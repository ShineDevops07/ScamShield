"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { assessmentLabel } from "@/lib/analysis";
import {
  ArrowRight,
  Check,
  ChevronRight,
  Download,
  FileText,
  Info,
  LockKeyhole,
  MessageCircle,
  RotateCcw,
  Send,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import {
  guidedAnswer,
  starterQuestions,
  type ChatMessage,
} from "@/lib/assistant";
import {
  downloadText,
  latestScan,
  redactSensitive,
  type SavedScan,
} from "@/lib/storage";
import { resources } from "@/lib/safety-data";
export default function Assistant() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"guided" | "ai">("guided");
  const [available, setAvailable] = useState(false);
  const [include, setInclude] = useState(false);
  const [scan, setScan] = useState<SavedScan | null>(null);
  const [error, setError] = useState("");
  const end = useRef<HTMLDivElement>(null);
  const field = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    setScan(latestScan());
    fetch("/api/chat")
      .then((r) => r.json())
      .then((d) => setAvailable(d.aiAvailable === true))
      .catch(() => setAvailable(false));
  }, []);
  useEffect(() => {
    end.current?.scrollIntoView?.({
      behavior: window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
      block: "nearest",
    });
  }, [messages, busy]);
  async function send(question = input) {
    if (!question.trim() || busy) return;
    const clean = redactSensitive(question.trim()).slice(0, 2000);
    const next = [...messages, { role: "user" as const, text: clean }].slice(
      -24,
    );
    setMessages(next);
    setInput("");
    setError("");
    if (mode === "guided") {
      const answer = guidedAnswer(clean, messages, include ? scan : null);
      setMessages([
        ...next,
        {
          role: "assistant",
          text: answer.text,
          topic: answer.topic,
          mode: "guided",
        },
      ]);
      field.current?.focus();
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next
            .slice(-12)
            .map((m) => ({ role: m.role, text: m.text })),
          context:
            include && scan
              ? JSON.stringify({
                  score: scan.assessment.score,
                  risk: scan.assessment.risk,
                  kind: scan.assessment.kind,
                  summary: scan.assessment.summary,
                  aiLinkReview: scan.assessment.aiReview,
                  findings: scan.assessment.signals.map((s) => ({
                    title: s.title,
                    description: s.description,
                  })),
                }).slice(0, 3900)
              : undefined,
        }),
        signal: AbortSignal.timeout(16000),
      });
      const data = await response.json();
      if (!response.ok || typeof data.text !== "string")
        throw Error(data.error || "Could not get an answer.");
      setMessages([
        ...next,
        { role: "assistant", text: data.text, mode: "ai" },
      ]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not get an answer.");
    } finally {
      setBusy(false);
      field.current?.focus();
    }
  }
  return (
    <main id="main-content" className="main-wrap subpage">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />A LITTLE HELP MAKES A DIFFERENCE
          </span>
          <h1>
            Let’s <span>talk it through.</span>
          </h1>
          <p>
            Ask a basic safety question. Get a clear explanation and a useful
            next step.
          </p>
        </div>
        <span className="page-emblem">
          <MessageCircle size={32} strokeWidth={1.3} />
        </span>
      </div>
      <div className="assistant-layout">
        <aside className="assistant-sidebar">
          <div className="sidebar-label">
            <ShieldCheck size={17} />
            <strong>Your safety assistant</strong>
          </div>
          <p>
            Built for everyday questions about scams, links, payments, and
            recovery.
          </p>
          <span className="section-label">CHOOSE A MODE</span>
          <div className="mode-options">
            <label className={mode === "guided" ? "active" : ""}>
              <input
                type="radio"
                name="mode"
                checked={mode === "guided"}
                onChange={() => setMode("guided")}
                disabled={busy}
              />
              <span>
                <strong>Guided answers</strong>
                <small>Local knowledge. No AI request.</small>
              </span>
              <LockKeyhole size={14} />
            </label>
            <label className={mode === "ai" ? "active" : ""}>
              <input
                type="radio"
                name="mode"
                checked={mode === "ai"}
                disabled={!available || busy}
                onChange={() => setMode("ai")}
              />
              <span>
                <strong>Gemini AI</strong>
                <small>
                  {available
                    ? "Sends this conversation to Gemini."
                    : "Requires a server API key."}
                </small>
              </span>
              <Sparkles size={14} />
            </label>
          </div>
          {!available && (
            <details className="ai-setup">
              <summary>
                How to enable AI chat
                <ChevronRight size={12} />
              </summary>
              <p>
                Add <code>GEMINI_API_KEY</code> to the server’s{" "}
                <code>.env.local</code> and restart. Optional: set{" "}
                <code>GEMINI_MODEL</code>. Never use a public environment
                variable for the key.
              </p>
            </details>
          )}
          <div className="chat-context">
            <FileText size={17} />
            <strong>Bring your latest check</strong>
            {scan ? (
              <>
                <p>
                  {assessmentLabel(scan.assessment)} · {scan.channel}
                </p>
                <label>
                  <input
                    type="checkbox"
                    checked={include}
                    disabled={busy}
                    onChange={(e) => setInclude(e.target.checked)}
                  />{" "}
                  Include the redacted findings
                </label>
              </>
            ) : (
              <>
                <p>No check in this session yet.</p>
                <Link href="/">
                  Run a check
                  <ArrowRight size={13} />
                </Link>
              </>
            )}
          </div>
          <p className="small-note">
            Chats are not saved after this page closes. Automated redaction is
            imperfect: don’t enter private details.
          </p>
          <Link className="help-link" href="/recover">
            Already responded to a scam?
            <ArrowRight size={14} />
          </Link>
        </aside>
        <section className="chat-panel" aria-label="Safety conversation">
          <div className="chat-topbar">
            <span>
              <span className="status-dot" />
              {mode === "guided" ? "Guided assistant" : "Gemini AI assistant"}
            </span>
            <div>
              <button
                className="icon-button"
                title="Download redacted conversation"
                aria-label="Download conversation"
                disabled={!messages.length || busy}
                onClick={() =>
                  downloadText(
                    "scamshield-conversation.txt",
                    messages
                      .map(
                        (m) =>
                          `${m.role === "user" ? "You" : "ScamShield"} (${m.mode || mode}):\n${redactSensitive(m.text)}`,
                      )
                      .join("\n\n"),
                  )
                }
              >
                <Download size={15} />
              </button>
              <button
                className="icon-button"
                aria-label="New conversation"
                title="New conversation"
                disabled={busy}
                onClick={() => {
                  setMessages([]);
                  setError("");
                  setInput("");
                }}
              >
                <RotateCcw size={15} />
              </button>
            </div>
          </div>
          <div
            className="chat-messages"
            role="log"
            aria-label="Messages"
            aria-live="polite"
          >
            {!messages.length ? (
              <div className="chat-welcome">
                <span className="welcome-shield">
                  <ShieldCheck size={30} strokeWidth={1.3} />
                </span>
                <h2>What are you unsure about?</h2>
                <p>
                  You can ask about suspicious messages, OTPs,
                  <br />
                  payment tricks, or your latest check.
                </p>
                <div className="suggestion-grid">
                  {starterQuestions.map((q) => (
                    <button key={q} onClick={() => send(q)}>
                      {q}
                      <ArrowRight size={14} />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m, i) => (
                <article key={i} className={`chat-bubble ${m.role}`}>
                  <span className="bubble-label">
                    {m.role === "user"
                      ? "You"
                      : `ScamShield · ${m.mode === "ai" ? "AI" : "guided"}`}
                  </span>
                  <p>{m.text}</p>
                </article>
              ))
            )}
            {busy && (
              <div className="thinking" role="status">
                <span />
                <span />
                <span />
                <span>Preparing an AI answer…</span>
              </div>
            )}
            <div ref={end} />
          </div>
          {error && (
            <div className="chat-error" role="alert">
              <Info size={14} />
              <span>
                {error}{" "}
                <button
                  onClick={() => {
                    setMode("guided");
                    const last = messages
                      .filter((m) => m.role === "user")
                      .at(-1);
                    if (last) {
                      const a = guidedAnswer(
                        last.text,
                        messages,
                        include ? scan : null,
                      );
                      setMessages([
                        ...messages,
                        {
                          role: "assistant",
                          text: a.text,
                          topic: a.topic,
                          mode: "guided",
                        },
                      ]);
                    }
                    setError("");
                  }}
                >
                  Use a guided answer instead
                </button>
              </span>
            </div>
          )}
          <form
            className="chat-compose"
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
          >
            <label className="sr-only" htmlFor="chat-input">
              Your safety question
            </label>
            <textarea
              ref={field}
              id="chat-input"
              value={input}
              maxLength={2000}
              disabled={busy}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (
                  e.key === "Enter" &&
                  !e.shiftKey &&
                  !e.nativeEvent.isComposing
                ) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder="Ask a safety question…"
              rows={2}
            />
            <button
              className="send-button"
              aria-label="Send question"
              type="submit"
              disabled={!input.trim() || busy}
            >
              <Send size={18} />
            </button>
            <span>
              {mode === "guided" ? (
                <>
                  <LockKeyhole size={11} /> Guided answers stay in this browser.
                </>
              ) : (
                <>
                  <Info size={11} /> Redacted messages are sent to Gemini.
                  Verify important guidance.
                </>
              )}
              <span>Enter to send · Shift + Enter for a new line</span>
            </span>
          </form>
        </section>
      </div>
      <div className="assistant-footnote">
        <Info size={14} />
        <p>
          This assistant gives general awareness guidance, not verified threat
          intelligence or a guarantee of safety.{" "}
          <a href={resources[1].url} target="_blank" rel="noreferrer">
            NPCI safety guidance
          </a>{" "}
          ·{" "}
          <a href={resources[0].url} target="_blank" rel="noreferrer">
            Official reporting portal
          </a>
        </p>
      </div>
    </main>
  );
}
