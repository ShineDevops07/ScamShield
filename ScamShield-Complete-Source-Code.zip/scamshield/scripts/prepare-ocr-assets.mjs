import { createRequire } from "node:module";
import { copyFile, mkdir, readdir, access } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);
const tessDir = path.dirname(require.resolve("tesseract.js/package.json"));
const coreDir = path.dirname(
  require.resolve("tesseract.js-core/package.json", { paths: [tessDir] }),
);
const target = path.join(root, "public", "ocr");
await mkdir(path.join(target, "core"), { recursive: true });
await copyFile(
  path.join(tessDir, "dist", "worker.min.js"),
  path.join(target, "worker.min.js"),
);
await copyFile(
  path.join(tessDir, "dist", "worker.min.js.LICENSE.txt"),
  path.join(target, "worker.LICENSE.txt"),
);
for (const name of await readdir(coreDir))
  if (
    (name.startsWith("tesseract-core") && name.endsWith(".wasm.js")) ||
    name.startsWith("LICENSE")
  )
    await copyFile(path.join(coreDir, name), path.join(target, "core", name));
await access(path.join(target, "lang", "eng.traineddata.gz"));
console.log("Self-hosted OCR worker, engine, and English model are ready.");
