export const challenges = [
  {
    category: "OTP safety",
    message:
      "Your login OTP is 492019. Never share this code with anyone. Our staff will never ask for it.",
    answer: "routine",
    why: "This is a protective warning, not a request to disclose a code. If you did not initiate a login, check your account through the official app. The sender is still not verified.",
  },
  {
    category: "UPI / QR",
    message:
      "I’m buying your old laptop. Scan my QR and enter your UPI PIN to receive ₹12,000 right now.",
    answer: "warning",
    why: "A UPI PIN is not required to receive money. A QR-and-PIN payment flow can send funds out. Check the payment screen and never follow a buyer’s instructions under pressure.",
  },
  {
    category: "Authority impersonation",
    message:
      "Your parcel contains banned substances. A digital arrest warrant is active. Transfer a refundable penalty immediately.",
    answer: "warning",
    why: "Threats of arrest combined with an urgent “refundable” payment are strong impersonation cues. Verify independently through official channels.",
  },
  {
    category: "Routine communication",
    message:
      "Your appointment is confirmed for Tuesday at 3 PM. Please bring the reference number from your booking.",
    answer: "routine",
    why: "There is no request for money, passwords, app installation, or urgent account changes. It may be routine; absence of these patterns does not verify the sender.",
  },
  {
    category: "Task jobs",
    message:
      "Earn ₹8,000 daily liking videos. Deposit ₹2,000 first to unlock your earnings with our Telegram manager.",
    answer: "warning",
    why: "High rewards for trivial tasks plus a deposit to unlock earnings are common task-scam patterns. A small initial payout would not prove safety.",
  },
  {
    category: "Mixed messages",
    message:
      "Never share your OTP with strangers. I’m your verification officer: send your OTP to me now or your account will be blocked.",
    answer: "warning",
    why: "The reassuring first sentence does not cancel the active OTP demand and pressure that follow. Evaluate each request, not just the presence of reassuring language.",
  },
] as const;
export const scamLibrary = [
  [
    "OTP & password theft",
    "An urgent caller asks you to read out a code or “confirm” your PIN.",
    "Keep codes private. Verify through the official service.",
  ],
  [
    "UPI & QR tricks",
    "A buyer or refund agent asks for a PIN to receive money.",
    "Read whether your app is sending money before authorizing.",
  ],
  [
    "Impersonation & arrest threats",
    "A caller claims to be customs or police and demands a settlement.",
    "Stop under pressure. Independently verify the claim.",
  ],
  [
    "Remote access & APK traps",
    "Support asks you to install an app or share control of your screen.",
    "Do not grant device access to an unverified caller.",
  ],
  [
    "Job & investment traps",
    "Easy daily earnings turn into deposits or withdrawal fees.",
    "Verify the employer independently before paying anything.",
  ],
  [
    "Links & lookalike domains",
    "The link displays a familiar brand but the actual host differs.",
    "Read the complete host and use the official app directly.",
  ],
] as const;
