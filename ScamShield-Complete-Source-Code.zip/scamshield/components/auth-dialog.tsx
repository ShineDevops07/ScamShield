"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, LogOut, X, ShieldCheck } from "lucide-react";
import { authFailure, type AuthFailure } from "@/lib/auth-errors";
import { getSupabase } from "@/lib/supabase/client";
import { useCloudHistory } from "@/components/cloud-history-provider";
export default function AuthDialog({
  onClose,
  onConfirmationRequired,
}: {
  onClose: () => void;
  onConfirmationRequired: () => void;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const previousOverflow = document.body.style.overflow;
    const previousFocus =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    dialog.showModal();
    document.body.style.overflow = "hidden";
    (
      dialog.querySelector<HTMLInputElement>("#account-email") ||
      dialog.querySelector<HTMLButtonElement>("button")
    )?.focus();
    return () => {
      dialog.close();
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, []);
  const cloud = useCloudHistory();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState<AuthFailure | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const client = getSupabase();
    if (!client || busy) return;
    setBusy(true);
    setError(null);
    setNotice("");
    try {
      const result =
        mode === "signin"
          ? await client.auth.signInWithPassword({
              email: email.trim(),
              password,
            })
          : await client.auth.signUp({
              email: email.trim(),
              password,
              options: { emailRedirectTo: `${window.location.origin}/account` },
            });
      if (result.error) {
        setError(authFailure(result.error, mode));
      } else {
        setPassword("");
        if (result.data.session) onClose();
        else if (mode === "signup") onConfirmationRequired();
        else
          setNotice(
            "Sign-in is not complete yet. Confirm your email if required, then try again.",
          );
      }
    } catch {
      setError({
        message:
          "Could not reach sign-in. Check your connection and try again.",
      });
    } finally {
      setBusy(false);
    }
  }
  async function signOut() {
    const client = getSupabase();
    if (!client || busy) return;
    setBusy(true);
    setError(null);
    setNotice("");
    try {
      const { error } = await client.auth.signOut({ scope: "local" });
      if (error) throw error;
      setNotice(
        "Signed out on this browser. Device history is still available.",
      );
    } catch {
      setError({ message: "Sign-out could not finish. Please retry." });
    } finally {
      setBusy(false);
    }
  }
  return (
    <dialog
      ref={dialogRef}
      className="auth-dialog"
      aria-labelledby="auth-dialog-title"
      aria-describedby="auth-dialog-description"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          const box = e.currentTarget.getBoundingClientRect();
          if (
            e.clientX < box.left ||
            e.clientX > box.right ||
            e.clientY < box.top ||
            e.clientY > box.bottom
          )
            onClose();
        }
      }}
    >
      <div className="auth-dialog-content">
        <button
          className="auth-close icon-button"
          aria-label="Close sign-in popup"
          onClick={onClose}
        >
          <X size={21} />
        </button>
        <span className="auth-symbol">
          <ShieldCheck size={23} />
        </span>
        <span className="section-label">
          {cloud.user ? "YOUR ACCOUNT" : "WELCOME TO SCAMSHIELD"}
        </span>
        <h2 id="auth-dialog-title">
          {cloud.user ? "Your checks, with you." : "Keep your checks together."}
        </h2>
        <p id="auth-dialog-description">
          {cloud.user
            ? "Manage your account and choose what syncs."
            : "Sign in to save your history across devices, or close this window and continue as a guest."}
        </p>
        {!cloud.configured ? (
          <>
            <span className="section-label">CLOUD SETUP PENDING</span>
            <h3>Device history is ready.</h3>
            <p>
              Cloud sign-in will be available after this app’s Supabase project
              is configured. Your existing checks can still be saved on this
              device.
            </p>
            <Link href="/history" onClick={onClose} className="primary-button">
              Open device history <ArrowRight size={16} />
            </Link>
          </>
        ) : cloud.loading ? (
          <p role="status">Checking your account…</p>
        ) : cloud.user ? (
          <>
            <span className="section-label">SIGNED IN</span>
            <p className="account-email">{cloud.user.email}</p>
            <label className="cloud-toggle">
              <input
                type="checkbox"
                checked={cloud.enabled}
                onChange={(e) => cloud.setEnabled(e.target.checked)}
              />
              <span>
                <strong>Sync new saved checks</strong>
                <small>
                  When a check’s save option is selected, also save its redacted
                  summary to this account. Existing device history stays here
                  until you choose to import it.
                </small>
              </span>
            </label>
            <Link className="primary-button" href="/history" onClick={onClose}>
              Review history <ArrowRight size={16} />
            </Link>
            <button
              className="secondary-button"
              disabled={busy}
              onClick={signOut}
            >
              <LogOut size={15} />
              {busy ? "Signing out…" : "Sign out"}
            </button>
          </>
        ) : (
          <>
            <div
              className="filter-group account-modes"
              role="group"
              aria-label="Account action"
            >
              <button
                aria-pressed={mode === "signin"}
                disabled={busy}
                onClick={() => {
                  setMode("signin");
                  setNotice("");
                  setError(null);
                }}
              >
                Sign in
              </button>
              <button
                aria-pressed={mode === "signup"}
                disabled={busy}
                onClick={() => {
                  setMode("signup");
                  setNotice("");
                  setError(null);
                }}
              >
                Create account
              </button>
            </div>
            <form className="account-form" onSubmit={submit}>
              <label htmlFor="account-email">Email address</label>
              <input
                id="account-email"
                type="email"
                autoComplete="email"
                required
                maxLength={254}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={busy}
              />
              <label htmlFor="account-password">Password</label>
              <input
                id="account-password"
                type="password"
                autoComplete={
                  mode === "signup" ? "new-password" : "current-password"
                }
                minLength={mode === "signup" ? 8 : undefined}
                maxLength={128}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={busy}
              />
              {mode === "signup" && (
                <small>
                  Use at least 8 characters. Email confirmation may be required.
                </small>
              )}
              <button className="primary-button" disabled={busy}>
                {busy
                  ? "Please wait…"
                  : mode === "signin"
                    ? "Sign in to ScamShield"
                    : "Create my account"}
                <ArrowRight size={15} />
              </button>
            </form>
          </>
        )}
        {notice && (
          <p className="account-message" role="status">
            {notice}
          </p>
        )}
        {error && (
          <div className="account-error" role="alert">
            <p>{error.message}</p>
            {error.reference && (
              <small className="auth-error-reference">
                Error reference: <code>{error.reference}</code>
              </small>
            )}
          </div>
        )}
        {!cloud.user && (
          <button className="auth-guest" onClick={onClose}>
            Continue as guest <ArrowRight size={15} />
          </button>
        )}
        <p className="auth-privacy">
          Only saved redacted summaries sync. Raw images and audio stay out of
          cloud history. Redaction can miss personal details.
        </p>
      </div>
    </dialog>
  );
}
