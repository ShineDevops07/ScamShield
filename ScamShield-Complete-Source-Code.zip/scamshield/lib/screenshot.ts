export const MAX_SCREENSHOT_BYTES = 5 * 1024 * 1024;
export const MAX_SCREENSHOT_PIXELS = 20_000_000;
export const MAX_SCREENSHOT_EDGE = 12_000;
export const MAX_OCR_TEXT = 10_000;
export const OCR_ASSET_ROOT = "/ocr";

export function screenshotMime(size: number, bytes: Uint8Array): string {
  if (size === 0)
    throw new Error(
      "This file is empty. Choose a screenshot with readable text.",
    );
  if (size > MAX_SCREENSHOT_BYTES)
    throw new Error(
      "This image is over 5 MB. Crop or resize it and try again.",
    );
  if (
    bytes.length >= 8 &&
    [137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => bytes[i] === v)
  )
    return "image/png";
  if (
    bytes.length >= 3 &&
    bytes[0] === 255 &&
    bytes[1] === 216 &&
    bytes[2] === 255
  )
    return "image/jpeg";
  if (
    bytes.length >= 12 &&
    String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" &&
    String.fromCharCode(...bytes.slice(8, 12)) === "WEBP"
  )
    return "image/webp";
  throw new Error(
    "Choose a PNG, JPEG, or WebP image. PDFs, GIFs, and SVGs are not supported.",
  );
}
export function validateDimensions(width: number, height: number) {
  if (
    !Number.isFinite(width) ||
    !Number.isFinite(height) ||
    width <= 0 ||
    height <= 0
  )
    throw new Error(
      "This image could not be decoded. Choose another screenshot.",
    );
  if (
    width * height > MAX_SCREENSHOT_PIXELS ||
    width > MAX_SCREENSHOT_EDGE ||
    height > MAX_SCREENSHOT_EDGE
  )
    throw new Error(
      "This image is too large to process safely. Crop the message area and try again.",
    );
}
export function reviewedText(text: string) {
  return text.replace(/\r\n?/g, "\n").trim().slice(0, MAX_OCR_TEXT);
}

/** Read declared dimensions before asking the browser to allocate a decoded image. */
export function declaredDimensions(
  bytes: Uint8Array,
  mime: string,
): { width: number; height: number } | null {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (
    mime === "image/png" &&
    bytes.length >= 24 &&
    String.fromCharCode(...bytes.slice(12, 16)) === "IHDR"
  )
    return { width: view.getUint32(16), height: view.getUint32(20) };
  if (mime === "image/webp" && bytes.length >= 30) {
    const tag = String.fromCharCode(...bytes.slice(12, 16));
    if (tag === "VP8X") {
      if (bytes[20] & 2)
        throw new Error(
          "Animated WebP files are not supported. Use a still screenshot.",
        );
      return {
        width: 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16),
        height: 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16),
      };
    }
    if (
      tag === "VP8 " &&
      bytes[23] === 157 &&
      bytes[24] === 1 &&
      bytes[25] === 42
    )
      return {
        width: view.getUint16(26, true) & 16383,
        height: view.getUint16(28, true) & 16383,
      };
    if (tag === "VP8L" && bytes[20] === 47) {
      const bits = view.getUint32(21, true);
      return { width: 1 + (bits & 16383), height: 1 + ((bits >>> 14) & 16383) };
    }
  }
  if (mime === "image/jpeg") {
    let pos = 2;
    while (pos + 4 < bytes.length) {
      if (bytes[pos] !== 255) {
        pos++;
        continue;
      }
      while (bytes[pos] === 255) pos++;
      const marker = bytes[pos++];
      if (marker === 217 || marker === 218) break;
      if (marker === 1 || (marker >= 208 && marker <= 216)) continue;
      if (pos + 2 > bytes.length) break;
      const length = view.getUint16(pos);
      if (length < 2 || pos + length > bytes.length) break;
      if (
        [
          192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207,
        ].includes(marker) &&
        length >= 8
      )
        return {
          width: view.getUint16(pos + 5),
          height: view.getUint16(pos + 3),
        };
      pos += length;
    }
  }
  return null;
}
