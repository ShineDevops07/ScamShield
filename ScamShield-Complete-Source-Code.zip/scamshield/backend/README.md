# ScamShield Backend & Threat Intelligence API

This is the separate supplied Python implementation. The current website uses local TypeScript rules and Next.js API routes; it does not call this service. Follow the root [README](../README.md) for current startup steps, environment settings and feature boundaries. Descriptions such as calibrated confidence or independently verified evidence are schema/design terminology, not proof of statistical calibration or a completed external verification.

ScamShield is a production-minded Python/FastAPI service designed to evaluate suspicious digital communications (SMS, WhatsApp, emails, call transcripts, and links), detect social engineering and extortion patterns, and provide actionable, safe guidance.

---

## Architecture Overview

```
backend/
├── main.py                      # FastAPI entrypoint, middleware (CORS, rate limiting, request tracking)
├── requirements.txt             # Core dependencies (FastAPI, Pydantic, HTTPX, Pytest, Uvicorn)
├── .env.example                 # Config template with placeholder keys
├── app/
│   ├── api/
│   │   └── routes/
│   │       ├── health.py        # GET /health, GET /api/v1/capabilities
│   │       ├── analyze.py       # POST /api/v1/analyze, POST /api/compat/analyze
│   │       ├── urls.py          # POST /api/v1/analyze-url (static URL inspection)
│   │       ├── followup.py      # POST /api/v1/followup (context-aware assistant)
│   │       ├── emergency.py     # POST /api/v1/emergency (prioritized response)
│   │       └── images.py        # POST /api/v1/analyze-image (safe file signature check + OCR)
│   ├── core/
│   │   ├── config.py            # Pydantic Settings & environment variables
│   │   ├── logging.py           # Structured logs with automated PII & credential redaction
│   │   └── security.py          # SSRF prevention, sliding-window rate limiting, prompt injection guard
│   ├── rules/
│   │   ├── fraud_patterns.py    # Deterministic catalog for digital arrest, KYC cutoff, APK traps, etc.
│   │   └── contextual_rules.py  # Negation detection, quote/reporting context, pure OTP delivery
│   ├── schemas/
│   │   ├── requests.py          # Validated input schemas with length bounds
│   │   └── responses.py         # Response models, multi-tier evidence items, frontend compatibility
│   ├── services/
│   │   ├── analysis_pipeline.py # Orchestrator for rules, URLs, AI inference, and risk scoring
│   │   ├── ai_provider.py       # Abstraction for Gemini, OpenAI, and local heuristic fallback
│   │   ├── context_analysis.py  # Semantic context, negations, and feature extraction
│   │   ├── evidence_analysis.py # Evidence categorization (Observed, Inferred, Independently Verified)
│   │   ├── risk_engine.py       # Bounded 0-100 scoring engine with distinct calibrated confidence
│   │   ├── url_analysis.py      # Non-fetching static lookalike, punycode, and shortener parser
│   │   ├── followup_service.py  # Q&A assistant explaining risk scores without hallucinated advice
│   │   ├── emergency_service.py # Indian cybercrime (1930) and containment workflows
│   │   └── image_service.py     # Magic-byte file validator & multimodal OCR integration
│   └── tests/                   # Comprehensive pytest regression suite (27 automated tests)
```

---

## Getting Started

### 1. Prerequisites
- Python 3.10+ (tested on Python 3.13)
- `pip` or virtual environment manager

### 2. Setup Virtual Environment & Install Dependencies
```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv

# Activate on Windows PowerShell:
.\venv\Scripts\Activate.ps1
# Or on Linux/macOS:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Configure your keys as needed. For example, to enable Google Gemini AI analysis and OCR:
```env
AI_PROVIDER=gemini
GEMINI_API_KEY=AIzaSy...
GEMINI_MODEL=gemini-2.5-flash
```
*Note:* The system is completely functional without an API key using the deterministic rules and heuristics engine. It never claims AI ran when falling back to rules.

### 4. Run the Development Server
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive API documentation will be available at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

---

## Core API Endpoints

### 1. Main Message Analysis
**`POST /api/v1/analyze`**

Evaluates incoming digital communications (SMS, WhatsApp, emails, call transcripts).

**Request Body:**
```json
{
  "message": "This is Mumbai Customs. An illegal parcel in your name was seized. Digital arrest warrant issued. Transfer refundable penalty of ₹45,000 immediately.",
  "content_type": "message",
  "sender": "+91 98231 09841",
  "url": null,
  "context": "Received via phone call"
}
```

**Key Result Fields:**
- `analysis_id`: Unique session UUID.
- `risk_score`: Bounded score between `0` and `100`.
- `risk_level`: `low`, `caution`, `high`, or `critical`.
- `confidence`: Calibrated confidence indicator separate from risk score.
- `verdict` & `summary`: Concise, honest explanation.
- `detected_categories`: Identified scam types.
- `evidence`: Structured findings categorized into:
  - `observed`: Direct text or syntax present in input.
  - `inferred`: Semantic intent, urgency, or authority claims.
  - `independently_verified`: Verified external domain/threat intelligence.
- `red_flags` & `reassuring_signals`: Specific pros/cons.
- `recommended_actions` & `what_not_to_do`: Actionable guidance.
- `verification_steps`: Independent out-of-band checks.
- `analysis_method`: `ai_assisted`, `rules_based`, or `hybrid`.
- `limitations`: Explicit assessment boundaries.

### 2. Frontend Direct Compatibility Bridge
**`POST /api/compat/analyze`** (or `POST /api/analyze`)

Directly matches the frontend's expected payload:
```json
{
  "type": "message",
  "text": "Your account will be suspended. Confirm your PIN via http://bit.ly/bank-auth",
  "sender": "Bank Alert",
  "subject": "Urgent Security Notice"
}
```
Returns both the full schema and frontend-specific properties (`score`, `riskBand`, `signals`, `aiAnalysis`, `recommendedAction`, `verificationStatus`, `disclaimer`).

### 3. Static Safe URL Inspection
**`POST /api/v1/analyze-url`**

Inspects suspicious URLs without executing scripts or visiting the destination server:
```json
{
  "url": "https://hfdcbank-kyc-update-portal-netbanking.support/login.php"
}
```
Checks for:
- Lookalike / typosquatting domains (e.g. `hfdc` vs `hdfc`)
- Direct IP hostnames
- Credential / userinfo `@` obfuscation
- Punycode / IDN homograph attacks (`xn--`)
- Nested subdomains
- Known URL shorteners (`bit.ly`, `tinyurl`)

### 4. Follow-up Security Assistant
**`POST /api/v1/followup`**

Answers questions about a previous ScamShield analysis. Enforces guardrails:
- Explains why scores were assigned.
- Answers verification queries.
- Rejects prompt injections attempting to bypass safety policies.
- Never advises users to share credentials or send money.

### 5. Emergency Incident Response
**`POST /api/v1/emergency`**

Delivers prioritized harm-reduction checklists for users who have already fallen victim:
```json
{
  "scenario": "otp_shared",
  "bank_name": "State Bank of India"
}
```
Supported scenarios: `otp_shared`, `credentials_leaked`, `money_sent`, `apk_installed`, `remote_access_granted`, `link_clicked`, `id_documents_shared`, `extortion_blackmail`. Includes Indian National Cyber Crime Helpline (**1930**) and "Golden Hour" reporting guidance.

### 6. Image & Screenshot OCR Analysis
**`POST /api/v1/analyze-image`**

Accepts `multipart/form-data` file uploads. Validates magic-byte signatures for PNG, JPEG, and WEBP before executing multimodal OCR and risk evaluation.

---

## Security & Privacy Controls

1. **Prompt Injection Defense**: Untrusted content is wrapped in rigid XML isolation tags `<submitted_content>` with strict delimiter boundaries.
2. **SSRF Safe**: Never resolves or fetches private RFC 1918 IPs, loopback (`127.0.0.1`), link-local, or cloud metadata endpoints (`169.254.169.254`).
3. **Automated Log Redaction**: OTPs, Aadhaar numbers (12-digit), PAN cards, credit cards, passwords, and auth tokens are scrubbed from server logs.
4. **Sliding-Window Rate Limiting**: In-memory IP-based rate limiting (60 requests/minute by default).
5. **Payload Size Caps**: Rejects payloads exceeding 1MB (and image uploads exceeding 5MB).

---

## Running the Automated Test Suite

To run all 27 automated unit, regression, and security tests:
```bash
# From the backend directory
pytest app/tests -v
```

The test suite validates:
- All 7 contextual false-positive scenarios (e.g., `"Don't send the OTP to anyone"`, `"Your delivery fee is ₹40"`, `"Your OTP is 482193"`).
- All 5 elevated concern scenarios (e.g., account blocked in 10 minutes, APK install, remote access).
- API request/response schemas.
- URL lookalike and SSRF prevention guards.
- Sensitive data redaction in logging.
- Emergency guidance workflows.

---

## Authors & Engineering Credits

- **Backend Architecture & Security Engine**: Engineered by **Antigravity** (Google DeepMind Advanced Agentic Coding).
- **Fraud Analysis Rules & Contextual Heuristics**: Designed for proactive digital threat forensics and cybercrime protection.

