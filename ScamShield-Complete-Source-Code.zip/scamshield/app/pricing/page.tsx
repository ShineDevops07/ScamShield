"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowDownToLine,
  ArrowRight,
  Building2,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  HeartHandshake,
  Info,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import { downloadText } from "@/lib/storage";

type Audience = "family" | "organization";
type Plan = {
  id: string;
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  label: string;
};

const familyPlans: Plan[] = [
  {
    id: "family-essential",
    name: "Family Essential",
    price: 99,
    period: "/ month",
    description:
      "A simple way to bring a trusted person into the conversation.",
    label: "Upcoming subscription",
    features: [
      "Everything in Free",
      "Trusted-contact invitations",
      "Shared requests for a second opinion",
      "Family scam-awareness reminders",
    ],
  },
  {
    id: "family-plus",
    name: "Family Plus",
    price: 199,
    period: "/ month",
    description: "More context and coordination for a family's safety routine.",
    label: "Upcoming subscription",
    features: [
      "Everything in Family Essential",
      "A shared family review dashboard",
      "Review status and follow-up reminders",
      "A monthly family learning recap",
    ],
  },
];

const pilotPlans: Plan[] = [
  {
    id: "pilot-starter",
    name: "Starter pilot",
    price: 5000,
    period: "/ 4 weeks",
    description: "Introduce scam awareness to a small team or community.",
    label: "Proposed pilot scope",
    features: [
      "Guided introduction to the free tools",
      "One scam-awareness workshop",
      "Recovery and reporting resource pack",
      "End-of-pilot feedback review",
    ],
  },
  {
    id: "pilot-extended",
    name: "Extended pilot",
    price: 15000,
    period: "/ 4 weeks",
    description: "A more hands-on awareness program with room to follow up.",
    label: "Proposed pilot scope",
    features: [
      "Everything in Starter pilot",
      "A follow-up awareness workshop",
      "Scenarios tailored to your audience",
      "A feedback summary and next-step plan",
    ],
  },
];

const freeFeatures = [
  "Message, call-transcript & link checks",
  "Screenshot text extraction and review",
  "Guided safety assistant & recovery steps",
  "Learning challenges & local scan history",
];

const familyComparison = [
  ["All current checking & learning tools", "Included", "Included", "Included"],
  [
    "Report downloads & optional saved history",
    "Included",
    "Included",
    "Included",
  ],
  ["Trusted contacts & shared review requests", "—", "Planned", "Planned"],
  ["Family awareness reminders", "—", "Planned", "Planned"],
  ["Shared dashboard & review follow-ups", "—", "—", "Planned"],
  ["Monthly family learning recap", "—", "—", "Planned"],
];

const pilotComparison = [
  ["Access to the current free tools", "Included", "Included"],
  ["Guided introduction & resource pack", "Proposed", "Proposed"],
  ["Scam-awareness workshops", "1 session", "2 sessions"],
  ["End-of-pilot feedback review", "Proposed", "Proposed"],
  ["Audience-specific scenarios", "—", "Proposed"],
  ["Written feedback & next-step plan", "—", "Proposed"],
];

const formatPrice = (value: number) => `₹${value.toLocaleString("en-IN")}`;

export default function Pricing() {
  const [audience, setAudience] = useState<Audience>("family");
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [focus, setFocus] = useState("Everyday digital safety");
  const [downloaded, setDownloaded] = useState(false);
  const summaryTitle = useRef<HTMLHeadingElement>(null);
  const previewTrigger = useRef<HTMLButtonElement | null>(null);
  const organization = audience === "organization";

  useEffect(() => {
    if (selectedPlan) summaryTitle.current?.focus();
  }, [selectedPlan]);

  function changeAudience(next: Audience) {
    setAudience(next);
    setSelectedPlan(null);
    setDownloaded(false);
  }

  function preview(plan: Plan, trigger: HTMLButtonElement) {
    previewTrigger.current = trigger;
    setSelectedPlan(plan);
    setDownloaded(false);
  }

  function downloadPlan() {
    if (!selectedPlan) return;
    downloadText(
      `scamshield-${selectedPlan.id}-summary.txt`,
      [
        "ScamShield — plan preview",
        selectedPlan.name,
        `${formatPrice(selectedPlan.price)} ${selectedPlan.period}`,
        organization
          ? "One four-week pilot. No automatic renewal. Scope and scheduling require agreement before payment."
          : "Proposed monthly subscription. Family features are planned and not yet available.",
        "",
        ...selectedPlan.features.map((feature) => `• ${feature}`),
        ...(organization ? ["", `Preferred focus: ${focus}`] : []),
        "",
        "This is a locally generated plan summary, not an order, invoice, booking, or subscription.",
        "No payment was taken. No request was submitted. No paid features were activated.",
        "Final billing and tax details will be shown before paid plans launch.",
        "The current free tools remain available without an account.",
      ].join("\n"),
    );
    setDownloaded(true);
  }

  return (
    <main id="main-content" className="main-wrap subpage pricing-page">
      <div className="page-heading pricing-heading">
        <div>
          <span className="eyebrow">
            <span /> PLANS & PRICING
          </span>
          <h1>
            Good habits. <span>A little backup.</span>
          </h1>
          <p>
            Start with the free tools. Explore more support for your family or
            community.
          </p>
        </div>
        <span className="page-emblem">
          <HeartHandshake size={36} strokeWidth={1.3} />
        </span>
      </div>

      <div className="pricing-toolbar">
        <div
          className="pricing-audiences"
          role="group"
          aria-label="Choose who the plan is for"
        >
          <button
            type="button"
            aria-pressed={!organization}
            onClick={() => changeAudience("family")}
          >
            <Users size={16} /> Individuals & families
          </button>
          <button
            type="button"
            aria-pressed={organization}
            onClick={() => changeAudience("organization")}
          >
            <Building2 size={16} /> Organizations
          </button>
        </div>
        <span className="pricing-currency">Prices in Indian rupees · INR</span>
      </div>

      <div className="pricing-notice">
        <Info size={17} aria-hidden="true" />
        <p>
          <strong>Paid plans are in preview.</strong> Compare the proposed
          benefits below. Checkout is not open yet, and selecting a plan won't
          charge you.
        </p>
      </div>

      <section
        className={`pricing-grid ${organization ? "pricing-pilots" : ""}`}
        aria-label={
          organization
            ? "Organization pilot plans"
            : "Individual and family plans"
        }
      >
        {!organization && (
          <article className="subscription-card free-subscription">
            <div className="subscription-icon">
              <ShieldCheck size={22} strokeWidth={1.6} />
            </div>
            <span className="subscription-label available-label">
              Available now
            </span>
            <h2>Free</h2>
            <p className="subscription-description">
              A practical first check when something doesn't feel right.
            </p>
            <div className="subscription-price">
              <strong>₹0</strong>
              <span>/ no subscription</span>
            </div>
            <Link href="/" className="primary-button">
              Start a free check <ArrowRight size={15} />
            </Link>
            <p className="subscription-caption">
              No account or payment details needed
            </p>
            <ul>
              {freeFeatures.map((feature) => (
                <li key={feature}>
                  <Check size={15} aria-hidden="true" />
                  {feature}
                </li>
              ))}
            </ul>
          </article>
        )}
        {(organization ? pilotPlans : familyPlans).map((plan, index) => (
          <article
            key={plan.id}
            className={`subscription-card ${index === 1 ? "subscription-expanded" : ""} ${selectedPlan?.id === plan.id ? "subscription-selected" : ""}`}
          >
            <div className="subscription-icon">
              {organization ? (
                <Building2 size={22} strokeWidth={1.6} />
              ) : index === 0 ? (
                <Users size={22} strokeWidth={1.6} />
              ) : (
                <HeartHandshake size={22} strokeWidth={1.6} />
              )}
            </div>
            <span className="subscription-label">{plan.label}</span>
            <h2>{plan.name}</h2>
            <p className="subscription-description">{plan.description}</p>
            <div className="subscription-price">
              <strong>{formatPrice(plan.price)}</strong>
              <span>{plan.period}</span>
            </div>
            <button
              type="button"
              className="secondary-button"
              aria-pressed={selectedPlan?.id === plan.id}
              aria-controls="plan-preview"
              onClick={(event) => preview(plan, event.currentTarget)}
            >
              {organization ? "Preview" : "Explore"} {plan.name}
              <ArrowRight size={15} />
            </button>
            <p className="subscription-caption">
              {organization
                ? "One pilot · No automatic renewal"
                : "Monthly price · Features coming soon"}
            </p>
            <ul>
              {plan.features.map((feature) => (
                <li key={feature}>
                  {organization ? (
                    <Check size={15} aria-hidden="true" />
                  ) : (
                    <Clock3 size={15} aria-hidden="true" />
                  )}
                  {feature}
                </li>
              ))}
            </ul>
            {!organization && (
              <p className="subscription-planned">
                Family benefits are planned, not active yet.
              </p>
            )}
          </article>
        ))}
      </section>

      <section
        id="plan-preview"
        className={`subscription-preview ${selectedPlan ? "has-selection" : ""}`}
        aria-label="Plan preview"
      >
        {selectedPlan ? (
          <>
            <div className="subscription-preview-heading">
              <div>
                <span className="section-label">YOUR PLAN PREVIEW</span>
                <h2 ref={summaryTitle} tabIndex={-1}>
                  {selectedPlan.name}
                </h2>
              </div>
              <button
                type="button"
                className="plan-close"
                aria-label="Close plan preview"
                onClick={() => {
                  setSelectedPlan(null);
                  setDownloaded(false);
                  previewTrigger.current?.focus();
                }}
              >
                <X size={18} />
              </button>
            </div>
            <div className="subscription-preview-body">
              <div className="subscription-preview-details">
                <p className="preview-price">
                  {formatPrice(selectedPlan.price)}{" "}
                  <span>{selectedPlan.period}</span>
                </p>
                <p>
                  {organization
                    ? "A proposed four-week awareness program. Scope and scheduling need to be agreed before a pilot can be booked."
                    : "A preview of the planned family subscription. Accounts, family sharing, and paid billing are still to be built."}
                </p>
                {organization && (
                  <label className="pilot-focus" htmlFor="pilot-focus">
                    What would you like the pilot to focus on?
                    <select
                      id="pilot-focus"
                      value={focus}
                      onChange={(event) => {
                        setFocus(event.target.value);
                        setDownloaded(false);
                      }}
                    >
                      <option>Everyday digital safety</option>
                      <option>UPI and payment scams</option>
                      <option>Phishing and impersonation</option>
                      <option>Safety for students</option>
                      <option>Safety for older adults</option>
                    </select>
                  </label>
                )}
              </div>
              <div className="subscription-preview-action">
                <button
                  type="button"
                  className="primary-button"
                  onClick={downloadPlan}
                >
                  <ArrowDownToLine size={16} /> Download{" "}
                  {organization ? "pilot brief" : "plan details"}
                </button>
                <span>Saved to your device. No request is submitted.</span>
                <p role="status">
                  {downloaded
                    ? "Your download is ready. No payment or subscription was created."
                    : "Preview only · No charge · No activation"}
                </p>
              </div>
            </div>
          </>
        ) : (
          <div className="subscription-preview-empty">
            <CircleHelp size={20} />
            <p>
              <strong>Take a closer look.</strong> Choose a paid plan above to
              preview the details and download a summary.
            </p>
          </div>
        )}
      </section>

      <section
        className="subscription-comparison"
        aria-labelledby="comparison-heading"
      >
        <div className="section-heading">
          <div>
            <span className="section-label">THE DETAILS, SIDE BY SIDE</span>
            <h2 id="comparison-heading">
              {organization
                ? "Choose your pilot's scope."
                : "Find the right amount of support."}
            </h2>
          </div>
          <p>
            {organization
              ? "Both pilots run for four weeks."
              : "Every plan starts with the same free tools."}
          </p>
        </div>
        <div
          className="pricing-table-scroll"
          role="region"
          aria-label="Scrollable plan comparison"
          tabIndex={0}
        >
          <table className="pricing-table">
            <caption className="pricing-table-caption">
              {organization
                ? "Pilot delivery is proposed; no booking has been made."
                : "Included = available today. Planned = a future family feature."}
            </caption>
            <thead>
              <tr>
                <th scope="col">
                  {organization ? "Pilot scope" : "What's included"}
                </th>
                {(organization
                  ? ["Starter pilot", "Extended pilot"]
                  : ["Free", "Family Essential", "Family Plus"]
                ).map((name) => (
                  <th key={name} scope="col">
                    {name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(organization ? pilotComparison : familyComparison).map(
                ([feature, ...values]) => (
                  <tr key={feature}>
                    <th scope="row">{feature}</th>
                    {values.map((value, index) => (
                      <td key={index}>
                        <span
                          className={
                            value === "Included"
                              ? "comparison-included"
                              : value === "Planned" || value === "Proposed"
                                ? "comparison-planned"
                                : ""
                          }
                        >
                          {value === "Included" && (
                            <Check size={12} aria-hidden="true" />
                          )}
                          {value === "—" ? (
                            <span aria-label="Not included">—</span>
                          ) : (
                            value
                          )}
                        </span>
                      </td>
                    ))}
                  </tr>
                ),
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="pricing-faq" aria-labelledby="pricing-faq-heading">
        <div>
          <span className="section-label">BEFORE YOU CHOOSE</span>
          <h2 id="pricing-faq-heading">A few fair questions.</h2>
          <p>Clear prices. Clear expectations.</p>
        </div>
        <div className="pricing-questions">
          {[
            [
              "Can I use ScamShield without paying?",
              "Yes. All current message, transcript, screenshot, and link checks, guided safety conversations, learning tools, recovery checklists, and optional saved history are free. Supabase accounts and cloud history require a configured project; paid family sharing is still planned. Optional Gemini chat and OpenAI audio transcription need separately configured API keys; provider usage is not included in these plans.",
            ],
            [
              "Can I buy a subscription today?",
              "Not yet. This page previews the prices and benefits. There is no checkout, recurring charge, or active paid subscription. A downloaded summary is for your reference and does not create an account or order.",
            ],
            [
              "What do the family plans add?",
              "The proposed ₹99/month plan adds trusted contacts, shared review requests, and awareness reminders. The proposed ₹199/month plan also adds a family dashboard, review follow-ups, and learning recaps. These family features are planned and are not available in the current app.",
            ],
            [
              "How does an organization pilot work?",
              "The proposed ₹5,000 Starter pilot and ₹15,000 Extended pilot each cover four weeks. They combine the existing free tools with facilitated awareness activities. The scope and schedule must be agreed before a booking or payment. No organization dashboard or enterprise API is included.",
            ],
            [
              "What about renewals, cancellations, and taxes?",
              "The family prices shown are monthly; the pilot prices cover one four-week program without automatic renewal. Before payments launch, the checkout must show the final amount, applicable taxes, renewal terms, and cancellation controls. No one can be charged from this preview.",
            ],
            [
              "Does a plan guarantee protection from scams?",
              "No. ScamShield explains common warning signs and helps you decide what to verify next. It cannot confirm a sender's identity, guarantee that something is safe, or recover lost money. Use the recovery page if you need practical next steps.",
            ],
          ].map(([question, answer]) => (
            <details key={question}>
              <summary>
                {question}
                <ChevronDown size={16} aria-hidden="true" />
              </summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>

      <div className="pricing-bottom-note">
        <ShieldCheck size={19} />
        <p>You don't need a subscription to pause and check.</p>
        <Link href="/screenshots">
          Try a screenshot check <ArrowRight size={15} />
        </Link>
      </div>
    </main>
  );
}
