import type { Metadata, Viewport } from "next";
import "./globals.css";
import CloudHistoryProvider from "@/components/cloud-history-provider";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

export const metadata: Metadata = {
  title: "ScamShield — Check before you respond.",
  description:
    "Take a closer look at suspicious messages, call transcripts, and website links. Understand common warning signs before you respond.",
};

export const viewport: Viewport = {
  colorScheme: "light",
  themeColor: "#f7f8f5",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main-content">
          Skip to content
        </a>
        <CloudHistoryProvider>
          <SiteHeader />
          {children}
          <SiteFooter />
        </CloudHistoryProvider>
      </body>
    </html>
  );
}
