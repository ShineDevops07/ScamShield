-- Run once in the Supabase SQL editor, or apply using `supabase db push`.
-- This migration only creates the dedicated ScamShield history table.
begin;
create table if not exists public.scamshield_checks (
  user_id uuid not null references auth.users(id) on delete cascade,
  id uuid not null,
  created_at timestamptz not null default now(),
  channel text not null check (channel in ('message', 'call', 'url')),
  source text not null check (source in ('message', 'call', 'url', 'screenshot', 'audio')),
  preview text not null check (char_length(preview) <= 160),
  assessment jsonb not null,
  primary key (user_id, id),
  constraint scamshield_source_channel check (
    (source in ('message', 'screenshot') and channel = 'message') or
    (source in ('call', 'audio') and channel = 'call') or
    (source = 'url' and channel = 'url')
  ),
  constraint scamshield_assessment_shape check (coalesce(
    jsonb_typeof(assessment) = 'object' and
    assessment ->> 'tone' in ('neutral', 'safe', 'warning', 'danger') and
    jsonb_typeof(assessment -> 'risk') = 'string' and
    jsonb_typeof(assessment -> 'summary') = 'string' and
    char_length(assessment ->> 'risk') <= 100 and
    char_length(assessment ->> 'summary') <= 1200 and
    jsonb_typeof(assessment -> 'signals') = 'array' and
    jsonb_array_length(assessment -> 'signals') <= 30 and
    octet_length(assessment::text) <= 100000 and (
      (jsonb_typeof(assessment -> 'score') = 'number' and (assessment ->> 'score')::numeric between 0 and 100) or
      (assessment -> 'score' = 'null'::jsonb and assessment ->> 'kind' = 'payment_receipt' and assessment ->> 'tone' = 'neutral')
    ), false))
);
create index if not exists scamshield_checks_owner_date on public.scamshield_checks(user_id, created_at desc, id desc);
alter table public.scamshield_checks enable row level security;
revoke all on public.scamshield_checks from anon;
grant select, insert, update, delete on public.scamshield_checks to authenticated;
-- Policy names are scoped to this table. Reapplying this migration is safe.
drop policy if exists "scamshield_read_own" on public.scamshield_checks;
create policy "scamshield_read_own" on public.scamshield_checks for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "scamshield_insert_own" on public.scamshield_checks;
create policy "scamshield_insert_own" on public.scamshield_checks for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "scamshield_update_own" on public.scamshield_checks;
create policy "scamshield_update_own" on public.scamshield_checks for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists "scamshield_delete_own" on public.scamshield_checks;
create policy "scamshield_delete_own" on public.scamshield_checks for delete to authenticated using ((select auth.uid()) = user_id);
commit;
