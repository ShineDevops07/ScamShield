"use client";

import { useEffect, useRef, useState } from "react";
import type { Worker as OCRWorker } from "tesseract.js";
import Link from "next/link";
import CloudSaveNote from "@/components/cloud-save-note";
import {
  ArrowRight,
  Check,
  Download,
  ImagePlus,
  Info,
  LoaderCircle,
  LockKeyhole,
  MessageCircle,
  RotateCcw,
  Search,
  ShieldCheck,
  Upload,
  X,
} from "lucide-react";
import { analyzeRisk, assessmentLabel, type Assessment } from "@/lib/analysis";
import {
  downloadText,
  redactSensitive,
  remember,
  safeScan,
  SAVE_KEY,
} from "@/lib/storage";
import {
  MAX_OCR_TEXT,
  OCR_ASSET_ROOT,
  declaredDimensions,
  reviewedText,
  screenshotMime,
  validateDimensions,
} from "@/lib/screenshot";

type SelectedImage = { file: File; url: string; width: number; height: number };
type ScreenshotReport = { text: string; assessment: Assessment };

export default function ScreenshotScanner() {
  const [image, setImage] = useState<SelectedImage | null>(null);
  const [text, setText] = useState("");
  const [report, setReport] = useState<ScreenshotReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [choosing, setChoosing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [dragging, setDragging] = useState(false);
  const [save, setSave] = useState(false);
  const [receiptMode, setReceiptMode] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const reviewRef = useRef<HTMLTextAreaElement>(null);
  const workerRef = useRef<OCRWorker | null>(null);
  const jobRef = useRef(0);
  const selectRef = useRef(0);
  const previewRef = useRef("");
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    try {
      setSave(localStorage.getItem(SAVE_KEY) === "true");
    } catch {}
    return () => {
      mounted.current = false;
      selectRef.current++;
      jobRef.current++;
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
      const worker = workerRef.current;
      workerRef.current = null;
      worker?.terminate().catch(() => {});
    };
  }, []);

  function stop() {
    jobRef.current++;
    const worker = workerRef.current;
    workerRef.current = null;
    worker?.terminate().catch(() => {});
    setBusy(false);
    setPhase("");
    setProgress(0);
  }
  function clear() {
    selectRef.current++;
    stop();
    if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    previewRef.current = "";
    setImage(null);
    setText("");
    setReport(null);
    setReceiptMode(false);
    setError("");
    setNotice("");
    setChoosing(false);
    if (fileInput.current) fileInput.current.value = "";
  }

  async function choose(file: File) {
    if (busy) return;
    const selection = ++selectRef.current;
    setError("");
    setNotice("");
    setChoosing(true);
    try {
      const bytes = new Uint8Array(await file.slice(0, 12).arrayBuffer());
      const mime = screenshotMime(file.size, bytes);
      const fullBytes = new Uint8Array(await file.arrayBuffer());
      const declared = declaredDimensions(fullBytes, mime);
      if (!declared)
        throw new Error(
          "This image has an unreadable header. Try another screenshot.",
        );
      validateDimensions(declared.width, declared.height);
      const normalized = new File([file], file.name, { type: mime });
      const bitmap = await createImageBitmap(normalized);
      const { width, height } = bitmap;
      bitmap.close();
      validateDimensions(width, height);
      if (selection !== selectRef.current || !mounted.current) return;
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
      const url = URL.createObjectURL(normalized);
      previewRef.current = url;
      setImage({ file: normalized, url, width, height });
      setText("");
      setReport(null);
      setReceiptMode(false);
      setPhase("");
      setProgress(0);
    } catch (e) {
      if (selection === selectRef.current && mounted.current)
        setError(
          e instanceof Error
            ? e.message
            : "This image could not be opened. Try another screenshot.",
        );
    } finally {
      if (selection === selectRef.current && mounted.current)
        setChoosing(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  async function demo() {
    if (busy || choosing) return;
    setError("");
    setChoosing(true);
    const demoSelection = ++selectRef.current;
    try {
      const response = await fetch("/examples/scam-message.png");
      if (!response.ok)
        throw Error(
          "The example could not be loaded. Choose your own screenshot.",
        );
      const blob = await response.blob();
      if (demoSelection !== selectRef.current || !mounted.current) return;
      await choose(
        new File([blob], "demo-bank-message.png", { type: "image/png" }),
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load the example.");
      setChoosing(false);
    }
  }

  async function extract() {
    if (!image || busy || choosing) return;
    const id = ++jobRef.current;
    setBusy(true);
    setProgress(0);
    setPhase("Preparing text reader");
    setError("");
    setNotice("");
    setReport(null);
    let worker: OCRWorker | null = null;
    const current = () => mounted.current && id === jobRef.current;
    try {
      const { createWorker, OEM } = await import("tesseract.js");
      if (!current()) return;
      worker = await createWorker("eng", OEM.LSTM_ONLY, {
        workerPath: `${OCR_ASSET_ROOT}/worker.min.js`,
        corePath: `${OCR_ASSET_ROOT}/core`,
        langPath: `${OCR_ASSET_ROOT}/lang`,
        workerBlobURL: false,
        cacheMethod: "none",
        gzip: true,
        logger: (m) => {
          if (!current()) return;
          if (m.status === "recognizing text") {
            setPhase("Reading screenshot text");
            setProgress(
              Math.max(0, Math.min(100, Math.round(m.progress * 100))),
            );
          } else if (m.status.includes("language"))
            setPhase("Loading English text model");
          else if (m.status.includes("core"))
            setPhase("Starting local recognition engine");
        },
      });
      if (!current()) return;
      workerRef.current = worker;
      const result = await worker.recognize(image.file);
      if (!current()) return;
      const extracted = reviewedText(result.data.text);
      if (!extracted) {
        setError(
          "No readable text was found. Try a sharper image, crop to the message, or type the text below.",
        );
        return;
      }
      setText(extracted);
      setProgress(100);
      setPhase("Text ready for review");
      setNotice(
        result.data.text.trim().length > MAX_OCR_TEXT
          ? "Only the first 10,000 characters were kept. Crop to the relevant message for a complete check."
          : "Text extracted locally. Review words, numbers, and links before checking.",
      );
      requestAnimationFrame(() =>
        reviewRef.current?.focus({ preventScroll: true }),
      );
    } catch {
      if (current())
        setError(
          "Text extraction could not finish. Retry, use a smaller image, or paste the message into the review box. No scam assessment was generated.",
        );
    } finally {
      if (workerRef.current === worker) workerRef.current = null;
      await worker?.terminate().catch(() => {});
      if (current()) setBusy(false);
    }
  }

  function check() {
    const content = reviewedText(text);
    if (!content || busy) return;
    const assessment = analyzeRisk(content, "message", {
      paymentReceipt: receiptMode,
    });
    setReport({ text: content, assessment });
    const stored = remember(
      safeScan(content, "message", assessment, "screenshot"),
      save,
    );
    setNotice(
      stored
        ? save
          ? "Redacted message summary saved to history. The screenshot was not saved."
          : "Redacted findings are available to the assistant during this session. The screenshot was not saved."
        : "This browser could not store a summary. The assessment still works.",
    );
    setError("");
  }

  return (
    <main className="main-wrap subpage" id="main-content">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />
            FROM SCREENSHOT TO UNDERSTANDING
          </span>
          <h1>
            Read between <span>the pixels.</span>
          </h1>
          <p>
            Add a screenshot. Review the text. Check the request.
            <br />
            The image is processed locally in your browser.
          </p>
        </div>
        <span className="page-emblem">
          <ImagePlus size={34} strokeWidth={1.3} />
        </span>
      </div>
      <div className="screenshot-steps" aria-label="Screenshot workflow">
        <span className={image ? "done" : ""}>
          <span>01</span>Choose image
        </span>
        <i />
        <span className={text ? "done" : ""}>
          <span>02</span>Review text
        </span>
        <i />
        <span className={report ? "done" : ""}>
          <span>03</span>Check the signs
        </span>
      </div>
      <div className="receipt-scope-note">
        <Info size={19} aria-hidden="true" />
        <p>
          <strong>Checking a payment screenshot?</strong> This tool reads text.
          It cannot confirm a transfer or determine whether a receipt was
          edited. Check the actual credit in your own account.
        </p>
      </div>
      <div className="screenshot-workspace">
        <section className="screenshot-card" aria-labelledby="image-title">
          <div className="panel-heading">
            <div>
              <span className="section-label">YOUR SCREENSHOT</span>
              <h2 id="image-title">A clearer look at the message.</h2>
            </div>
            {image && (
              <button
                className="icon-button"
                aria-label="Remove screenshot"
                title="Remove screenshot"
                onClick={clear}
              >
                <X size={15} />
              </button>
            )}
          </div>
          <input
            ref={fileInput}
            type="file"
            className="sr-only"
            tabIndex={-1}
            aria-label="Choose screenshot file"
            accept="image/png,image/jpeg,image/webp"
            disabled={busy || choosing}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) choose(file);
            }}
          />
          {!image ? (
            <div
              className={`screenshot-dropzone ${dragging ? "dragging" : ""}`}
              tabIndex={0}
              aria-label="Drop or paste a screenshot here"
              onDragOver={(e) => {
                e.preventDefault();
                if (!busy && !choosing) setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragging(false);
                if (busy || choosing) return;
                const file = e.dataTransfer.files?.[0];
                if (file) choose(file);
              }}
              onPaste={(e) => {
                if (busy || choosing) return;
                const item = [...e.clipboardData.items].find((i) =>
                  i.type.startsWith("image/"),
                );
                const file = item?.getAsFile();
                if (file) {
                  e.preventDefault();
                  choose(file);
                }
              }}
            >
              <span className="upload-emblem">
                <Upload size={27} strokeWidth={1.4} />
              </span>
              <h3>Drop a screenshot here.</h3>
              <p>Or focus here and paste an image from your clipboard.</p>
              <button
                className="primary-button"
                disabled={busy || choosing}
                onClick={() => fileInput.current?.click()}
              >
                {choosing ? (
                  <LoaderCircle size={15} className="spin" />
                ) : (
                  <ImagePlus size={15} />
                )}{" "}
                Browse screenshot
              </button>
              <span>PNG, JPEG, WebP · Up to 5 MB · Printed English text</span>
            </div>
          ) : (
            <>
              <div className="screenshot-preview">
                <img
                  src={image.url}
                  alt="Your selected screenshot, kept in this browser"
                />
              </div>
              <div className="screenshot-file">
                <span>{image.file.name}</span>
                <span>
                  {image.width} × {image.height} ·{" "}
                  {(image.file.size / 1024).toFixed(0)} KB
                </span>
              </div>
              <div className="screenshot-controls">
                <button
                  className="secondary-button"
                  disabled={busy || choosing}
                  onClick={() => fileInput.current?.click()}
                >
                  <ImagePlus size={14} /> Change image
                </button>
                {busy ? (
                  <button
                    className="secondary-button"
                    onClick={() => {
                      stop();
                      setNotice("Extraction cancelled. You can try again.");
                    }}
                  >
                    <X size={14} /> Cancel extraction
                  </button>
                ) : (
                  <button
                    className="primary-button"
                    disabled={choosing}
                    onClick={extract}
                  >
                    {choosing ? (
                      <LoaderCircle className="spin" size={15} />
                    ) : (
                      <Search size={15} />
                    )}{" "}
                    {text ? "Read image again" : "Extract text"}
                  </button>
                )}
              </div>
            </>
          )}
          {busy && (
            <div className="ocr-progress" role="status">
              <span>
                <LoaderCircle size={14} className="spin" />
                {phase}
              </span>
              {phase === "Reading screenshot text" ? (
                <>
                  <progress
                    max={100}
                    value={progress}
                    aria-label="Text extraction progress"
                  />
                  <small>{progress}% of recognition</small>
                </>
              ) : (
                <p>
                  Loading local recognition assets. The first read may take
                  longer.
                </p>
              )}
            </div>
          )}
          <div className="screenshot-privacy">
            <LockKeyhole size={14} />
            <p>
              No image upload or AI key required. Recognition files are served
              by this app; the screenshot is read on your device.
            </p>
          </div>
          <button
            className="text-button demo-screenshot"
            disabled={busy || choosing}
            onClick={demo}
          >
            Try a demonstration screenshot
            <ArrowRight size={13} />
          </button>
        </section>
        <section
          className="screenshot-card review-card"
          aria-labelledby="review-title"
        >
          <div className="panel-heading">
            <div>
              <span className="section-label">REVIEW BEFORE CHECKING</span>
              <h2 id="review-title">Make sure the words are right.</h2>
            </div>
            <span className="step-number">02</span>
          </div>
          <p className="review-help">
            OCR can misread small text, numbers, or links. Correct the text
            below; only this reviewed text is assessed.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              check();
            }}
          >
            <label htmlFor="screenshot-text">Extracted message text</label>
            <textarea
              id="screenshot-text"
              ref={reviewRef}
              value={text}
              disabled={busy}
              maxLength={MAX_OCR_TEXT}
              onChange={(e) => {
                setText(e.target.value);
                setNotice("");
              }}
              placeholder="Extract text from a screenshot, or paste the message here…"
            />
            <div className="input-meta">
              <span>
                Review spellings, links, and requests for private details.
              </span>
              <span>{text.length.toLocaleString()} / 10,000</span>
            </div>
            <label className="receipt-preference">
              <input
                type="checkbox"
                checked={receiptMode}
                onChange={(event) => {
                  setReceiptMode(event.target.checked);
                  setReport(null);
                  setNotice("");
                }}
              />
              <span>
                <strong>This is a payment receipt</strong>
                <small>
                  Use this if OCR missed receipt labels. It will be treated as
                  unverified, even without suspicious wording.
                </small>
              </span>
            </label>
            <label className="save-preference">
              <input
                type="checkbox"
                checked={save}
                onChange={(e) => {
                  setSave(e.target.checked);
                  try {
                    localStorage.setItem(SAVE_KEY, String(e.target.checked));
                  } catch {}
                }}
              />{" "}
              Save a redacted text summary in my history
            </label>
            <CloudSaveNote />
            <div className="form-footer">
              <span>
                <ShieldCheck size={13} /> Image stays out of saved history
              </span>
              <button
                className="primary-button"
                disabled={!text.trim() || busy || choosing}
              >
                Check reviewed text
                <ArrowRight size={15} />
              </button>
            </div>
          </form>
          <div className="screenshot-tips">
            <strong>For a better read</strong>
            <ul>
              <li>Crop to one message and keep the text upright.</li>
              <li>Use a clear screenshot rather than a photo of a screen.</li>
              <li>
                Blur or remove sensitive details before choosing an image.
              </li>
            </ul>
          </div>
        </section>
      </div>
      {error && (
        <div className="screenshot-error" role="alert">
          <Info size={18} />
          <p>{error}</p>
        </div>
      )}
      {notice && (
        <p className="screenshot-notice" role="status">
          <Check size={14} />
          {notice}
        </p>
      )}
      {report && (
        <section
          className={`screenshot-assessment ${report.assessment.tone}`}
          aria-live="polite"
        >
          <div className="link-report-heading">
            <div>
              <span className="section-label">
                {report.assessment.kind === "payment_receipt"
                  ? "PAYMENT RECEIPT REVIEW"
                  : "REVIEWED TEXT ASSESSMENT"}
              </span>
              <h2>
                {report.assessment.kind === "payment_receipt"
                  ? "A screenshot is not proof of payment."
                  : "What the message asks you to do."}
              </h2>
              <p className="muted">
                This result checks text, not the sender, image authenticity, QR
                contents, or attachments.
              </p>
            </div>
            <span className="risk-badge">
              <span />
              {assessmentLabel(report.assessment)}
            </span>
          </div>
          {reviewedText(text) !== report.text && (
            <p className="changed-notice">
              The reviewed text has changed. Check it again to update these
              findings.
            </p>
          )}
          {report.assessment.score !== null && (
            <div
              className="risk-track"
              role="meter"
              aria-label="Screenshot message risk score"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={report.assessment.score}
            >
              <span style={{ width: `${report.assessment.score}%` }} />
            </div>
          )}
          {report.assessment.kind === "payment_receipt" && (
            <div className="receipt-verification">
              <Info size={22} aria-hidden="true" />
              <div>
                <strong>Payment status: unverified</strong>
                <p>
                  We have not checked bank records or image authenticity. A
                  genuine receipt and an edited receipt can contain exactly the
                  same words.
                </p>
                <a
                  href="https://paytm.com/faqs/upi/how-to-identify-a-fake-transaction"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Read payment verification guidance <ArrowRight size={14} />
                </a>
              </div>
            </div>
          )}
          <p className="screenshot-summary">{report.assessment.summary}</p>
          <div className="url-flags">
            {report.assessment.signals.length ? (
              report.assessment.signals.map((signal, i) => (
                <article key={signal.title}>
                  <span className="flag-number">
                    {signal.type === "context" ? (
                      <Info size={15} />
                    ) : signal.type === "safety" ? (
                      <Check size={15} />
                    ) : (
                      i + 1
                    )}
                  </span>
                  <div>
                    <h3>{signal.title}</h3>
                    <p>{signal.description}</p>
                    {signal.excerpt && (
                      <blockquote>“{signal.excerpt}”</blockquote>
                    )}
                  </div>
                </article>
              ))
            ) : (
              <article>
                <span className="flag-number">
                  <Check size={15} />
                </span>
                <div>
                  <h3>No strong text patterns matched</h3>
                  <p>
                    A clean-looking message is not proof of authenticity.
                    Independently verify unexpected requests.
                  </p>
                </div>
              </article>
            )}
          </div>
          <div className="link-result-actions">
            <Link href="/assistant" className="secondary-button">
              <MessageCircle size={14} /> Ask about this check
            </Link>
            <Link href="/recover" className="secondary-button">
              I already responded
              <ArrowRight size={14} />
            </Link>
            <button
              className="secondary-button"
              onClick={() => {
                const saved = safeScan(
                  report.text,
                  "message",
                  report.assessment,
                );
                downloadText(
                  "scamshield-screenshot-report.txt",
                  `ScamShield screenshot text assessment\n${assessmentLabel(saved.assessment)}\n\n${saved.assessment.summary}\n\nReviewed text (automatically redacted):\n${redactSensitive(report.text)}\n\n${saved.assessment.signals.map((s) => `${s.title}: ${s.description}${s.excerpt ? `\nExcerpt: ${s.excerpt}` : ""}`).join("\n\n")}\n\nOCR text was reviewed by the user. The image was not saved. Pattern-based guidance only; image and sender authenticity are unverified.`,
                );
              }}
            >
              <Download size={14} /> Download report
            </button>
          </div>
        </section>
      )}
      <div className="assistant-footnote">
        <Info size={14} />
        <p>
          Printed English is supported in this version. Handwriting, mixed
          scripts, and stylized or low-resolution images may be misread. This is
          text extraction and pattern checking, not image forensics or QR
          decoding. Closing or removing the screenshot releases this page’s
          preview; only explicitly saved redacted text summaries persist.
        </p>
      </div>
    </main>
  );
}
