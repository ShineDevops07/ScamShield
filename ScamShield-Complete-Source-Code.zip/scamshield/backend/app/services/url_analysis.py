import ipaddress
import re
from typing import List, Tuple
from urllib.parse import urlparse, unquote

from app.schemas.responses import RiskLevelEnum, URLInspectionResponse


# Popular shorteners used to obfuscate destinations
KNOWN_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "buff.ly",
    "ow.ly", "cutt.ly", "rb.gy", "rebrand.ly", "shorturl.at"
}

# High-profile brand targets for phishing/typosquatting detection
TARGET_BRANDS = [
    ("hdfc", ["hfdc", "hdfcbank-login", "hdfc-kyc", "hdfc-support", "hdfcnetbanking"]),
    ("sbi", ["onlinesbi-kyc", "sbi-verification", "sbi-card-update", "statebank-kyc"]),
    ("icici", ["icici-rewards", "icicibank-update", "icici-login"]),
    ("paytm", ["paytm-kyc", "paytm-cashback", "paytm-rewards"]),
    ("google", ["googel", "g00gle", "google-security-notice"]),
    ("amazon", ["amazn", "amazon-delivery-update", "amazon-security"]),
    ("netflix", ["netflx", "netflix-billing-update"]),
    ("apple", ["apple-id-verify", "apple-support-login"]),
    ("customs", ["customs-clearance-fee", "customs-penalty-pay"]),
    ("courier", ["fedex-tracking-penalty", "dhl-clearance-pay"]),
]

SUSPICIOUS_TLDS = {
    ".xyz", ".top", ".tk", ".ml", ".ga", ".cf", ".gq", ".work",
    ".click", ".loan", ".support", ".rest", ".fit", ".icu"
}


def analyze_url_safety(raw_url: str) -> URLInspectionResponse:
    """
    Performs safe static inspection of a URL without making outbound network requests.
    Detects IP hostnames, lookalike domains, punycode, excessive subdomains, userinfo tricks, and shorteners.
    """
    cleaned = raw_url.strip()
    if not cleaned.startswith(("http://", "https://")):
        # Prepend https for parsing if omitted
        normalized_url = "https://" + cleaned
    else:
        normalized_url = cleaned

    try:
        parsed = urlparse(normalized_url)
    except Exception as e:
        return URLInspectionResponse(
            url=raw_url,
            normalized_url=normalized_url,
            scheme="unknown",
            hostname="unknown",
            domain="unknown",
            is_ip_address=False,
            has_userinfo=False,
            is_punycode=False,
            subdomain_count=0,
            is_known_shortener=False,
            lookalike_indicators=[],
            suspicious_indicators=[f"Invalid URL structure: {str(e)}"],
            threat_intel_status="unverified",
            risk_score=75,
            risk_level=RiskLevelEnum.HIGH,
            verdict="Malformed URL syntax with high risk of deception.",
            safe_navigation_guidance=["Do not open or navigate to malformed URLs."],
            limitations=["Static syntax analysis only; no external network queries performed."],
        )

    scheme = parsed.scheme.lower()
    hostname = (parsed.hostname or "").lower()
    userinfo = parsed.username or parsed.password
    has_userinfo = bool(userinfo)

    is_ip_address = False
    try:
        ipaddress.ip_address(hostname)
        is_ip_address = True
    except ValueError:
        is_ip_address = False

    is_punycode = "xn--" in hostname
    is_known_shortener = hostname in KNOWN_SHORTENERS

    # Split domain and subdomains
    parts = hostname.split(".")
    subdomain_count = max(0, len(parts) - 2)
    domain = ".".join(parts[-2:]) if len(parts) >= 2 else hostname

    suspicious_indicators: List[str] = []
    lookalike_indicators: List[str] = []
    risk_score = 10

    # 1. Scheme checks
    if scheme == "http":
        suspicious_indicators.append("Unencrypted HTTP protocol used for link.")
        risk_score += 15

    # 2. IP Hostname Check
    if is_ip_address:
        suspicious_indicators.append(f"Direct IP address host ({hostname}) used instead of a registered domain name.")
        risk_score += 45

    # 3. Userinfo Obfuscation Check (e.g., http://trusted.com@evil.com)
    if has_userinfo:
        suspicious_indicators.append("URL contains embedded userinfo/credentials (@), frequently used to visually spoof authentic domains.")
        risk_score += 45

    # 4. Punycode / IDN Homograph
    if is_punycode:
        suspicious_indicators.append(f"Punycode encoding detected ({hostname}), often used in homograph attacks to mimic legitimate character sets.")
        risk_score += 40

    # 5. Excessive Subdomains Check
    if subdomain_count >= 3:
        suspicious_indicators.append(f"Excessive subdomain nesting ({subdomain_count} subdomains), common in phishing kits targeting mobile screens.")
        risk_score += 25

    # 6. Suspicious / High-Abuse TLDs
    for tld in SUSPICIOUS_TLDS:
        if hostname.endswith(tld):
            suspicious_indicators.append(f"Domain registered under high-abuse TLD ({tld}).")
            risk_score += 25
            break

    # 7. URL Shortener Detection
    if is_known_shortener:
        suspicious_indicators.append(f"Known URL shortener ({hostname}) masks true final destination.")
        risk_score += 30

    # 8. Target Brand Impersonation / Typosquatting
    full_target_string = hostname + (parsed.path or "")
    for brand, variants in TARGET_BRANDS:
        for variant in variants:
            if variant in full_target_string and not hostname.endswith(f"{brand}.com"):
                lookalike_indicators.append(f"Brand spoofing indicator: '{variant}' targets '{brand.upper()}'.")
                risk_score += 40
                break

    # Path keywords check
    lower_path = parsed.path.lower()
    if re.search(r'\b(login|signin|kyc|verify|update-card|bank|account|security-check)\.php\b', lower_path):
        suspicious_indicators.append(f"Phishing script/path pattern detected: '{parsed.path}'")
        risk_score += 25

    # Clamp risk score
    risk_score = max(5, min(95, risk_score))

    if risk_score >= 80:
        risk_level = RiskLevelEnum.CRITICAL
        verdict = "Dangerous URL exhibiting multiple phishing, obfuscation, or spoofing vectors."
    elif risk_score >= 50:
        risk_level = RiskLevelEnum.HIGH
        verdict = "Suspicious URL with high probability of deception or hidden destination."
    elif risk_score >= 20:
        risk_level = RiskLevelEnum.CAUTION
        verdict = "URL displays cautionary traits (shortener, HTTP, or ambiguous domain)."
    else:
        risk_level = RiskLevelEnum.LOW
        verdict = "Clean standard URL syntax. No overt obfuscation or brand impersonation detected."

    safe_navigation_guidance = [
        "Never enter banking passwords, OTPs, or debit card PINs on links received via unsolicited SMS or WhatsApp.",
        "Instead of clicking links, open your browser independently and type the verified official domain of the organization.",
        "If a link uses a shortener, verify its unshortened destination with an offline inspection tool before proceeding.",
    ]

    limitations = [
        "Static heuristics and syntax analysis only. Outbound network requests to the target server are intentionally not made for safety.",
        "A syntactically clean domain is not proof of safety, nor does absence of a blacklist record guarantee authenticity.",
    ]

    return URLInspectionResponse(
        url=raw_url,
        normalized_url=normalized_url,
        scheme=scheme,
        hostname=hostname,
        domain=domain,
        is_ip_address=is_ip_address,
        has_userinfo=has_userinfo,
        is_punycode=is_punycode,
        subdomain_count=subdomain_count,
        is_known_shortener=is_known_shortener,
        lookalike_indicators=lookalike_indicators,
        suspicious_indicators=suspicious_indicators,
        threat_intel_status="unavailable (no live threat intel API key configured)",
        risk_score=risk_score,
        risk_level=risk_level,
        verdict=verdict,
        safe_navigation_guidance=safe_navigation_guidance,
        limitations=limitations,
    )
