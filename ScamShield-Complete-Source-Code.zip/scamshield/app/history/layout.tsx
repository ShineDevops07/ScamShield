import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Your check history | ScamShield",
  description:
    "Review, search, export, or remove the redacted check summaries saved on your device.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
