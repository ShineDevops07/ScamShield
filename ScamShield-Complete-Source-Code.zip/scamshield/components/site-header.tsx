"use client";
import Link from "next/link";
import AccountButton from "./account-button";
import { usePathname } from "next/navigation";
import { ArrowUpRight, ShieldCheck } from "lucide-react";
const items = [
  ["/", "Checker"],
  ["/screenshots", "Screenshots"],
  ["/audio", "Audio"],
  ["/assistant", "Safety assistant"],
  ["/links", "Link inspector"],
  ["/learn", "Learn"],
  ["/history", "History"],
  ["/pricing", "Plans"],
];
export default function SiteHeader() {
  const pathname = usePathname();
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link href="/" className="wordmark" aria-label="ScamShield home">
          <span className="brand-symbol">
            <ShieldCheck size={21} strokeWidth={1.7} />
          </span>
          ScamShield<span className="brand-period">.</span>
        </Link>
        <nav aria-label="Main navigation">
          {items.map(([href, label]) => (
            <Link
              key={href}
              href={href}
              className={pathname === href ? "nav-active" : ""}
              aria-current={pathname === href ? "page" : undefined}
            >
              {label}
            </Link>
          ))}
          <AccountButton className="account-nav" />
        </nav>
        <Link className="recovery-nav" href="/recover">
          Need help now?
          <ArrowUpRight size={13} />
        </Link>
      </div>
    </header>
  );
}
