from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class RiskLevelEnum(str, Enum):
    LOW = "low"
    CAUTION = "caution"
    HIGH = "high"
    CRITICAL = "critical"


class EvidenceTypeEnum(str, Enum):
    OBSERVED = "observed"
    INFERRED = "inferred"
    INDEPENDENTLY_VERIFIED = "independently_verified"


class SeverityEnum(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"
    POSITIVE = "Positive"


class AnalysisMethodEnum(str, Enum):
    AI_ASSISTED = "ai_assisted"
    RULES_BASED = "rules_based"
    HYBRID = "hybrid"


class EvidenceItem(BaseModel):
    description: str = Field(..., description="Short title of the finding")
    evidence_source: str = Field(..., description="Source where finding was observed (e.g., text, url, sender)")
    severity: SeverityEnum = Field(..., description="Severity or nature of signal")
    points: Optional[str] = Field(default=None, description="Score impact e.g., '+45', '-15'")
    excerpt: Optional[str] = Field(default=None, description="Direct text snippet from input if observed")
    explanation: str = Field(..., description="Detailed contextual reasoning for why this matters")
    evidence_type: EvidenceTypeEnum = Field(
        ...,
        description="Whether this is observed in text, inferred by logic/AI, or independently verified",
    )


class AnalyzeResponse(BaseModel):
    analysis_id: str = Field(..., description="Unique UUID for this analysis session")
    risk_score: int = Field(..., ge=0, le=100, description="Bounded risk score from 0 to 100")
    risk_level: RiskLevelEnum = Field(..., description="Categorical risk tier: low, caution, high, critical")
    confidence: str = Field(..., description="Calibrated confidence level with explanation: low, medium, high")
    verdict: str = Field(..., description="Concise assessment statement")
    summary: str = Field(..., description="Short explanation of the assessment and primary driver")
    detected_categories: List[str] = Field(default_factory=list, description="Categories of fraud or safety detected")
    evidence: List[EvidenceItem] = Field(default_factory=list, description="Structured list of findings")
    red_flags: List[str] = Field(default_factory=list, description="Specific suspicious warning signs")
    reassuring_signals: List[str] = Field(default_factory=list, description="Contextual protective or legitimate factors")
    recommended_actions: List[str] = Field(default_factory=list, description="Actionable safe next steps for user")
    what_not_to_do: List[str] = Field(default_factory=list, description="Dangerous actions to strictly avoid")
    uncertainty: List[str] = Field(default_factory=list, description="Missing information or open ambiguities")
    verification_steps: List[str] = Field(default_factory=list, description="Independent steps to verify claims safely")
    analysis_method: AnalysisMethodEnum = Field(..., description="Actual analysis technique executed")
    limitations: List[str] = Field(default_factory=list, description="Disclaimers and assessment boundaries")

    # Frontend compatibility fields
    score: Optional[int] = None
    riskBand: Optional[str] = None
    signals: Optional[List[Dict[str, Any]]] = None
    aiAnalysis: Optional[Dict[str, Any]] = None
    recommendedAction: Optional[str] = None
    verificationStatus: Optional[str] = None
    disclaimer: Optional[str] = None


class URLInspectionResponse(BaseModel):
    url: str
    normalized_url: str
    scheme: str
    hostname: str
    domain: str
    is_ip_address: bool
    has_userinfo: bool
    is_punycode: bool
    subdomain_count: int
    is_known_shortener: bool
    lookalike_indicators: List[str] = Field(default_factory=list)
    suspicious_indicators: List[str] = Field(default_factory=list)
    threat_intel_status: str
    risk_score: int = Field(..., ge=0, le=100)
    risk_level: RiskLevelEnum
    verdict: str
    safe_navigation_guidance: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)


class FollowUpResponse(BaseModel):
    answer: str
    clarifications: List[str] = Field(default_factory=list)
    recommended_next_steps: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    unverified_assumptions: List[str] = Field(default_factory=list)


class EmergencyStep(BaseModel):
    step_number: int
    priority: str  # "IMMEDIATE", "HIGH", "FOLLOW_UP"
    action: str
    details: str
    contact_or_resource: Optional[str] = None


class EmergencyResponse(BaseModel):
    scenario: str
    summary: str
    immediate_actions: List[EmergencyStep]
    reporting_channels: List[Dict[str, str]]
    evidence_to_preserve: List[str]
    recovery_reality_check: str


class CapabilitiesResponse(BaseModel):
    version: str
    environment: str
    ai_enabled: bool
    ai_provider: str
    threat_intel_enabled: bool
    image_analysis_enabled: bool
    supported_content_types: List[str]
    supported_scenarios: List[str]
    engineered_by: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    uptime_seconds: float
    timestamp: str
    engine: Optional[str] = None


class ErrorResponse(BaseModel):
    error_code: str
    message: str
    request_id: Optional[str] = None
    details: Optional[Any] = None
