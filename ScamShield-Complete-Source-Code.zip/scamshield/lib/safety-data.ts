export const resources = [
  {
    name: "National Cyber Crime Reporting Portal",
    url: "https://cybercrime.gov.in/",
    description:
      "Report cybercrime in India; financial cyber fraud helpline: 1930.",
  },
  {
    name: "NPCI fraud awareness",
    url: "https://www.npci.org.in/fraud-awareness",
    description: "Official guidance on UPI, QR code, and payment fraud.",
  },
  {
    name: "CERT-In",
    url: "https://www.cert-in.org.in/",
    description:
      "India’s national computer security advisories and awareness resources.",
  },
];
export const recoveryScenarios = [
  {
    id: "money",
    title: "I sent money",
    hint: "UPI, bank transfer, card, or wallet",
    icon: "money",
    steps: [
      [
        "Contact your bank or payment service",
        "Use the official app or a contact number you already trust. Ask to report the transaction and secure the affected account.",
      ],
      [
        "Report promptly",
        "In India, call 1930 for financial cyber fraud and use cybercrime.gov.in. Prompt reporting may help; recovery is not guaranteed.",
      ],
      [
        "Preserve transaction evidence",
        "Keep the transaction reference, date, amount, screenshots, and sender details. Do not alter the original messages.",
      ],
      [
        "Avoid recovery-fee scams",
        "Do not send another payment to someone promising to recover the loss.",
      ],
    ],
  },
  {
    id: "otp",
    title: "I shared an OTP or password",
    hint: "Security codes, PINs, or account credentials",
    icon: "key",
    steps: [
      [
        "Secure the affected account",
        "From a trusted device, use the official service to change the exposed password and sign out unknown sessions.",
      ],
      [
        "Contact the service provider",
        "If a bank or payment account is involved, contact its official fraud support and ask about restricting unauthorized activity.",
      ],
      [
        "Review other accounts",
        "Change reused passwords and enable multi-factor authentication where available. Do not share new codes.",
      ],
      [
        "Keep evidence and report losses",
        "Save the suspicious communication. If money was lost in India, contact 1930 and report through cybercrime.gov.in.",
      ],
    ],
  },
  {
    id: "link",
    title: "I clicked a link",
    hint: "Suspicious website, email, or message",
    icon: "link",
    steps: [
      [
        "Close the suspicious page",
        "Do not submit details, approve browser permissions, or download additional files.",
      ],
      [
        "Consider what you did next",
        "A click alone does not establish compromise. If you entered credentials, switch to the OTP/password checklist. If you installed a file, use the app-installation checklist.",
      ],
      [
        "Check the account through the official app",
        "Review recent sign-ins and security alerts without using the suspicious link.",
      ],
      [
        "Preserve the message",
        "Keep a copy of the original communication for your service provider or a report.",
      ],
    ],
  },
  {
    id: "app",
    title: "I installed an app or gave remote access",
    hint: "APK files, screen sharing, or control apps",
    icon: "device",
    steps: [
      [
        "End the remote session",
        "Stop screen sharing and disconnect the affected device from the internet if you suspect ongoing unauthorized control.",
      ],
      [
        "Use another trusted device",
        "Contact your bank or affected service from a separate device. Do not enter new credentials on a device you suspect is compromised.",
      ],
      [
        "Get trusted technical help",
        "Review and remove unfamiliar apps and permissions using official device guidance. A security professional can help assess whether further recovery is needed.",
      ],
      [
        "Review and report",
        "Check account activity and preserve evidence. Report any financial loss promptly through your bank and official channels.",
      ],
    ],
  },
  {
    id: "identity",
    title: "I shared identity documents",
    hint: "Aadhaar, PAN, or other personal records",
    icon: "id",
    steps: [
      [
        "Preserve what was shared",
        "Record which documents were sent, when, and to whom. Keep evidence without reposting the documents publicly.",
      ],
      [
        "Contact the issuing authority",
        "Use the authority’s official website or app to review available protections and report suspected misuse.",
      ],
      [
        "Watch for unexpected activity",
        "Check for unexplained account changes, service registrations, and messages about activity you did not initiate.",
      ],
      [
        "Report suspected misuse",
        "Use the official cybercrime portal or appropriate local authorities. Do not pay someone claiming they can erase or repair your identity records.",
      ],
    ],
  },
  {
    id: "threat",
    title: "I am being threatened or pressured",
    hint: "Impersonation, extortion, or blackmail",
    icon: "shield",
    steps: [
      [
        "Pause contact and seek support",
        "If you feel in immediate physical danger, contact local emergency services. Ask a trusted person to help you assess the situation.",
      ],
      [
        "Do not pay under pressure",
        "Sending money or more private material may lead to further demands. Avoid engaging with threats.",
      ],
      [
        "Preserve evidence",
        "Keep messages, usernames, call details, and screenshots. Do not circulate intimate or sensitive material.",
      ],
      [
        "Use official reporting channels",
        "Report the account to the platform and the incident to appropriate authorities or the cybercrime portal.",
      ],
    ],
  },
] as const;
