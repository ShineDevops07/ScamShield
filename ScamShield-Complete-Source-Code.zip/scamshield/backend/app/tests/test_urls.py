import pytest
from httpx import ASGITransport, AsyncClient
from app.core.security import is_ssrf_safe_url
from main import app


@pytest.mark.asyncio
async def test_phishing_lookalike_url_inspection():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "url": "https://hfdcbank-kyc-update-portal-netbanking.support/login.php"
        }
        res = await client.post("/api/v1/analyze-url", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert data["risk_score"] >= 60
        assert data["risk_level"] in ("high", "critical")
        assert any("hdfc" in ind.lower() for ind in data["lookalike_indicators"])


@pytest.mark.asyncio
async def test_shortener_url_inspection():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {"url": "http://bit.ly/mseb-quickpay"}
        res = await client.post("/api/v1/analyze-url", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert data["is_known_shortener"] is True
        assert data["risk_score"] >= 30


@pytest.mark.asyncio
async def test_legitimate_domain_url_inspection():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {"url": "https://www.onlinesbi.sbi/personal/login.html"}
        res = await client.post("/api/v1/analyze-url", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert data["risk_score"] < 40
        assert data["is_ip_address"] is False
        assert data["is_known_shortener"] is False


def test_ssrf_safe_url_guard():
    # Loopback
    is_safe, _ = is_ssrf_safe_url("http://127.0.0.1:8000/internal")
    assert is_safe is False

    is_safe, _ = is_ssrf_safe_url("http://localhost/admin")
    assert is_safe is False

    # Private IP
    is_safe, _ = is_ssrf_safe_url("http://192.168.1.1/router")
    assert is_safe is False

    is_safe, _ = is_ssrf_safe_url("http://10.0.0.5:8080/secret")
    assert is_safe is False

    # AWS/GCP Metadata
    is_safe, _ = is_ssrf_safe_url("http://169.254.169.254/latest/meta-data/")
    assert is_safe is False

    # Valid Public URL
    is_safe, _ = is_ssrf_safe_url("https://www.google.com/search")
    assert is_safe is True
