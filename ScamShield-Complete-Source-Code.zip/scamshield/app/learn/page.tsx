"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  BookOpen,
  Check,
  GraduationCap,
  Info,
  RotateCcw,
  ShieldCheck,
  X,
} from "lucide-react";
import { challenges, scamLibrary } from "@/lib/learning";
export default function Learn() {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [active, setActive] = useState(false);
  const [filter, setFilter] = useState("");
  const finished = index >= challenges.length;
  const challenge = challenges[Math.min(index, challenges.length - 1)];
  const answered = answers.length > index;
  const correct = answers.filter((a, i) => a === challenges[i].answer).length;
  const categories = scamLibrary.filter(([title, text]) =>
    `${title} ${text}`.toLowerCase().includes(filter.toLowerCase()),
  );
  return (
    <main id="main-content" className="main-wrap subpage">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />
            AWARENESS IS A SKILL
          </span>
          <h1>
            Build your <span>scam radar.</span>
          </h1>
          <p>
            Practice on everyday situations. Learn the reasoning, not just the
            verdict.
          </p>
        </div>
        <span className="page-emblem">
          <GraduationCap size={36} strokeWidth={1.3} />
        </span>
      </div>
      <section className="quiz-card">
        <div className="quiz-intro">
          <span className="section-label">THE SIX-MESSAGE CHALLENGE</span>
          <h2>
            Can you spot
            <br />
            the pressure?
          </h2>
          <p>
            Some messages are ordinary. Others use fear, easy money, or
            reassuring language to hide a risky request.
          </p>
          <span className="quiz-meta">
            <BookOpen size={14} /> 6 situations · Around 2 minutes
          </span>
          <span className="quiz-privacy">Your answers stay on this page.</span>
        </div>
        <div className="quiz-workspace">
          {!active ? (
            <div className="quiz-start">
              <span className="welcome-shield">
                <ShieldCheck size={32} />
              </span>
              <h3>
                Trust your judgment.
                <br />
                Then check the reasoning.
              </h3>
              <p>
                Choose “Warning signs” or “Looks routine.”
                <br />
                Both answers come with an explanation.
              </p>
              <button
                className="primary-button"
                onClick={() => setActive(true)}
              >
                Start challenge
                <ArrowRight size={15} />
              </button>
            </div>
          ) : finished ? (
            <div className="quiz-complete">
              <span className="welcome-shield">
                <Check size={32} />
              </span>
              <span className="section-label">CHALLENGE COMPLETE</span>
              <h3>
                {correct} <span>of {challenges.length}</span>
              </h3>
              <p>
                {correct === challenges.length
                  ? "You picked out every pattern in this practice set. Keep verifying real-world requests."
                  : "Good practice. Review the explanations to sharpen your next decision."}
              </p>
              <div className="quiz-recap">
                {challenges.map((q, i) => (
                  <details key={q.category}>
                    <summary>
                      {answers[i] === q.answer ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}{" "}
                      {q.category}
                    </summary>
                    <p>{q.why}</p>
                  </details>
                ))}
              </div>
              <button
                className="secondary-button"
                onClick={() => {
                  setIndex(0);
                  setAnswers([]);
                  setActive(false);
                }}
              >
                <RotateCcw size={14} /> Try again
              </button>
            </div>
          ) : (
            <>
              <div className="quiz-progress">
                <span>
                  Situation {index + 1} of {challenges.length}
                </span>
                <span>{challenge.category}</span>
              </div>
              <progress
                value={index + 1}
                max={challenges.length}
                aria-label="Challenge progress"
              />
              <blockquote className="challenge-message" key={index}>
                “{challenge.message}”
              </blockquote>
              <div className="quiz-choices">
                <button
                  disabled={answered}
                  aria-pressed={answers[index] === "warning"}
                  onClick={() => setAnswers([...answers, "warning"])}
                >
                  Warning signs
                  <Info size={15} />
                </button>
                <button
                  disabled={answered}
                  aria-pressed={answers[index] === "routine"}
                  onClick={() => setAnswers([...answers, "routine"])}
                >
                  Looks routine
                  <Check size={15} />
                </button>
              </div>
              {answered && (
                <div
                  className={`quiz-explanation ${answers[index] === challenge.answer ? "correct" : "review"}`}
                  role="status"
                >
                  <strong>
                    {answers[index] === challenge.answer
                      ? "You spotted the pattern."
                      : "A useful distinction."}
                  </strong>
                  <p>{challenge.why}</p>
                  <button
                    className="text-button"
                    onClick={() => setIndex(index + 1)}
                  >
                    {index === challenges.length - 1
                      ? "See my results"
                      : "Next situation"}
                    <ArrowRight size={14} />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </section>
      <section className="library-section">
        <div className="section-heading">
          <div>
            <span className="section-label">PATTERN LIBRARY</span>
            <h2>Know what to look for.</h2>
          </div>
          <label className="search-field">
            <BookOpen size={14} />
            <input
              placeholder="Find a scam pattern…"
              aria-label="Search scam patterns"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </label>
        </div>
        <div className="library-grid">
          {categories.map(([title, text, action], i) => (
            <article key={title}>
              <span className="section-label">
                PATTERN 0{scamLibrary.findIndex((c) => c[0] === title) + 1}
              </span>
              <h3>{title}</h3>
              <p>{text}</p>
              <div>
                <ShieldCheck size={14} />
                <span>{action}</span>
              </div>
            </article>
          ))}
        </div>
        {!categories.length && (
          <p className="muted">
            No matching patterns. Try “OTP”, “link”, or “job”.
          </p>
        )}
      </section>
      <div className="learning-cta">
        <div>
          <h2>Have a real message to check?</h2>
          <p>Put the patterns into practice with your own content.</p>
        </div>
        <Link href="/" className="primary-button">
          Open checker
          <ArrowRight size={15} />
        </Link>
      </div>
    </main>
  );
}
