import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Audio transcription | ScamShield",
  description:
    "Turn an MP3 or WAV recording into editable text, then review it for common scam requests.",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
