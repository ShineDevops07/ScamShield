"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import CloudSaveNote from "@/components/cloud-save-note";
import {
  ArrowRight,
  Check,
  Copy,
  LoaderCircle,
  Sparkles,
  X,
  Globe2,
  Info,
  Link2,
  Search,
  ShieldCheck,
} from "lucide-react";
import { inspectLink, type LinkInspection } from "@/lib/url-inspector";
import {
  isLinkReview,
  reviewableUrl,
  verdictLabels,
  type LinkReview,
} from "@/lib/link-review";
import { remember, safeScan } from "@/lib/storage";
export default function LinksPage() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<LinkInspection | null>(null);
  const [status, setStatus] = useState("");
  const [save, setSave] = useState(false);
  const [checked, setChecked] = useState("");
  const [aiAvailable, setAiAvailable] = useState<boolean | null>(null);
  const [review, setReview] = useState<LinkReview | null>(null);
  const [reviewError, setReviewError] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const activeReview = useRef<AbortController | null>(null);
  const generation = useRef(0);
  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/links/review", { signal: controller.signal, cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!controller.signal.aborted)
          setAiAvailable(data?.available === true);
      })
      .catch(() => {
        if (!controller.signal.aborted) setAiAvailable(false);
      });
    return () => {
      controller.abort();
      activeReview.current?.abort();
      generation.current++;
    };
  }, []);
  function cancelReview() {
    generation.current++;
    activeReview.current?.abort();
    activeReview.current = null;
    setReviewing(false);
  }
  function resetReview() {
    cancelReview();
    setReview(null);
    setReviewError("");
  }
  const samples = [
    ["Lookalike bank", "https://hfdcbank-kyc.support/login"],
    ["Hidden host", "https://bank.example@unfamiliar-site.xyz/verify"],
    ["Short link", "https://bit.ly/parcel-update"],
    ["Plain domain", "https://example.com"],
  ];
  function inspect(persist = true) {
    resetReview();
    if (!url.trim()) return;
    const r = inspectLink(url);
    setResult(r);
    setChecked(url.trim());
    setStatus("");
    if (r.valid) {
      const assessment = {
        score: r.score,
        risk:
          r.score >= 60
            ? "High risk"
            : r.score >= 25
              ? "Use caution"
              : "Low risk",
        tone:
          r.score >= 60
            ? ("danger" as const)
            : r.score >= 25
              ? ("warning" as const)
              : ("safe" as const),
        summary:
          "Static link inspection. The destination was not visited or verified.",
        signals: r.flags.map((f) => ({
          title: f.title,
          description: f.detail,
          excerpt: "",
          points: "",
          severity: "Context" as const,
          type: "context" as const,
        })),
      };
      const scan = safeScan(url, "url", assessment);
      if (!persist) {
        remember(scan, false);
        return scan;
      }
      const stored = remember(scan, save);
      setStatus(
        stored
          ? save
            ? "Redacted link summary saved on this device."
            : "Link findings are available to the assistant during this session."
          : "The check is ready, but browser storage is unavailable.",
      );
    }
  }
  async function reviewWithAi() {
    const content = url.trim(),
      saveAtStart = save;
    const scan = inspect(false);
    if (!scan) return;
    let target: string;
    try {
      target = reviewableUrl(content);
    } catch (e) {
      setReviewError(
        e instanceof Error ? e.message : "Use a public website link.",
      );
      return;
    }
    const controller = new AbortController(),
      current = ++generation.current;
    activeReview.current = controller;
    setReviewing(true);
    setReviewError("");
    setStatus("");
    try {
      const response = await fetch("/api/links/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: content }),
        signal: AbortSignal.any([
          controller.signal,
          AbortSignal.timeout(55000),
        ]),
      });
      const data = await response.json();
      if (generation.current !== current) return;
      if (!response.ok)
        throw Error(
          typeof data.error === "string"
            ? data.error
            : "AI review could not finish.",
        );
      if (!isLinkReview(data.review) || data.review.reviewedUrl !== target)
        throw Error(
          "AI review returned an incomplete answer. This page has not been verified.",
        );
      const checked: LinkReview = data.review;
      setReview(checked);
      const assessment = {
        ...scan.assessment,
        aiReview: {
          verdict: checked.verdict,
          summary: checked.summary,
          findings: checked.findings,
          pageRead: checked.pageRead,
          checkedAt: checked.checkedAt,
        },
      };
      const stored = remember(
        safeScan(content, "url", assessment),
        saveAtStart,
      );
      setStatus(
        stored
          ? saveAtStart
            ? "Basic findings and a redacted AI summary saved to history."
            : "Redacted findings are available during this session."
          : "Review complete. Browser history could not be saved.",
      );
    } catch (e) {
      if (generation.current === current && !controller.signal.aborted)
        setReviewError(
          e instanceof Error
            ? e.message
            : "AI review could not finish. The page has not been verified.",
        );
    } finally {
      if (generation.current === current) {
        setReviewing(false);
        activeReview.current = null;
      }
    }
  }
  return (
    <main id="main-content" className="main-wrap subpage">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />
            LOOK PAST THE FAMILIAR NAME
          </span>
          <h1>
            Where does <span>that link lead?</span>
          </h1>
          <p>
            Inspect the link’s structure, or ask AI to read the public page and
            explain what deserves a closer look.
          </p>
        </div>
        <span className="page-emblem">
          <Globe2 size={34} strokeWidth={1.3} />
        </span>
      </div>
      <div className="link-layout">
        <section className="plan-card link-input-card">
          <span className="section-label">LINK INSPECTION & AI REVIEW</span>
          <h2>A closer look before you click.</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!reviewing) {
                if (aiAvailable) void reviewWithAi();
                else inspect();
              }
            }}
          >
            <label htmlFor="inspect-url">Website link</label>
            <div className="inline-form">
              <input
                id="inspect-url"
                maxLength={2048}
                value={url}
                onChange={(e) => {
                  resetReview();
                  setUrl(e.target.value);
                }}
                placeholder="https://example.com"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => inspect()}
                className="secondary-button"
                disabled={!url.trim() || reviewing}
              >
                <Search size={15} /> Inspect
              </button>
            </div>
            <div className="link-ai-actions">
              <button
                type="button"
                className="primary-button"
                disabled={!url.trim() || reviewing || aiAvailable === false}
                onClick={reviewWithAi}
              >
                {reviewing ? (
                  <LoaderCircle size={16} className="spin" />
                ) : (
                  <Sparkles size={16} />
                )}
                {reviewing ? "Reading page…" : "Review with AI"}
              </button>
              {reviewing && (
                <button
                  type="button"
                  className="secondary-button"
                  onClick={() => {
                    cancelReview();
                    setReviewError(
                      "AI review cancelled. No AI result was saved.",
                    );
                  }}
                >
                  <X size={15} />
                  Cancel review
                </button>
              )}
            </div>
            <p className="link-ai-disclosure">
              AI review sends this public link to Google Gemini, which may
              retrieve the page. Avoid private or one-time links.{" "}
              {aiAvailable === false
                ? "AI review is not connected yet; basic inspection works now."
                : "The result can identify warning signs, but cannot guarantee legitimacy."}
            </p>
            <label className="cloud-toggle">
              <input
                type="checkbox"
                disabled={reviewing}
                checked={save}
                onChange={(e) => setSave(e.target.checked)}
              />
              <span>Save a redacted link summary in my history</span>
            </label>
            <CloudSaveNote />
          </form>
          <div className="link-samples">
            <span>Try a pattern</span>
            {samples.map(([label, value]) => (
              <button
                key={label}
                onClick={() => {
                  resetReview();
                  setUrl(value);
                  setResult(null);
                  setChecked("");
                  setStatus("");
                }}
              >
                {label}
                <ArrowRight size={11} />
              </button>
            ))}
          </div>
          <p className="small-note">
            <ShieldCheck size={13} /> Basic inspection stays on your device.
            Only “Review with AI” requests a page-content review.
          </p>
        </section>
        <aside className="tip-card">
          <Link2 size={22} />
          <h3>Read the host, not the promise.</h3>
          <p>
            A familiar bank name before an <code>@</code>, or at the start of a
            long subdomain, can hide a different destination.
          </p>
          <Link href="/learn">
            Learn the patterns
            <ArrowRight size={14} />
          </Link>
        </aside>
      </div>
      {(reviewing || reviewError || review) && (
        <section
          className="link-ai-report"
          aria-label="AI page review"
          aria-busy={reviewing}
        >
          <div className="link-ai-heading">
            <div>
              <span className="section-label">AI PAGE REVIEW</span>
              <h2>
                {reviewing
                  ? "Looking beyond the address…"
                  : review
                    ? verdictLabels[review.verdict]
                    : "Page review unavailable"}
              </h2>
            </div>
            {review && (
              <span
                className={`risk-badge ${review.verdict === "suspicious" ? "warning" : "neutral"}`}
              >
                {review.pageRead
                  ? "Page content retrieved"
                  : "Page not verified"}
              </span>
            )}
          </div>
          {reviewing && (
            <p role="status">
              Gemini is being asked to retrieve the public page and assess its
              content. This may take a few moments.
            </p>
          )}
          {reviewError && (
            <p className="account-error" role="alert">
              {reviewError}
            </p>
          )}
          {review && (
            <>
              <p className="link-ai-summary">{review.summary}</p>
              <div className="link-ai-columns">
                <div>
                  <h3>What the review found</h3>
                  <ul>
                    {review.findings.map((finding, i) => (
                      <li key={i}>{finding}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>Before you act</h3>
                  <ul>
                    {review.nextSteps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="link-ai-evidence">
                <strong>
                  {review.pageRead
                    ? "Evidence used: submitted page content"
                    : "No confirmed page-content evidence"}
                </strong>
                <code>{review.reviewedUrl}</code>
                <span>
                  Google Gemini · {new Date(review.checkedAt).toLocaleString()}
                </span>
                <p>
                  Page content may be cached or incomplete. This review does not
                  verify ownership or scan for malware. The basic URL score
                  below is separate from this AI assessment.
                </p>
              </div>
              <p role="status">{status}</p>
            </>
          )}
        </section>
      )}
      {result && (
        <section className="link-results" aria-live="polite">
          {!result.valid ? (
            <div className="invalid-result">
              <Info size={22} />
              <div>
                <h2>{result.flags[0].title}</h2>
                <p>{result.flags[0].detail}</p>
              </div>
            </div>
          ) : (
            <>
              <div className="link-report-heading">
                <div>
                  <span className="section-label">
                    BASIC INSPECTION · DESTINATION HOST
                  </span>
                  <h2 className="hostname">{result.hostname}</h2>
                  <p className="muted">
                    This is the hostname a browser would contact, not an
                    endorsement.
                  </p>
                </div>
                <span
                  className={`risk-badge ${result.score >= 60 ? "danger" : result.score >= 25 ? "warning" : "safe"}`}
                >
                  <span />
                  {result.score >= 60
                    ? "High risk"
                    : result.score >= 25
                      ? "Use caution"
                      : "Low risk"}{" "}
                  · {result.score}/100
                </span>
              </div>
              {url.trim() !== checked && (
                <p className="changed-notice">
                  The input has changed. Inspect again to update these results.
                </p>
              )}
              <div className="host-breakdown">
                <div>
                  <span>Protocol</span>
                  <strong>{result.protocol.toUpperCase()}</strong>
                </div>
                <div>
                  <span>Destination host</span>
                  <strong>{result.hostname}</strong>
                </div>
                <div>
                  <span>Path</span>
                  <strong>{result.path || "/"}</strong>
                </div>
                <div>
                  <span>Final destination</span>
                  <strong>
                    {result.shortener
                      ? "Hidden by shortener"
                      : "Redirects not checked by basic inspection"}
                  </strong>
                </div>
              </div>
              <div className="url-flags">
                {result.flags.length ? (
                  result.flags.map((f, i) => (
                    <article
                      key={f.title}
                      style={
                        { "--delay": `${i * 55}ms` } as React.CSSProperties
                      }
                    >
                      <span className="flag-number">0{i + 1}</span>
                      <div>
                        <h3>{f.title}</h3>
                        <p>{f.detail}</p>
                      </div>
                    </article>
                  ))
                ) : (
                  <article>
                    <span className="flag-number">
                      <Check size={16} />
                    </span>
                    <div>
                      <h3>No listed structural warning signs</h3>
                      <p>
                        A clean-looking link can still be unsafe. This basic
                        result checks the URL structure; use the AI review for
                        page-content observations.
                      </p>
                    </div>
                  </article>
                )}
              </div>
              <div className="link-result-actions">
                <button
                  className="secondary-button"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(
                        `ScamShield link inspection\nHost: ${result.hostname}\nScore: ${result.score}/100\n${result.flags.map((f) => `${f.title}: ${f.detail}`).join("\n")}\nBasic inspection checks URL structure only.${review ? `\n\nAI page review: ${verdictLabels[review.verdict]}\n${review.summary}\nPage content retrieved: ${review.pageRead ? "yes" : "no"}\n${review.findings.join("\n")}\nReviewed: ${review.checkedAt}` : ""}\nNeither result guarantees legitimacy.`,
                      );
                      setStatus("Copied link assessment.");
                    } catch {
                      setStatus("Could not copy. Select the text manually.");
                    }
                  }}
                >
                  <Copy size={14} /> Copy assessment
                </button>
                <Link href="/assistant" className="secondary-button">
                  Ask about this check
                  <ArrowRight size={14} />
                </Link>
                <span role="status">{status}</span>
              </div>
            </>
          )}
        </section>
      )}
      <div className="assistant-footnote">
        <Info size={14} />
        <p>
          A suspicious structure is a clue, not proof of fraud. Hostname
          comparisons use a small curated brand list. Legitimate new domains can
          be flagged, and malicious domains can be missed.
        </p>
      </div>
    </main>
  );
}
