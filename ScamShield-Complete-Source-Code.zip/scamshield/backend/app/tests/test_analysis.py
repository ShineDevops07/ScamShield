import pytest
from httpx import ASGITransport, AsyncClient
from main import app


@pytest.mark.asyncio
async def test_health_endpoint():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        res = await client.get("/health")
        assert res.status_code == 200
        data = res.json()
        assert data["status"] == "healthy"
        assert "uptime_seconds" in data
        assert "version" in data


@pytest.mark.asyncio
async def test_capabilities_endpoint():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        res = await client.get("/api/v1/capabilities")
        assert res.status_code == 200
        data = res.json()
        assert "supported_content_types" in data
        assert "ai_provider" in data
        assert "environment" in data


@pytest.mark.asyncio
async def test_analyze_endpoint_success():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "message": "This is Mumbai Customs Department. A parcel registered with your Aadhaar card contains illegal contraband. Digital arrest warrant issued. Transfer penalty fee immediately.",
            "content_type": "message",
            "sender": "+91 98231 09841",
        }
        res = await client.post("/api/v1/analyze", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert "analysis_id" in data
        assert 0 <= data["risk_score"] <= 100
        assert data["risk_level"] in ("high", "critical")
        assert len(data["evidence"]) > 0
        assert len(data["recommended_actions"]) > 0
        assert len(data["what_not_to_do"]) > 0
        assert data["analysis_method"] in ("rules_based", "hybrid", "ai_assisted")
        # Check evidence categorization
        assert all("evidence_type" in ev for ev in data["evidence"])


@pytest.mark.asyncio
async def test_analyze_empty_message_validation():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        res = await client.post("/api/v1/analyze", json={"message": "   "})
        assert res.status_code == 422
        data = res.json()
        assert data["error_code"] == "VALIDATION_ERROR"


@pytest.mark.asyncio
async def test_frontend_compat_route():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "type": "message",
            "text": "Dear consumer, your electricity connection will be disconnected tonight. Pay via bit.ly/mseb",
            "sender": "VM-MSEB",
        }
        res = await client.post("/api/compat/analyze", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert "score" in data
        assert "riskBand" in data
        assert "signals" in data
        assert data["score"] >= 40
