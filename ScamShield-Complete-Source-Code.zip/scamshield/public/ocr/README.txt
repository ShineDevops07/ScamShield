Self-hosted OCR assets for ScamShield.
Worker: tesseract.js 7.0.0 (Apache-2.0), from the official npm distribution.
Core: tesseract.js-core 7.0.0 (Apache-2.0), from the official npm distribution.
English data: @tesseract.js-data/eng 1.0.0, 4.0.0_best_int/eng.traineddata.gz, from the official tesseract.js-data distribution.
Sources: https://github.com/naptha/tesseract.js and https://github.com/naptha/tessdata and https://github.com/tesseract-ocr/tessdata
Run node scripts/prepare-ocr-assets.mjs after updating the OCR dependency.
These files run on the client; user screenshots are never written here.
