import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Link inspector | ScamShield",
  description:
    "Inspect actual destination hosts, lookalikes, shortened links, and obfuscation without opening a website.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
