import time
from datetime import datetime, timezone
from fastapi import APIRouter

from app.core.config import settings
from app.schemas.responses import CapabilitiesResponse, HealthResponse

router = APIRouter(tags=["System & Metadata"])
START_TIME = time.time()


@router.get("/health", response_model=HealthResponse)
async def get_health():
    """Returns basic service health, availability, and uptime."""
    return HealthResponse(
        status="healthy",
        version=settings.VERSION,
        uptime_seconds=round(time.time() - START_TIME, 2),
        timestamp=datetime.now(timezone.utc).isoformat(),
        engine=settings.ARCHITECT,
    )


@router.get("/capabilities", response_model=CapabilitiesResponse)
async def get_capabilities():
    """
    Returns configured capabilities without exposing API keys, secrets, or internal paths.
    """
    has_ai = bool(
        (settings.AI_PROVIDER == "gemini" and settings.GEMINI_API_KEY)
        or (settings.AI_PROVIDER == "openai" and settings.OPENAI_API_KEY)
    )

    return CapabilitiesResponse(
        version=settings.VERSION,
        environment=settings.ENV,
        ai_enabled=has_ai,
        ai_provider=settings.AI_PROVIDER if has_ai else "rules_based_fallback",
        threat_intel_enabled=bool(settings.THREAT_INTEL_API_KEY),
        image_analysis_enabled=bool(settings.GEMINI_API_KEY),
        supported_content_types=["message", "email", "chat", "call"],
        supported_scenarios=[
            "digital_arrest",
            "bank_kyc_suspension",
            "otp_credential_harvesting",
            "electricity_bill_cutoff",
            "job_task_telegram_scam",
            "courier_customs_fee",
            "remote_access_apk",
            "qr_code_reverse_payment",
        ],
        engineered_by=settings.ARCHITECT,
    )
