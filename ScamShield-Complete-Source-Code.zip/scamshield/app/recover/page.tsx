"use client";
import { useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Download,
  ExternalLink,
  LifeBuoy,
  RotateCcw,
} from "lucide-react";
import Link from "next/link";
import { recoveryScenarios, resources } from "@/lib/safety-data";
import { downloadText } from "@/lib/storage";
export default function Recovery() {
  const [selected, setSelected] = useState("");
  const [done, setDone] = useState<string[]>([]);
  const scenario = recoveryScenarios.find((s) => s.id === selected);
  const [note, setNote] = useState("");
  function choose(id: string) {
    setSelected(id);
    setDone([]);
    setNote("");
  }
  return (
    <main id="main-content" className="main-wrap subpage">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />
            RECOVERY & REPORTING
          </span>
          <h1>
            One step <span>at a time.</span>
          </h1>
          <p>
            You don’t have to figure everything out at once.
            <br />
            Choose what happened. Build a practical plan.
          </p>
        </div>
        <span className="page-emblem">
          <LifeBuoy size={34} strokeWidth={1.3} />
        </span>
      </div>
      <div className="urgent-banner">
        <LifeBuoy size={20} />
        <div>
          <strong>Lost money to a scam in India?</strong>
          <p>
            Contact your bank promptly. Call <a href="tel:1930">1930</a> for
            financial cyber fraud and report through the official portal.
            Recovery is not guaranteed.
          </p>
        </div>
        <a
          href="https://cybercrime.gov.in/"
          target="_blank"
          rel="noreferrer"
          className="secondary-button"
        >
          Official portal
          <ExternalLink size={13} />
        </a>
      </div>
      {!scenario ? (
        <section className="scenario-grid" aria-label="Choose what happened">
          {recoveryScenarios.map((s, i) => (
            <button
              key={s.id}
              className="scenario-card"
              style={{ "--delay": `${i * 55}ms` } as React.CSSProperties}
              onClick={() => choose(s.id)}
            >
              <span className="step-number">0{i + 1}</span>
              <h2>{s.title}</h2>
              <p>{s.hint}</p>
              <span className="card-arrow">
                <ArrowRight size={18} />
              </span>
            </button>
          ))}
        </section>
      ) : (
        <section className="recovery-layout">
          <div className="plan-card">
            <button onClick={() => choose("")} className="text-button">
              <ArrowLeft size={14} /> Choose a different situation
            </button>
            <h2>{scenario.title}</h2>
            <p className="muted">
              A checklist to organize your next steps. Nothing is sent or
              reported by this tool.
            </p>
            <div className="plan-progress">
              <span>
                {done.length} of {scenario.steps.length} steps checked
              </span>
              <span>
                {Math.round((done.length / scenario.steps.length) * 100)}%
              </span>
            </div>
            <progress
              value={done.length}
              max={scenario.steps.length}
              aria-label="Recovery checklist progress"
            />
            {scenario.steps.map(([title, description], i) => (
              <label
                key={title}
                className={`checklist-step ${done.includes(title) ? "completed" : ""}`}
              >
                <input
                  type="checkbox"
                  checked={done.includes(title)}
                  onChange={(e) =>
                    setDone(
                      e.target.checked
                        ? [...done, title]
                        : done.filter((x) => x !== title),
                    )
                  }
                />
                <span className="check-visual">
                  {done.includes(title) ? <Check size={15} /> : i + 1}
                </span>
                <span>
                  <strong>{title}</strong>
                  <span>{description}</span>
                </span>
              </label>
            ))}
            {done.length === scenario.steps.length && (
              <p className="completion-note">
                <Check size={16} /> Your checklist is complete. Keep following
                any instructions from official support.
              </p>
            )}
          </div>
          <aside className="plan-sidebar">
            <h3>Keep a useful record.</h3>
            <p>
              Gather dates, transaction references, screenshots, and the
              original messages. Store them securely. You do not need to enter
              private evidence here.
            </p>
            <button
              className="primary-button"
              onClick={() => {
                downloadText(
                  "scamshield-recovery-plan.txt",
                  `ScamShield recovery checklist\n${scenario.title}\n\n${scenario.steps.map(([t, d]) => `${done.includes(t) ? "[x]" : "[ ]"} ${t}\n${d}`).join("\n\n")}\n\nIndia financial cyber fraud: 1930\nOfficial portal: https://cybercrime.gov.in/\nThis checklist does not file a report or guarantee recovery.`,
                );
                setNote("Checklist downloaded.");
              }}
            >
              <Download size={15} /> Download checklist
            </button>
            <button
              className="text-button"
              onClick={() => {
                setDone([]);
                setNote("Checklist reset.");
              }}
            >
              <RotateCcw size={13} /> Reset checklist
            </button>
            <p role="status">{note}</p>
            <Link href="/assistant" className="findings-link">
              Ask a safety question
              <ArrowRight size={14} />
            </Link>
            <p className="small-note">
              Progress stays in this page only. Download to keep a copy.
            </p>
          </aside>
        </section>
      )}
      <section className="resource-section">
        <span className="section-label">OFFICIAL RESOURCES · INDIA</span>
        <div className="resource-grid">
          {resources.map((r) => (
            <a href={r.url} key={r.url} target="_blank" rel="noreferrer">
              <strong>
                {r.name}
                <ExternalLink size={13} />
              </strong>
              <p>{r.description}</p>
            </a>
          ))}
        </div>
        <p className="small-note">
          For another country, use your bank’s official support and the relevant
          local reporting authority. Guidance reviewed 22 October 2026.
        </p>
      </section>
    </main>
  );
}
