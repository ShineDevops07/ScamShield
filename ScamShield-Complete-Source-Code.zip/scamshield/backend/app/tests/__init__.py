"""ScamShield test suite."""
