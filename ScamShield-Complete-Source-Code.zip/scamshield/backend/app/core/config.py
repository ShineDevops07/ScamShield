from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # General
    PROJECT_NAME: str = "ScamShield Backend & Threat Intelligence API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ARCHITECT: str = "Antigravity (Google DeepMind)"
    ENV: str = "development"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # CORS
    CORS_ORIGINS: List[str] = Field(
        default_factory=lambda: [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:3001",
            "http://127.0.0.1:3001",
        ]
    )

    # Security & Rate Limiting
    MAX_REQUEST_SIZE_BYTES: int = 1_048_576  # 1MB limit for payload
    MAX_IMAGE_SIZE_BYTES: int = 5_242_880    # 5MB limit for images
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PER_MINUTE: int = 60

    # AI Provider Settings
    AI_PROVIDER: str = "gemini"  # "gemini" | "openai" | "claude" | "none"
    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-2.5-flash"
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4o-mini"
    ANTHROPIC_API_KEY: Optional[str] = None
    ANTHROPIC_MODEL: str = "claude-3-5-sonnet-20241022"

    AI_TIMEOUT_SECONDS: float = 8.0
    AI_MAX_RETRIES: int = 1

    # External Threat Intelligence (Optional)
    THREAT_INTEL_API_KEY: Optional[str] = None
    THREAT_INTEL_PROVIDER: Optional[str] = None

    # Risk Scoring Thresholds (0-19: Low, 20-49: Caution, 50-79: High, 80-100: Critical)
    RISK_THRESHOLD_CAUTION: int = 20
    RISK_THRESHOLD_HIGH: int = 50
    RISK_THRESHOLD_CRITICAL: int = 80


settings = Settings()
