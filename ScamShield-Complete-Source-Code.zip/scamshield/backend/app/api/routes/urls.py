from fastapi import APIRouter, HTTPException, status
from app.schemas.requests import AnalyzeURLRequest
from app.schemas.responses import URLInspectionResponse
from app.services.url_analysis import analyze_url_safety

router = APIRouter(tags=["URL Inspection"])


@router.post("/analyze-url", response_model=URLInspectionResponse)
async def inspect_url(request: AnalyzeURLRequest):
    """
    Analyzes submitted URL for lookalike spoofing, brand typosquatting,
    excessive subdomains, punycode/homograph attacks, IP addresses, and obfuscated destinations.
    Performs purely static analysis without opening or visiting destination servers.
    """
    try:
        return analyze_url_safety(request.url)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"URL inspection encountered an error: {str(e)}",
        )
