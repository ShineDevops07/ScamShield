import base64
import json
from typing import Optional, Tuple
from fastapi import HTTPException, status
import httpx

from app.core.config import settings
from app.core.logging import logger
from app.schemas.requests import AnalyzeRequest, ContentTypeEnum
from app.schemas.responses import AnalyzeResponse
from app.services.analysis_pipeline import run_analysis_pipeline


# File signature magic bytes
VALID_SIGNATURES = {
    "image/jpeg": (b"\xff\xd8\xff",),
    "image/png": (b"\x89PNG\r\n\x1a\n",),
    "image/webp": (b"RIFF", b"WEBP"),  # Starts with RIFF, bytes 8-12 are WEBP
}


def validate_image_file(file_bytes: bytes, declared_content_type: Optional[str] = None) -> Tuple[bool, str, str]:
    """
    Validates image file bytes against strict magic number signatures and size bounds.
    Does not trust user-provided Content-Type or file extension.
    """
    size = len(file_bytes)
    if size == 0:
        return False, "Uploaded file is empty", ""

    if size > settings.MAX_IMAGE_SIZE_BYTES:
        return False, f"File exceeds maximum size of {settings.MAX_IMAGE_SIZE_BYTES / (1024*1024):.1f}MB", ""

    # Check PNG
    if file_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        return True, "Valid PNG image", "image/png"

    # Check JPEG
    if file_bytes.startswith(b"\xff\xd8\xff"):
        return True, "Valid JPEG image", "image/jpeg"

    # Check WEBP
    if file_bytes.startswith(b"RIFF") and len(file_bytes) >= 12 and file_bytes[8:12] == b"WEBP":
        return True, "Valid WEBP image", "image/webp"

    return False, "Unsupported or malformed file format. Only JPEG, PNG, and WEBP are permitted.", ""


async def extract_and_analyze_image(file_bytes: bytes, mime_type: str) -> AnalyzeResponse:
    """
    Extracts text from image using multimodal AI if configured, then runs full ScamShield pipeline.
    If no vision model is configured, returns an honest HTTPException.
    """
    if not settings.GEMINI_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Screenshot/Image OCR analysis is currently unavailable because no multimodal AI "
                "provider (GEMINI_API_KEY) is configured. Please provide text directly to /api/v1/analyze."
            ),
        )

    b64_data = base64.b64encode(file_bytes).decode("utf-8")
    endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{settings.GEMINI_MODEL}:generateContent?key={settings.GEMINI_API_KEY}"

    prompt = (
        "Extract all visible text from this screenshot or message image accurately. "
        "Return ONLY the extracted text verbatim without adding commentary."
    )

    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt},
                    {
                        "inlineData": {
                            "mimeType": mime_type,
                            "data": b64_data,
                        }
                    },
                ]
            }
        ]
    }

    try:
        async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS * 1.5) as client:
            res = await client.post(endpoint, json=payload)
            if res.status_code != 200:
                logger.error(f"Multimodal vision request failed with code {res.status_code}")
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail="Multimodal vision provider encountered an error while processing the image.",
                )

            data = res.json()
            extracted_text = data["candidates"][0]["content"]["parts"][0]["text"].strip()

            if not extracted_text:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="No readable text could be extracted from the uploaded screenshot.",
                )

            # Route extracted text through full pipeline
            analyze_req = AnalyzeRequest(
                message=extracted_text,
                content_type=ContentTypeEnum.MESSAGE,
                context="Extracted via multimodal OCR screenshot inspection.",
            )
            return await run_analysis_pipeline(analyze_req)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to process image: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to extract or analyze text from image.",
        )
