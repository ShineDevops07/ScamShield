"use client";

import Spline from "@splinetool/react-spline";
import type { Application } from "@splinetool/runtime";
import { useRef } from "react";

export default function SplineBackground() {
  const splineAppRef = useRef<Application | null>(null);

  function onLoad(splineApp: Application) {
    splineAppRef.current = splineApp;

    try {
      // 1. Recursive helper to find and hide any text-related objects
      const hideIfText = (obj: any) => {
        if (!obj) return;
        const name = (obj.name || "").toLowerCase();
        const textVal = (obj.text || "").toLowerCase();
        const type = (obj.type || "").toLowerCase();

        if (
          type === "text" ||
          name.includes("text") ||
          name.includes("building") ||
          name.includes("cool") ||
          name.includes("experience") ||
          textVal.includes("building") ||
          textVal.includes("cool")
        ) {
          obj.visible = false;
          if (obj.scale) {
            obj.scale.x = 0;
            obj.scale.y = 0;
            obj.scale.z = 0;
          }
        }

        if (obj.children && Array.isArray(obj.children)) {
          obj.children.forEach(hideIfText);
        }
      };

      // Check root scene objects
      const scene = (splineApp as any)._scene || (splineApp as any).scene;
      if (scene && scene.children) {
        scene.children.forEach(hideIfText);
      }

      // Check via getAllObjects API if available
      if (typeof splineApp.getAllObjects === "function") {
        const all = splineApp.getAllObjects() || [];
        all.forEach(hideIfText);
      }

      // Also directly hide by known exact names
      const candidates = [
        "We're Building",
        "We`re Building",
        "Cool Experiences",
        "Text",
        "Text 2",
        "Text 1",
        "Title",
        "Subtitle",
      ];
      candidates.forEach((cand) => {
        const found = splineApp.findObjectByName(cand);
        if (found) {
          found.visible = false;
          if (found.scale) {
            found.scale.x = 0;
            found.scale.y = 0;
            found.scale.z = 0;
          }
        }
      });
    } catch (err) {
      console.warn("Spline text hide error:", err);
    }
  }

  return (
    <div className="fixed inset-0 z-0 pointer-events-auto">
      <Spline
        scene="https://prod.spline.design/FG5TnNoPIS6sZI0f/scene.splinecode"
        className="w-full h-full"
        onLoad={onLoad}
      />
      {/* Very light gradient vignette around edges so center stays crisp & interactive */}
      <div className="absolute inset-0 bg-radial-[circle_at_center,transparent_40%,rgba(5,8,18,0.7)_100%] pointer-events-none" />
    </div>
  );
}
