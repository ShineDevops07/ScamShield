import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Learn to spot scams | ScamShield",
  description:
    "Practice on six everyday situations and explore common scam patterns.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
