from fastapi import APIRouter, File, HTTPException, UploadFile, status
from app.core.config import settings
from app.schemas.responses import AnalyzeResponse
from app.services.image_service import extract_and_analyze_image, validate_image_file

router = APIRouter(tags=["Image / Screenshot Inspection"])


@router.post("/analyze-image", response_model=AnalyzeResponse)
async def analyze_image_upload(file: UploadFile = File(...)):
    """
    Inspects and evaluates uploaded screenshots or suspicious message images.
    Enforces strict magic-byte signature validation, file size limits, and safe OCR text extraction.
    """
    file_bytes = await file.read()
    is_valid, msg, mime_type = validate_image_file(file_bytes, file.content_type)
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=msg,
        )

    return await extract_and_analyze_image(file_bytes, mime_type)
