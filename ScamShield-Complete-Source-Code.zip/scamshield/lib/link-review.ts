export type LinkVerdict = "suspicious" | "no_clear_red_flags" | "inconclusive";
export interface LinkReview {
  verdict: LinkVerdict;
  summary: string;
  findings: string[];
  nextSteps: string[];
  pageRead: boolean;
  retrieval: "retrieved" | "blocked" | "unavailable";
  reviewedUrl: string;
  sources: { url: string; title: string }[];
  checkedAt: string;
  provider: "Gemini";
}
export const verdictLabels: Record<LinkVerdict, string> = {
  suspicious: "Suspicious signs found",
  no_clear_red_flags: "No clear warning signs found",
  inconclusive: "Unable to verify",
};
// Public websites only. No direct requests to arbitrary destinations are made
// by our server; retrieval is delegated to Gemini's URL Context tool.
export function reviewableUrl(input: unknown): string {
  if (
    typeof input !== "string" ||
    !input.trim() ||
    input.length > 2048 ||
    /\s/.test(input.trim())
  )
    throw Error("Enter one public website link, up to 2,048 characters.");
  const raw = input.trim();
  let url: URL;
  try {
    url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
  } catch {
    throw Error("Enter a valid http:// or https:// website link.");
  }
  if (
    !["http:", "https:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.port
  )
    throw Error(
      "AI review supports standard public website links without embedded credentials or custom ports.",
    );
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  const labels = host.split(".");
  if (
    labels.length < 2 ||
    host.length > 253 ||
    !/^(?:[a-z]{2,63}|xn--[a-z0-9-]+)$/i.test(labels.at(-1)!) ||
    labels.some(
      (label) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label),
    ) ||
    /(?:^|\.)(localhost|local|internal|lan|home|test|invalid|onion|arpa)$/.test(
      host,
    ) ||
    /(?:^|\.)(nip\.io|sslip\.io|localtest\.me|lvh\.me)$/.test(host)
  )
    throw Error(
      "AI review requires a public domain. Local addresses, IP links and private-network aliases can still be inspected locally.",
    );
  for (const name of url.searchParams.keys())
    if (
      /(?:token|password|passwd|secret|signature|credential|api[_-]?key|otp|auth|session|^code$|^key$|^email$)/i.test(
        name,
      )
    )
      throw Error(
        "This link may contain a private login token or personal details. Use the public website address for AI review, or inspect this link locally.",
      );
  url.hostname = host;
  url.hash = "";
  return url.href;
}
export function isLinkReview(value: unknown): value is LinkReview {
  if (!value || typeof value !== "object") return false;
  const x = value as LinkReview;
  return (
    ["suspicious", "no_clear_red_flags", "inconclusive"].includes(x.verdict) &&
    typeof x.summary === "string" &&
    x.summary.length > 0 &&
    x.summary.length <= 1200 &&
    [x.findings, x.nextSteps].every(
      (a) =>
        Array.isArray(a) &&
        a.length <= 8 &&
        a.every((s) => typeof s === "string" && s.length <= 600),
    ) &&
    typeof x.pageRead === "boolean" &&
    ["retrieved", "blocked", "unavailable"].includes(x.retrieval) &&
    typeof x.reviewedUrl === "string" &&
    typeof x.checkedAt === "string" &&
    x.provider === "Gemini" &&
    Array.isArray(x.sources) &&
    x.sources.length <= 8 &&
    x.sources.every(
      (s) =>
        typeof s.url === "string" &&
        /^https?:\/\//.test(s.url) &&
        typeof s.title === "string",
    )
  );
}
