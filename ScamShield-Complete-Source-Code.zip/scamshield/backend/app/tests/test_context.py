import pytest
from app.schemas.requests import AnalyzeRequest, ContentTypeEnum
from app.services.analysis_pipeline import run_analysis_pipeline
from app.schemas.responses import RiskLevelEnum


@pytest.mark.asyncio
async def test_contextual_false_positive_1_dont_send_otp():
    """1. 'Don't send the OTP to anyone.' must be evaluated as LOW risk."""
    req = AnalyzeRequest(message="Don't send the OTP to anyone.", content_type=ContentTypeEnum.MESSAGE)
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20
    assert any("protective" in s.lower() or "safeguard" in s.lower() or "negation" in s.lower() for s in res.reassuring_signals)


@pytest.mark.asyncio
async def test_contextual_false_positive_2_never_share_password():
    """2. 'Never share your password with anyone.' must be evaluated as LOW risk."""
    req = AnalyzeRequest(message="Never share your password with anyone.", content_type=ContentTypeEnum.MESSAGE)
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20


@pytest.mark.asyncio
async def test_contextual_false_positive_3_bank_never_ask_pin():
    """3. 'Your bank will never ask for your PIN.' must be evaluated as LOW risk."""
    req = AnalyzeRequest(message="Your bank will never ask for your PIN.", content_type=ContentTypeEnum.MESSAGE)
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20


@pytest.mark.asyncio
async def test_contextual_false_positive_4_quoted_scammer():
    """4. 'This scammer told me, 'send your OTP,' but I ignored them.' must be evaluated as LOW risk."""
    req = AnalyzeRequest(
        message="This scammer told me, 'send your OTP,' but I ignored them.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20
    assert any("reporting" in cat.lower() or "inquiry" in cat.lower() for cat in res.detected_categories)


@pytest.mark.asyncio
async def test_contextual_false_positive_5_educational_question():
    """5. 'How can I recognize a phishing email?' must be evaluated as LOW risk."""
    req = AnalyzeRequest(
        message="How can I recognize a phishing email?",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20


@pytest.mark.asyncio
async def test_contextual_false_positive_6_benign_delivery_fee():
    """6. 'Your delivery fee is ₹40. Pay when your parcel arrives.' must be evaluated as LOW risk."""
    req = AnalyzeRequest(
        message="Your delivery fee is ₹40. Pay when your parcel arrives.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20


@pytest.mark.asyncio
async def test_contextual_false_positive_7_pure_otp_delivery():
    """7. 'Your OTP is 482193.' must be evaluated as LOW risk with privacy guidance."""
    req = AnalyzeRequest(
        message="Your OTP is 482193.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level == RiskLevelEnum.LOW
    assert res.risk_score < 20
    assert any("private" in w.lower() or "never" in w.lower() or "share" in w.lower() for w in res.what_not_to_do)


# Elevated concern tests
@pytest.mark.asyncio
async def test_elevated_concern_1_blocked_in_10_minutes():
    """1. 'Your account will be blocked in 10 minutes. Send your OTP immediately.' -> CRITICAL/HIGH."""
    req = AnalyzeRequest(
        message="Your account will be blocked in 10 minutes. Send your OTP immediately.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level in (RiskLevelEnum.HIGH, RiskLevelEnum.CRITICAL)
    assert res.risk_score >= 80


@pytest.mark.asyncio
async def test_elevated_concern_2_suspended_confirm_pin():
    """2. 'Your bank account will be suspended. Confirm your PIN through this link.' -> HIGH/CRITICAL."""
    req = AnalyzeRequest(
        message="Your bank account will be suspended. Confirm your PIN through this link.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level in (RiskLevelEnum.HIGH, RiskLevelEnum.CRITICAL)
    assert res.risk_score >= 70


@pytest.mark.asyncio
async def test_elevated_concern_3_refundable_recruitment_fee():
    """3. 'Pay a refundable recruitment fee to secure your job.' -> HIGH/CRITICAL."""
    req = AnalyzeRequest(
        message="Pay a refundable recruitment fee to secure your job.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level in (RiskLevelEnum.HIGH, RiskLevelEnum.CRITICAL)
    assert res.risk_score >= 50


@pytest.mark.asyncio
async def test_elevated_concern_4_install_unknown_apk():
    """4. 'Install this unknown APK to receive your parcel.' -> HIGH/CRITICAL."""
    req = AnalyzeRequest(
        message="Install this unknown APK to receive your parcel.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level in (RiskLevelEnum.HIGH, RiskLevelEnum.CRITICAL)
    assert res.risk_score >= 70


@pytest.mark.asyncio
async def test_elevated_concern_5_remote_access_banking_app():
    """5. 'Give me remote access to your banking app so I can fix your account.' -> CRITICAL."""
    req = AnalyzeRequest(
        message="Give me remote access to your banking app so I can fix your account.",
        content_type=ContentTypeEnum.MESSAGE,
    )
    res = await run_analysis_pipeline(req)
    assert res.risk_level in (RiskLevelEnum.HIGH, RiskLevelEnum.CRITICAL)
    assert res.risk_score >= 80
