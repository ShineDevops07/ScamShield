export interface AuthFailure {
  message: string;
  reference?: string;
}
export function authFailure(
  error: unknown,
  mode: "signin" | "signup",
): AuthFailure {
  const e =
    error && typeof error === "object"
      ? (error as { code?: unknown; status?: unknown; name?: unknown })
      : {};
  const code =
    typeof e.code === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(e.code)
      ? e.code
      : undefined;
  const messages: Record<string, string> = {
    email_address_not_authorized:
      "This project’s email service cannot send confirmation to this address yet. The project owner needs to configure an email sender (SMTP). You can continue as a guest.",
    over_email_send_rate_limit:
      "The email service has reached its sending limit. Wait before trying again. If you already registered, check your inbox and try signing in.",
    over_request_rate_limit:
      "Too many sign-in or signup attempts. Wait before trying again.",
    weak_password:
      "Your password does not meet this project’s requirements. Use a longer password with the required mix of characters.",
    signup_disabled:
      "New account registration is disabled for this project. The project owner needs to enable signups. You can continue as a guest.",
    email_provider_disabled:
      "Email sign-in is disabled for this project. The project owner needs to enable the email provider.",
    email_address_invalid:
      "The email address was not accepted. Check the spelling and use a valid email address.",
    email_not_confirmed:
      "Confirm your email before signing in. Check your inbox and spam folder for the confirmation link.",
    invalid_credentials:
      "Sign-in failed. Check your email and password, and confirm your email if required.",
    user_already_exists:
      "Account creation could not finish. Try signing in with your existing details, or check your confirmation email.",
    email_exists:
      "Account creation could not finish. Try signing in with your existing details, or check your confirmation email.",
    validation_failed:
      "Check your email address and password requirements, then try again.",
    captcha_failed:
      "Signup verification could not be completed. Retry or ask the project owner to check the verification settings.",
    request_timeout:
      "The account service took too long to respond. Check your connection and retry.",
    user_banned:
      "This account is currently unavailable. Contact the project owner for help.",
  };
  // Return fixed messages and a bounded reference, never raw provider diagnostics,
  // submitted email/password values, request headers or tokens.
  const message =
    code && messages[code]
      ? messages[code]
      : e.status === 429
        ? "Too many attempts or confirmation emails. Wait before trying again."
        : e.status === 401 || e.status === 403
          ? "The account service rejected this request. Check that the Supabase Project URL and public key belong to the same project."
          : e.name === "AuthRetryableFetchError" || e.status === 0
            ? "Could not reach sign-in. Check your connection and try again."
            : mode === "signin"
              ? "Sign-in could not finish. Check your details or ask the project owner to inspect the authentication logs."
              : "Account creation could not finish. The project owner should check Supabase Authentication logs for the error reference below. You can continue as a guest.";
  return { message, ...(code ? { reference: code } : {}) };
}
