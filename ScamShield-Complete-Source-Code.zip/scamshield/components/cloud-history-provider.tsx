"use client";
import Link from "next/link";
import AuthDialog from "./auth-dialog";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import type { User } from "@supabase/supabase-js";
import { getSupabase, supabaseConfigured } from "@/lib/supabase/client";
import { historyError, uploadChecks } from "@/lib/cloud-history";
import { HISTORY_SAVED_EVENT, type SavedScan } from "@/lib/storage";

interface CloudContext {
  configured: boolean;
  loading: boolean;
  user: User | null;
  enabled: boolean;
  status: string;
  error: string;
  revision: number;
  pending: number;
  openAuth: () => void;
  setEnabled: (value: boolean) => void;
  upload: (scans: SavedScan[]) => Promise<boolean>;
  retry: () => Promise<boolean>;
}
const defaults: CloudContext = {
  configured: false,
  loading: false,
  user: null,
  enabled: false,
  status: "",
  error: "",
  revision: 0,
  pending: 0,
  openAuth: () => {},
  setEnabled: () => {},
  upload: async () => false,
  retry: async () => false,
};
const Context = createContext<CloudContext>(defaults);
const preference = (id: string) => `scamshield.cloud-sync.${id}`;
export const useCloudHistory = () => useContext(Context);

export default function CloudHistoryProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [authOpen, setAuthOpen] = useState(false);
  const [authNotice, setAuthNotice] = useState("");
  const prompted = useRef(false);
  const closeAuth = useCallback(() => setAuthOpen(false), []);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [enabled, updateEnabled] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [pending, setPending] = useState(0);
  const identity = useRef<{
    user: User | null;
    enabled: boolean;
    generation: number;
  }>({ user: null, enabled: false, generation: 0 });
  const failed = useRef(new Map<string, SavedScan>());
  const configured = supabaseConfigured();
  useEffect(() => {
    const client = getSupabase();
    if (!client) {
      setLoading(false);
      return;
    }
    let active = true,
      changed = false;
    function accept(next: User | null) {
      if (!active) return;
      if (identity.current.user?.id !== next?.id) {
        if (next) setAuthOpen(false);
        setAuthNotice("");
        let optIn = false;
        try {
          optIn =
            !!next && localStorage.getItem(preference(next.id)) === "true";
        } catch {}
        identity.current = {
          user: next,
          enabled: optIn,
          generation: identity.current.generation + 1,
        };
        failed.current.clear();
        setPending(0);
        updateEnabled(optIn);
        setStatus("");
        setError("");
      } else identity.current.user = next;
      setUser(next);
      setLoading(false);
    }
    const {
      data: { subscription },
    } = client.auth.onAuthStateChange((_event, session) => {
      changed = true;
      accept(session?.user || null);
    });
    client.auth
      .getSession()
      .then(({ data, error: authError }) => {
        if (!active || changed) return;
        accept(data.session?.user || null);
        if (authError)
          setError(
            "Your sign-in session could not be restored. Open Account to sign in again.",
          );
      })
      .catch(() => {
        if (active && !changed) {
          setLoading(false);
          setError("Sign-in is unavailable. Your device history still works.");
        }
      });
    return () => {
      active = false;
      identity.current.generation++;
      subscription.unsubscribe();
    };
  }, []);
  useEffect(() => {
    if (loading || prompted.current) return;
    prompted.current = true;
    const url = new URL(window.location.href);
    const requested = url.searchParams.get("signin") === "1";
    if (!user && (requested || configured)) setAuthOpen(true);
    if (requested) {
      url.searchParams.delete("signin");
      window.history.replaceState(
        window.history.state,
        "",
        url.pathname + url.search + url.hash,
      );
    }
  }, [loading, configured, user]);
  const upload = useCallback(async (scans: SavedScan[]) => {
    const client = getSupabase(),
      current = identity.current;
    if (!client || !current.user || !scans.length) return false;
    const owner = current.user.id,
      generation = current.generation;
    const isCurrent = () =>
      identity.current.user?.id === owner &&
      identity.current.generation === generation;
    setError("");
    setStatus("Saving redacted checks to your account…");
    try {
      await uploadChecks(client, owner, scans);
      if (!isCurrent()) return false;
      scans.forEach((s) => failed.current.delete(s.id));
      setPending(failed.current.size);
      setStatus(
        `${scans.length === 1 ? "Check saved" : "Checks saved"} to your account.`,
      );
      setRevision((n) => n + 1);
      return true;
    } catch (e) {
      if (!isCurrent()) return false;
      // Memory-only retry queue, discarded when the signed-in account changes.
      scans.forEach((s) => {
        if (failed.current.size < 100) failed.current.set(s.id, s);
      });
      setPending(failed.current.size);
      setStatus("");
      setError(historyError(e));
      return false;
    }
  }, []);
  useEffect(() => {
    const save = (event: Event) => {
      if (identity.current.user && identity.current.enabled)
        void upload([(event as CustomEvent<SavedScan>).detail]);
    };
    window.addEventListener(HISTORY_SAVED_EVENT, save);
    return () => window.removeEventListener(HISTORY_SAVED_EVENT, save);
  }, [upload]);
  function setEnabled(value: boolean) {
    const current = identity.current;
    if (!current.user) return;
    try {
      localStorage.setItem(preference(current.user.id), String(value));
    } catch {
      setError(
        "This browser could not remember your sync preference. It applies for this visit.",
      );
    }
    identity.current = { ...current, enabled: value };
    updateEnabled(value);
  }
  return (
    <Context.Provider
      value={{
        configured,
        loading,
        user,
        enabled,
        status,
        error,
        revision,
        pending,
        openAuth: () => {
          setAuthNotice("");
          setAuthOpen(true);
        },
        setEnabled,
        upload,
        retry: () => upload([...failed.current.values()]),
      }}
    >
      {children}
      {authOpen && (
        <AuthDialog
          onClose={closeAuth}
          onConfirmationRequired={() => {
            setAuthOpen(false);
            setAuthNotice(
              "Check your email for a confirmation link. After confirming, sign in to access your cloud history.",
            );
          }}
        />
      )}
      {authNotice && (
        <div className="cloud-feedback" role="status">
          <span>{authNotice}</span>
          <button
            className="auth-notice-action"
            onClick={() => {
              setAuthNotice("");
              setAuthOpen(true);
            }}
          >
            Sign in
          </button>
          <button
            aria-label="Dismiss account message"
            onClick={() => setAuthNotice("")}
          >
            ×
          </button>
        </div>
      )}
      {(status || error) && (
        <div
          className={`cloud-feedback ${error ? "has-error" : ""}`}
          role={error ? "alert" : "status"}
        >
          <span>{error || status}</span>
          <Link href="/history">View history</Link>
          <button
            aria-label="Dismiss cloud status"
            onClick={() => {
              setStatus("");
              setError("");
            }}
          >
            ×
          </button>
        </div>
      )}
    </Context.Provider>
  );
}
