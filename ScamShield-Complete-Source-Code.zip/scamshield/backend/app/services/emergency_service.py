from typing import Dict, List
from app.schemas.requests import EmergencyRequest, EmergencyScenarioEnum
from app.schemas.responses import EmergencyResponse, EmergencyStep


def get_emergency_response(request: EmergencyRequest) -> EmergencyResponse:
    """
    Generates tailored, prioritized incident response actions for users
    who have interacted with or fallen victim to a scam.
    """
    scenario = request.scenario
    bank = request.bank_name or "your bank"
    payment_mode = request.payment_method or "UPI / Bank Transfer"

    immediate_actions: List[EmergencyStep] = []
    evidence_to_preserve: List[str] = [
        "Take clear screenshots of all chat conversations, SMS messages, and caller IDs.",
        "Save bank transaction reference numbers (UTR, UPI Transaction ID, Reference Number).",
        "Record exact timestamps of calls, messages, and monetary transfers.",
        "Export chat transcripts before blocking the fraudster.",
    ]

    reporting_channels: List[Dict[str, str]] = [
        {
            "name": "National Cyber Crime Reporting Helpline (India)",
            "contact": "Dial 1930 (Toll-Free, 24/7)",
            "details": "Citizen Financial Cyber Fraud Reporting System — immediately alerts banks to freeze funds in transit.",
        },
        {
            "name": "National Cyber Crime Reporting Portal",
            "contact": "https://cybercrime.gov.in",
            "details": "Official Government of India portal for filing formal financial cyber fraud complaints.",
        },
        {
            "name": "Local Police / Cyber Crime Cell",
            "contact": "Nearest Cyber Police Station",
            "details": "File a formal First Information Report (FIR) if significant financial loss occurred.",
        },
    ]

    recovery_reality_check = (
        "CRITICAL WARNING: Beware of secondary recovery scams. No legitimate agency, hacker, or lawyer on "
        "Instagram, Telegram, or WhatsApp can 'hack back' or recover stolen funds for an upfront fee. "
        "Only official bank freezing and law enforcement via the 1930 portal can block and return stolen money."
    )

    if scenario == EmergencyScenarioEnum.OTP_SHARED or scenario == EmergencyScenarioEnum.CREDENTIALS_LEAKED:
        summary = "Emergency containment for leaked OTP, password, or banking PIN."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action=f"Call {bank} emergency helpline to freeze accounts and debit cards",
                details=(
                    "Use the official phone number printed on the back of your physical debit card or within your authentic bank mobile app. "
                    "Request an immediate freeze on netbanking, UPI, and card transactions."
                ),
                contact_or_resource="Official bank helpline from bank app",
            ),
            EmergencyStep(
                step_number=2,
                priority="IMMEDIATE",
                action="Change netbanking and email passwords from a secure device",
                details="Use a trusted secondary device to reset your master email and netbanking passwords. Terminate all active login sessions.",
            ),
            EmergencyStep(
                step_number=3,
                priority="HIGH",
                action="Check for unauthorized UPI handles or linked devices",
                details="Open your authentic UPI apps (GPay, PhonePe, Paytm, BHIM) and verify linked bank accounts and active devices.",
            ),
            EmergencyStep(
                step_number=4,
                priority="FOLLOW_UP",
                action="Report to National Cyber Crime Helpline (1930)",
                details="File an incident report so authorities can monitor for unauthorized attempts against your accounts.",
                contact_or_resource="Dial 1930 or visit cybercrime.gov.in",
            ),
        ]

    elif scenario == EmergencyScenarioEnum.MONEY_SENT:
        summary = f"Rapid response for unauthorized {payment_mode} financial transfer."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action="Dial 1930 immediately (The Golden Hour)",
                details=(
                    "Reporting to 1930 within the first 2-3 hours offers the highest chance of freezing the money "
                    "before the fraudster can withdraw it at an ATM or convert it to cryptocurrency."
                ),
                contact_or_resource="Call 1930 immediately",
            ),
            EmergencyStep(
                step_number=2,
                priority="IMMEDIATE",
                action=f"Notify {bank} fraud desk with Transaction ID / UTR",
                details="Provide the exact 12-digit UPI reference (UTR) or IMPS reference number to your bank's fraud control department.",
            ),
            EmergencyStep(
                step_number=3,
                priority="HIGH",
                action="File formal complaint on cybercrime.gov.in",
                details="Attach screenshots, bank statements showing the debit, and sender phone numbers to obtain a formal complaint acknowledgment number.",
            ),
        ]

    elif scenario == EmergencyScenarioEnum.APK_INSTALLED or scenario == EmergencyScenarioEnum.REMOTE_ACCESS_GRANTED:
        summary = "Containment for malicious APK installation or unauthorized remote screen sharing."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action="Disconnect device from Internet immediately (Turn on Airplane Mode)",
                details="Immediately turn on Airplane mode and disable Wi-Fi to stop remote attackers from viewing your screen or receiving SMS OTPs.",
            ),
            EmergencyStep(
                step_number=2,
                priority="IMMEDIATE",
                action="Call your bank from another phone to block digital banking",
                details="Do NOT use the compromised phone to conduct banking. Call your bank from a family member's phone to temporarily freeze netbanking.",
            ),
            EmergencyStep(
                step_number=3,
                priority="HIGH",
                action="Uninstall suspicious applications and remote desktop software",
                details="Go to Phone Settings -> Apps. Look for recently installed unknown APKs or tools like AnyDesk, TeamViewer, RustDesk, or QuickSupport and uninstall them.",
            ),
            EmergencyStep(
                step_number=4,
                priority="HIGH",
                action="Perform factory data reset if malware persists",
                details="If unknown apps cannot be uninstalled or the screen is flickering/locked, back up essential photos/contacts and perform a complete factory reset.",
            ),
        ]

    elif scenario == EmergencyScenarioEnum.ID_DOCUMENTS_SHARED:
        summary = "Protection plan for leaked Aadhaar or PAN card identity documents."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action="Lock your Aadhaar biometrics via mAadhaar or UIDAI portal",
                details="Log in to the official UIDAI portal (myaadhaar.uidai.gov.in) and activate biometric lock to prevent fraudulent authentication.",
                contact_or_resource="https://myaadhaar.uidai.gov.in",
            ),
            EmergencyStep(
                step_number=2,
                priority="HIGH",
                action="Monitor your credit report (CIBIL / Experian)",
                details="Check your CIBIL report over the next 3-6 months for any unauthorized loan applications or credit card inquiries opened in your name.",
            ),
            EmergencyStep(
                step_number=3,
                priority="FOLLOW_UP",
                action="Check registered mobile numbers on your Aadhaar (TAFCOP portal)",
                details="Visit the Department of Telecommunications TAFCOP portal (tafcop.sancharsaathi.gov.in) to check if any unauthorized SIM cards have been issued using your ID.",
                contact_or_resource="https://tafcop.sancharsaathi.gov.in",
            ),
        ]

    elif scenario == EmergencyScenarioEnum.EXTORTION_BLACKMAIL:
        summary = "Crisis containment for Digital Arrest, extortion, or blackmail threats."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action="Immediately cease all communication with the extortionist",
                details="Disconnect video or audio calls. Do not pay any money. Scammers escalate demands once they receive a first payment.",
            ),
            EmergencyStep(
                step_number=2,
                priority="IMMEDIATE",
                action="Remember: Digital Arrest is 100% fake",
                details="Indian law enforcement, CBI, and police do not conduct arrests, hearings, or penalty collections over WhatsApp, Skype, or phone calls.",
            ),
            EmergencyStep(
                step_number=3,
                priority="HIGH",
                action="Report immediately to Cyber Police and dial 1930",
                details="Provide the phone numbers, video call handles, and bank account numbers provided by the extortionist.",
                contact_or_resource="Dial 1930 / Visit cybercrime.gov.in",
            ),
        ]

    else:
        summary = "General scam containment and safety verification."
        immediate_actions = [
            EmergencyStep(
                step_number=1,
                priority="IMMEDIATE",
                action="Cease communication and do not click any links",
                details="Do not send money, OTPs, or passwords.",
            ),
            EmergencyStep(
                step_number=2,
                priority="HIGH",
                action="Verify claims independently via official channels",
                details="Contact the legitimate institution using verified numbers from their official website.",
            ),
        ]

    return EmergencyResponse(
        scenario=scenario.value,
        summary=summary,
        immediate_actions=immediate_actions,
        reporting_channels=reporting_channels,
        evidence_to_preserve=evidence_to_preserve,
        recovery_reality_check=recovery_reality_check,
    )
