"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import CloudSaveNote from "@/components/cloud-save-note";
import {
  downloadText,
  remember,
  safeScan,
  redactSensitive,
  SAVE_KEY,
} from "@/lib/storage";
import {
  ArrowDown,
  ArrowRight,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  Copy,
  FileText,
  Globe2,
  Info,
  LockKeyhole,
  MessageSquareText,
  Phone,
  RotateCcw,
  Search,
  ShieldCheck,
  X,
  Download,
  MessageCircle,
  History,
  LifeBuoy,
  GraduationCap,
  ImagePlus,
  AudioLines,
} from "lucide-react";
import {
  analyzeRisk,
  assessmentLabel,
  callSamples,
  messageSamples,
  urlSamples,
  type AnalysisTab,
  type SampleItem,
} from "@/lib/analysis";

const channels = [
  { id: "message" as const, label: "Message", icon: MessageSquareText },
  { id: "call" as const, label: "Phone call", icon: Phone },
  { id: "url" as const, label: "Website link", icon: Globe2 },
];

const sampleNames: Record<string, string> = {
  "Electricity Power Cut SMS": "Electricity bill reminder",
  "Part-Time Job / Telegram Scam": "Job offer",
  "Legitimate Security OTP SMS": "Bank security message",
  "FedEx Customs Scam Call": "Customs impersonation",
  "Bank KYC Expiry Call": "Bank verification call",
  "Legitimate Bank Advisory Call": "Security advisory",
  "Phishing Netbanking Portal": "Suspicious bank link",
  "Legitimate Domain": "Standard bank link",
};

const signalNames: Record<string, string> = {
  "Active Credential Harvesting Demand": "Request for private credentials",
  "Legitimate Security / Anti-Phishing Advisory": "Protective security advice",
  "Aadhaar / PAN Card Identity Theft Solicitation":
    "Request for identity documents",
  "National Identity Document (Aadhaar / PAN) Referenced":
    "Identity documents mentioned",
  "Law Enforcement / Digital Arrest Impersonation":
    "Claim of authority or arrest",
  "Unsolicited Financial Transfer Demand": "Request for payment",
  "Psychological Panic & Pressure Tactics": "Pressure to act quickly",
  "Phishing URL or Unrealistic Task Trap": "Suspicious link or income claim",
};

type Report = {
  content: string;
  channel: AnalysisTab;
  assessment: ReturnType<typeof analyzeRisk>;
};

export default function Home() {
  const [tab, setTab] = useState<AnalysisTab>("message");
  const [text, setText] = useState("");
  const [callerNumber, setCallerNumber] = useState("");
  const [callerName, setCallerName] = useState("");
  const [report, setReport] = useState<Report | null>(null);
  const [copyStatus, setCopyStatus] = useState("");
  const [example, setExample] = useState("");
  const [saveHistory, setSaveHistory] = useState(false);
  const [storageNotice, setStorageNotice] = useState("");
  useEffect(() => {
    try {
      setSaveHistory(localStorage.getItem(SAVE_KEY) === "true");
    } catch {}
  }, []);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const resultsRef = useRef<HTMLElement>(null);
  const samples =
    tab === "message"
      ? messageSamples
      : tab === "call"
        ? callSamples
        : urlSamples;
  const assessment = report?.assessment;
  const tone = assessment?.tone || "neutral";

  function changeChannel(channel: AnalysisTab) {
    setTab(channel);
    setText("");
    setCallerNumber("");
    setCallerName("");
    setReport(null);
    setExample("");
    setCopyStatus("");
    setStorageNotice("");
  }

  function loadSample(sample: SampleItem) {
    setText(sample.text);
    setTab(sample.type);
    setCallerNumber(sample.callerNumber || "");
    setCallerName(sample.callerName || "");
    setExample(sample.label);
    setReport(null);
    setCopyStatus("");
    inputRef.current?.focus();
  }

  function reset() {
    setText("");
    setCallerNumber("");
    setCallerName("");
    setReport(null);
    setCopyStatus("");
    setExample("");
    inputRef.current?.focus();
  }

  function runAnalysis() {
    if (!text.trim()) return;
    setReport({
      content: text.trim(),
      channel: tab,
      assessment: analyzeRisk(text, tab),
    });
    setCopyStatus("");
    const stored = remember(
      safeScan(text.trim(), tab, analyzeRisk(text, tab)),
      saveHistory,
    );
    setStorageNotice(
      stored
        ? saveHistory
          ? "Redacted summary saved on this device."
          : "Summary available to the assistant during this session."
        : "Browser storage is unavailable. Your check still works.",
    );
    requestAnimationFrame(() => {
      resultsRef.current?.focus({ preventScroll: true });
      if (window.matchMedia?.("(max-width: 760px)").matches)
        resultsRef.current?.scrollIntoView?.({
          behavior: window.matchMedia?.("(prefers-reduced-motion: reduce)")
            .matches
            ? "auto"
            : "smooth",
          block: "start",
        });
    });
  }

  async function copyReport() {
    if (!report) return;
    try {
      await navigator.clipboard.writeText(
        `ScamShield assessment\n${assessmentLabel(report.assessment)}\n\n${report.assessment.summary}\n\nSubmitted content:\n${redactSensitive(report.content)}\n\nFindings:\n${report.assessment.signals.map((s) => `${signalNames[s.title] || s.title}: ${s.description}`).join("\n")}\n\nThis is a pattern-based assessment, not verification of the sender.`,
      );
      setCopyStatus("Copied to clipboard");
    } catch {
      setCopyStatus(
        "Could not copy. Please select and copy the result manually.",
      );
    }
  }

  return (
    <div className="site-shell">
      <main className="main-wrap" id="main-content">
        <section className="intro" aria-labelledby="page-title">
          <div>
            <div className="eyebrow">
              <span /> EVERYDAY DIGITAL SECURITY
            </div>
            <h1 id="page-title">
              Check before <span>you respond.</span>
            </h1>
            <p>
              Check the message. Understand the pressure. Know your next step.
              <br className="desktop-break" /> Your everyday toolkit for
              spotting scams and responding with confidence.
            </p>
          </div>
          <div className="intro-note animated-note">
            <span className="intro-note-icon">
              <ShieldCheck size={22} strokeWidth={1.5} />
            </span>
            <div>
              <strong>A second opinion, in seconds.</strong>
              <p>
                Understand the warning signs.
                <br />
                Keep the decision in your hands.
              </p>
            </div>
          </div>
        </section>

        <div className="journey-strip" aria-label="Your safety journey">
          <span className="journey-step done">
            <span>01</span>Detect
          </span>
          <i />
          <span className={report ? "journey-step done" : "journey-step"}>
            <span>02</span>Understand
          </span>
          <i />
          <Link href={report ? "/recover" : "/learn"} className="journey-step">
            <span>03</span>Take action
            <ArrowRight size={13} />
          </Link>
          <span className="journey-privacy">
            <LockKeyhole size={12} /> Checks run on your device
          </span>
        </div>
        <div className="workspace" id="checker">
          <section className="input-card" aria-labelledby="input-title">
            <div className="panel-heading">
              <div>
                <span className="section-label">CONTENT CHECK</span>
                <h2 id="input-title">What would you like to check?</h2>
              </div>
              <span className="step-number">01</span>
            </div>
            <Link href="/screenshots" className="screenshot-entry">
              <ImagePlus size={16} />
              <span>Have a screenshot instead?</span>
              <span>
                Read and check it privately
                <ArrowRight size={13} />
              </span>
            </Link>
            {tab === "call" && (
              <Link href="/audio" className="audio-entry">
                <AudioLines size={17} />
                <span>Have a voice note or recording?</span>
                <ArrowRight size={15} />
              </Link>
            )}
            <div
              className="channel-tabs"
              role="tablist"
              aria-label="Content type"
            >
              {channels.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  id={`tab-${id}`}
                  role="tab"
                  aria-selected={tab === id}
                  aria-controls="content-panel"
                  tabIndex={tab === id ? 0 : -1}
                  onKeyDown={(e) => {
                    const index = channels.findIndex((c) => c.id === tab);
                    const next =
                      e.key === "ArrowRight"
                        ? (index + 1) % 3
                        : e.key === "ArrowLeft"
                          ? (index + 2) % 3
                          : e.key === "Home"
                            ? 0
                            : e.key === "End"
                              ? 2
                              : -1;
                    if (next >= 0) {
                      e.preventDefault();
                      changeChannel(channels[next].id);
                      document
                        .getElementById(`tab-${channels[next].id}`)
                        ?.focus();
                    }
                  }}
                  className={
                    tab === id ? "channel-tab selected" : "channel-tab"
                  }
                  onClick={() => changeChannel(id)}
                >
                  <Icon size={16} strokeWidth={1.7} />
                  {label}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                runAnalysis();
              }}
              id="content-panel"
              role="tabpanel"
              aria-labelledby={`tab-${tab}`}
            >
              {tab === "call" && (
                <div className="caller-fields">
                  <div>
                    <label htmlFor="caller-number">
                      Caller number <span>(optional)</span>
                    </label>
                    <input
                      id="caller-number"
                      value={callerNumber}
                      onChange={(e) => setCallerNumber(e.target.value)}
                      placeholder="Displayed phone number"
                    />
                  </div>
                  <div>
                    <label htmlFor="caller-name">
                      Claimed organization <span>(optional)</span>
                    </label>
                    <input
                      id="caller-name"
                      value={callerName}
                      onChange={(e) => setCallerName(e.target.value)}
                      placeholder="Bank, delivery company…"
                    />
                  </div>
                </div>
              )}
              <div className="input-label-row">
                <label htmlFor="content">
                  {tab === "message"
                    ? "Paste your message"
                    : tab === "call"
                      ? "What did the caller say?"
                      : "Paste the website link"}
                </label>
                {text && (
                  <button className="text-button" type="button" onClick={reset}>
                    <X size={12} /> Clear
                  </button>
                )}
              </div>
              <textarea
                ref={inputRef}
                id="content"
                maxLength={10000}
                value={text}
                onChange={(e) => {
                  setText(e.target.value);
                  setExample("");
                  setCopyStatus("");
                }}
                placeholder={
                  tab === "message"
                    ? "Paste an SMS, WhatsApp message, or email here…"
                    : tab === "call"
                      ? "Paste a transcript or write down what the caller asked you to do…"
                      : "https://example.com"
                }
                className={tab === "url" ? "link-input" : ""}
                aria-describedby="content-help"
              />
              <div className="input-meta" id="content-help">
                <span>
                  {tab === "url"
                    ? "We check the link without opening it."
                    : tab === "call"
                      ? "Text only. No call recording or caller verification."
                      : "Leave out passwords, account details, and personal information."}
                </span>
                <span>{text.length.toLocaleString()} / 10,000</span>
              </div>
              <div className="examples">
                <span>Or try an example</span>
                <div>
                  {samples.map((sample) => (
                    <button
                      type="button"
                      key={sample.label}
                      className={
                        example === sample.label
                          ? "example-button active"
                          : "example-button"
                      }
                      onClick={() => loadSample(sample)}
                    >
                      {sampleNames[sample.label]}
                      <ChevronRight size={12} />
                    </button>
                  ))}
                </div>
              </div>
              {tab === "call" && (
                <button
                  className="demo-button"
                  type="button"
                  onClick={() =>
                    loadSample({
                      label: "Demo call transcript",
                      type: "call",
                      text: "Officer speaking from cyber cell department. Your SIM card is involved in money laundering. Press 9 or transfer verification fee to avoid immediate handset blocking.",
                      callerNumber: "+91 91234 56789",
                      callerName: "Automated Cyber Cell IVR",
                    })
                  }
                >
                  <FileText size={14} /> Load demo transcript
                </button>
              )}
              <label className="save-preference">
                <input
                  type="checkbox"
                  checked={saveHistory}
                  onChange={(e) => {
                    setSaveHistory(e.target.checked);
                    try {
                      localStorage.setItem(SAVE_KEY, String(e.target.checked));
                    } catch {
                      setStorageNotice("Could not save your preference.");
                    }
                  }}
                />{" "}
                Save redacted summaries in my device history
              </label>
              <CloudSaveNote />
              <div className="form-footer">
                <span>
                  <LockKeyhole size={13} /> Your text stays in this browser
                </span>
                <button
                  className="primary-button"
                  type="submit"
                  disabled={!text.trim()}
                >
                  Check{" "}
                  {tab === "url"
                    ? "link"
                    : tab === "call"
                      ? "transcript"
                      : "message"}
                  <ArrowRight size={16} />
                </button>
              </div>
            </form>
          </section>

          <section
            className={`result-card ${tone}`}
            aria-labelledby="result-title"
            ref={resultsRef}
            tabIndex={-1}
          >
            <div className="panel-heading">
              <div>
                <span className="section-label">ASSESSMENT</span>
                <h2 id="result-title">Your results</h2>
              </div>
              {report ? (
                <button
                  className="icon-button"
                  title="Copy assessment"
                  aria-label="Copy assessment"
                  onClick={copyReport}
                >
                  {copyStatus === "Copied to clipboard" ? (
                    <Check size={17} />
                  ) : (
                    <Copy size={17} />
                  )}
                </button>
              ) : (
                <span className="step-number">02</span>
              )}
            </div>
            <div
              aria-live="polite"
              aria-atomic="true"
              className="result-content"
              key={report?.content || "empty"}
            >
              {!assessment ? (
                <div className="empty-result">
                  <div className="empty-illustration" aria-hidden="true">
                    <div className="paper-line short" />
                    <div className="paper-line" />
                    <div className="paper-line" />
                    <div className="search-lens">
                      <Search size={26} strokeWidth={1.4} />
                    </div>
                  </div>
                  <h3>A clearer picture starts here.</h3>
                  <p>
                    Add your content and select check.
                    <br />
                    We’ll look for common warning signs
                    <br />
                    and explain what they mean.
                  </p>
                  <div className="empty-checks">
                    <span>
                      <Check size={13} /> Clear explanations
                    </span>
                    <span>
                      <Check size={13} /> Practical next steps
                    </span>
                  </div>
                </div>
              ) : (
                <>
                  <div className="verdict-row">
                    <span className="risk-badge">
                      <span />
                      {assessment.risk}
                    </span>
                    {assessment.score !== null ? (
                      <span className="score">
                        <strong>{assessment.score}</strong>
                        <span>/ 100</span>
                      </span>
                    ) : (
                      <span className="unscored-label">Not scored</span>
                    )}
                  </div>
                  {assessment.score !== null && (
                    <>
                      <div
                        className="risk-track"
                        role="meter"
                        aria-label="Estimated risk score"
                        aria-valuenow={assessment.score}
                        aria-valuemin={0}
                        aria-valuemax={100}
                      >
                        <span style={{ width: `${assessment.score}%` }} />
                      </div>
                      <div className="risk-scale">
                        <span>Low risk</span>
                        <span>Higher risk</span>
                      </div>
                    </>
                  )}
                  <p className="result-summary">{assessment.summary}</p>
                  <div className="next-step">
                    <span className="section-label">YOUR NEXT STEP</span>
                    <p>
                      {tone === "danger"
                        ? "Stop the conversation. Do not send money or share security codes. Verify the request through a trusted contact channel."
                        : assessment.kind === "payment_receipt"
                          ? "Check the actual credited transaction in your own bank, wallet, or merchant payment app. Match the amount, date, receiving account, and reference. Do not rely on a screenshot alone."
                          : tone === "warning"
                            ? "Pause before acting. Find the organization’s official contact details independently and confirm the request."
                            : "Continue with care. Confirm unexpected requests through a contact channel you already trust."}
                    </p>
                  </div>
                  <a className="findings-link" href="#findings">
                    See {assessment.signals.length}{" "}
                    {assessment.signals.length === 1 ? "finding" : "findings"}
                    <ArrowDown size={14} />
                  </a>
                </>
              )}
              {report && (
                <div className="report-actions">
                  <Link href="/assistant">
                    <MessageCircle size={14} /> Ask about this
                  </Link>
                  <button
                    onClick={() => {
                      if (report) {
                        const scan = safeScan(
                          report.content,
                          report.channel,
                          report.assessment,
                        );
                        downloadText(
                          "scamshield-report.txt",
                          `ScamShield — Redacted safety report\n${new Date(scan.createdAt).toLocaleString()}\n${scan.channel} · ${assessmentLabel(scan.assessment)}\n\n${scan.assessment.summary}\n\n${scan.preview}\n\n${scan.assessment.signals.map((s) => `${s.title}: ${s.description} [${s.excerpt}]`).join("\n")}\n\nPattern-based guidance, not proof of fraud or authenticity.`,
                        );
                      }
                    }}
                  >
                    <Download size={14} /> Download
                  </button>
                  <Link href="/recover">
                    <LifeBuoy size={14} /> I already responded
                  </Link>
                </div>
              )}
              {storageNotice && (
                <p className="storage-notice" role="status">
                  {storageNotice}
                </p>
              )}
              {copyStatus && (
                <p className="copy-status" role="status">
                  {copyStatus}
                </p>
              )}
            </div>
            <div className="result-disclaimer">
              <Info size={14} />
              <p>
                Pattern-based guidance. A low score does not confirm a sender or
                website is genuine.
              </p>
            </div>
          </section>
        </div>

        {report && assessment && (
          <section
            className="findings-section"
            id="findings"
            aria-labelledby="findings-title"
          >
            <div className="findings-heading">
              <div>
                <span className="section-label">A CLOSER LOOK</span>
                <h2 id="findings-title">What we found</h2>
              </div>
              <button className="text-button" onClick={reset}>
                <RotateCcw size={14} /> Start again
              </button>
            </div>
            {report.content !== text.trim() && (
              <p className="changed-notice">
                <Info size={14} /> These findings are for your previous check.
                Check again to assess your changes.
              </p>
            )}
            <div className="findings-list">
              {assessment.signals.length ? (
                assessment.signals.map((signal) => (
                  <article key={signal.title} className="finding">
                    <span
                      className={`finding-icon ${signal.type}`}
                      aria-hidden="true"
                    >
                      {signal.type === "context" ? (
                        <Info size={18} />
                      ) : signal.type === "safety" ? (
                        <CheckCheck size={18} />
                      ) : (
                        <Search size={18} />
                      )}
                    </span>
                    <div>
                      <div className="finding-title">
                        <h3>{signalNames[signal.title] || signal.title}</h3>
                        <span className={`severity ${signal.type}`}>
                          {signal.type === "context"
                            ? "Not verified"
                            : signal.type === "safety"
                              ? "Reassuring"
                              : `${signal.severity} concern`}
                        </span>
                      </div>
                      <p>{signal.description}</p>
                      {signal.excerpt && (
                        <blockquote>“{signal.excerpt}”</blockquote>
                      )}
                    </div>
                  </article>
                ))
              ) : (
                <div className="no-findings">
                  <Check size={18} />
                  <p>
                    No common warning patterns matched this content. Independent
                    verification is still recommended.
                  </p>
                </div>
              )}
            </div>
          </section>
        )}

        <section className="toolbox" aria-labelledby="toolbox-title">
          <div className="section-heading">
            <div>
              <span className="section-label">YOUR SAFETY TOOLKIT</span>
              <h2 id="toolbox-title">More than a verdict.</h2>
            </div>
            <p>A little understanding goes a long way.</p>
          </div>
          <div className="tool-grid">
            {[
              {
                href: "/assistant",
                icon: MessageCircle,
                title: "Talk it through",
                text: "Ask basic safety questions or discuss your latest check.",
                label: "Open assistant",
              },
              {
                href: "/links",
                icon: Globe2,
                title: "Look past the link",
                text: "Reveal the actual hostname, lookalikes, and hidden destinations.",
                label: "Inspect a link",
              },
              {
                href: "/recover",
                icon: LifeBuoy,
                title: "Make a recovery plan",
                text: "Choose what happened and follow a practical checklist.",
                label: "Find next steps",
              },
              {
                href: "/learn",
                icon: GraduationCap,
                title: "Build your scam radar",
                text: "Try real-world examples and test your judgment.",
                label: "Take the challenge",
              },
            ].map(({ href, icon: Icon, title, text, label }) => (
              <Link href={href} key={href} className="tool-card">
                <span className="tool-icon">
                  <Icon size={20} />
                </span>
                <h3>{title}</h3>
                <p>{text}</p>
                <span>
                  {label}
                  <ArrowRight size={14} />
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section
          className="how-section"
          id="how-it-works"
          aria-labelledby="how-title"
        >
          <div className="how-heading">
            <span className="section-label">SIMPLE BY DESIGN</span>
            <h2 id="how-title">
              A moment to check.
              <br />A better-informed decision.
            </h2>
            <p>No account needed. No complicated setup.</p>
          </div>
          <div className="how-steps">
            {[
              [
                "01",
                "Bring the context",
                "Paste a message, call transcript, or link that you’re unsure about.",
              ],
              [
                "02",
                "Understand the signs",
                "See requests for private details, payment pressure, and other common patterns.",
              ],
              [
                "03",
                "Choose your next step",
                "Use the findings to pause, verify independently, or stop the conversation.",
              ],
            ].map(([number, title, description]) => (
              <div className="how-step" key={number}>
                <span>{number}</span>
                <div>
                  <h3>{title}</h3>
                  <p>{description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section
          className="safety-section"
          id="safety-guide"
          aria-labelledby="safety-title"
        >
          <div className="safety-heading">
            <span className="section-label">KEEP IN MIND</span>
            <h2 id="safety-title">Good habits go a long way.</h2>
          </div>
          <div className="safety-questions">
            {[
              [
                "Keep private information private",
                "Never send passwords, PINs, or one-time codes in response to an unexpected message or call. Remove sensitive details before pasting content into a checker.",
              ],
              [
                "Verify through a channel you trust",
                "Open the organization’s app or use contact details you already know. A displayed name, logo, or familiar-looking link is not proof of identity.",
              ],
              [
                "Already responded to a suspicious request?",
                "Contact the affected service through its official support channel. Explain what happened and ask for the appropriate steps to secure your account.",
              ],
              [
                "What can ScamShield verify?",
                "The checker looks for text patterns in your browser. It does not verify identities, visit websites, or record calls. The separate safety assistant offers optional AI chat, with disclosure before you use it.",
              ],
            ].map(([title, description]) => (
              <details key={title}>
                <summary>
                  {title}
                  <ChevronDown size={16} />
                </summary>
                <p>{description}</p>
              </details>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
