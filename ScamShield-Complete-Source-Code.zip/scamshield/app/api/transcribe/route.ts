import {
  audioMime,
  MAX_AUDIO_BYTES,
  MAX_TRANSCRIPT_CHARACTERS,
} from "@/lib/audio";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

const headers = { "Cache-Control": "no-store" };
const MAX_BODY_BYTES = MAX_AUDIO_BYTES + 64 * 1024;
let requests: number[] = [];
let active = false;
const reply = (
  error: string,
  status: number,
  extra: Record<string, string> = {},
) => Response.json({ error }, { status, headers: { ...headers, ...extra } });

export async function GET() {
  return Response.json(
    {
      available: !!process.env.OPENAI_API_KEY?.trim(),
      provider: "OpenAI",
      maxBytes: MAX_AUDIO_BYTES,
      formats: ["mp3", "wav"],
    },
    { headers },
  );
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (
    (origin && origin !== new URL(request.url).origin) ||
    request.headers.get("sec-fetch-site") === "cross-site"
  )
    return reply("Open the audio page on this website before uploading.", 403);
  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey)
    return reply(
      "Audio transcription is not configured. The app owner needs to set OPENAI_API_KEY on the server. You can still paste a transcript.",
      503,
    );
  const model = process.env.OPENAI_TRANSCRIBE_MODEL || "gpt-transcribe";
  if (!/^[a-z\d.-]{1,80}$/i.test(model))
    return reply("The transcription model configuration needs attention.", 503);
  const contentType = request.headers.get("content-type") || "";
  if (
    !/^multipart\/form-data\s*;/i.test(contentType) ||
    contentType.length > 1000
  )
    return reply("Upload one audio file using the audio page.", 415);
  const declaredLength = request.headers.get("content-length");
  if (
    declaredLength &&
    (!/^\d+$/.test(declaredLength) || Number(declaredLength) > MAX_BODY_BYTES)
  )
    return reply("This upload is too large. Choose a file up to 20 MB.", 413);
  const now = Date.now();
  requests = requests.filter((time) => time > now - 60_000);
  if (requests.length >= 6)
    return reply(
      "The demo transcription limit was reached. Wait a minute and retry.",
      429,
      { "Retry-After": "60" },
    );
  if (active)
    return reply(
      "Another recording is being transcribed. Please try again shortly.",
      429,
      { "Retry-After": "10" },
    );
  requests.push(now);
  active = true;
  const deadline = AbortSignal.timeout(110_000);
  const signal = AbortSignal.any([request.signal, deadline]);
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  const abortRead = () => {
    void reader?.cancel().catch(() => {});
  };
  signal.addEventListener("abort", abortRead, { once: true });
  try {
    reader = request.body?.getReader();
    if (!reader) return reply("Choose an audio file first.", 400);
    const chunks: ArrayBuffer[] = [];
    let size = 0;
    while (true) {
      signal.throwIfAborted();
      const { done, value } = await reader.read();
      signal.throwIfAborted();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BODY_BYTES) {
        await reader.cancel();
        return reply(
          "This upload is too large. Choose a file up to 20 MB.",
          413,
        );
      }
      chunks.push(value.slice().buffer as ArrayBuffer);
    }
    let form: FormData;
    try {
      form = await new Response(new Blob(chunks), {
        headers: { "Content-Type": contentType },
      }).formData();
    } catch {
      return reply(
        "This upload could not be read. Choose the recording again.",
        400,
      );
    }
    if (form.get("consent") !== "true")
      return reply(
        "Confirm that this recording may be sent to OpenAI before transcribing.",
        400,
      );
    const uploads = form.getAll("file");
    const file = uploads[0];
    if (uploads.length !== 1 || !(file instanceof File))
      return reply("Choose exactly one MP3 or WAV recording.", 400);
    let mime: "audio/mpeg" | "audio/wav";
    try {
      mime = audioMime(file.size, new Uint8Array(await file.arrayBuffer()));
    } catch (error) {
      return reply(
        error instanceof Error
          ? error.message
          : "This audio format could not be read.",
        file.size > MAX_AUDIO_BYTES ? 413 : 415,
      );
    }
    const upload = new FormData();
    // Send a generic filename; the original may contain private information.
    upload.set(
      "file",
      new Blob([file], { type: mime }),
      mime === "audio/mpeg" ? "recording.mp3" : "recording.wav",
    );
    upload.set("model", model);
    upload.set(
      "prompt",
      "A recorded conversation. Preserve the original words, language, requests, threats, and negation. Do not summarize, translate, or add advice.",
    );
    const response = await fetch(
      "https://api.openai.com/v1/audio/transcriptions",
      {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}` },
        body: upload,
        signal,
      },
    );
    if (!response.ok) {
      if ([401, 403, 404].includes(response.status))
        return reply(
          "Transcription credentials or model access need attention. Contact the app owner or paste a transcript.",
          503,
        );
      if (response.status === 429)
        return reply(
          "The transcription provider's usage limit was reached. Check API billing or try again later.",
          429,
          { "Retry-After": "60" },
        );
      if ([400, 413, 415, 422].includes(response.status))
        return reply(
          "The provider could not read this recording. Try a shorter, clearly recorded MP3 or WAV file.",
          422,
        );
      return reply(
        "The transcription provider is unavailable. Please retry or paste a transcript.",
        502,
      );
    }
    const data = await response.json();
    if (typeof data.text !== "string" || !data.text.trim())
      return reply(
        "No speech was returned. Try a clearer recording or paste the words manually.",
        422,
      );
    if (data.text.length > MAX_TRANSCRIPT_CHARACTERS)
      return reply(
        "This transcript is too long for the review page. Trim the recording and try again.",
        422,
      );
    const languages = Array.isArray(data.languages)
      ? data.languages
          .slice(0, 10)
          .filter(
            (item: unknown): item is { code: string } =>
              !!item &&
              typeof item === "object" &&
              "code" in item &&
              typeof item.code === "string" &&
              /^[a-z]{2,3}(?:-[a-z]{2,4})?$/i.test(item.code),
          )
          .map((item: { code: string }) => item.code.toLowerCase())
      : [];
    return Response.json(
      { text: data.text.trim(), languages, provider: "OpenAI" },
      { headers },
    );
  } catch {
    if (request.signal.aborted)
      return reply("Transcription cancelled. No result was saved.", 499);
    if (deadline.aborted)
      return reply("Transcription timed out. Try a shorter recording.", 504);
    return reply(
      "Transcription could not finish. Check the audio file and retry, or paste a transcript.",
      502,
    );
  } finally {
    signal.removeEventListener("abort", abortRead);
    reader?.releaseLock();
    active = false;
  }
}
