import re
from typing import Dict, List, Pattern


class FraudPattern:
    def __init__(
        self,
        category: str,
        title: str,
        pattern: Pattern,
        severity: str,
        base_points: int,
        description: str,
    ):
        self.category = category
        self.title = title
        self.pattern = pattern
        self.severity = severity
        self.base_points = base_points
        self.description = description


FRAUD_PATTERNS: List[FraudPattern] = [
    # 1. Digital Arrest & Law Enforcement Extortion
    FraudPattern(
        category="Digital Arrest / Authority Impersonation",
        title="Law Enforcement / Digital Arrest Coercion",
        pattern=re.compile(
            r'\b(digital arrest|customs department|cbi officer|police headquarters|arrest warrant|'
            r'narcotics bureau|banned substances|fake passports|cyber crime branch|illegal package|'
            r'money laundering case|mumbai customs|delhi police crime branch)\b',
            re.IGNORECASE,
        ),
        severity="Critical",
        base_points=50,
        description="Police, CBI, Customs, and judicial authorities NEVER conduct arrests or demand settlements over video/phone calls.",
    ),

    # 2. Active Credential Demands (OTP, PIN, Password, CVV)
    FraudPattern(
        category="Credential Harvesting",
        title="Active Credential / OTP Solicitation",
        pattern=re.compile(
            r'\b(share|send|provide|give|reply with|confirm|verify|enter|tell me|read out|forward)\s+'
            r'(your|the|this|that|6-digit|4-digit)?\s*(otp|pin|password|verification code|cvv|secret code|upi pin|atm pin)\b',
            re.IGNORECASE,
        ),
        severity="Critical",
        base_points=45,
        description="Active request for confidential one-time passwords or security PINs. Legitimate institutions never ask for your OTP or PIN.",
    ),

    # 3. National Identity Extortion (Aadhaar & PAN card demands)
    FraudPattern(
        category="Identity Theft Extortion",
        title="Aadhaar / PAN Card Extortion",
        pattern=re.compile(
            r'\b(share|send|provide|give|upload|submit|verify|forward|send copy of|enter)\s+'
            r'(your|the|a)?\s*(pan card|pancard|pan number|pan details|aadhaar|aadhaar card|aadhar|'
            r'aadhar card|aadhaar number|aadhar number|identity proof|national id)\b',
            re.IGNORECASE,
        ),
        severity="High",
        base_points=40,
        description="Unsolicited demands for Aadhaar or PAN card copies pose severe risks of identity theft, unauthorized loans, and SIM-swap attacks.",
    ),

    # 4. Bank Account Suspension & KYC Cutoff Urgency
    FraudPattern(
        category="Banking & KYC Fraud",
        title="Fabricated Banking Suspension Threat",
        pattern=re.compile(
            r'\b(account will be (blocked|suspended|permanently deactivated|frozen)|'
            r'debit card kyc expired|kyc verification pending|update your pan immediately|'
            r'complete kyc within \d+\s*(minutes|hours)|netbanking disabled tonight)\b',
            re.IGNORECASE,
        ),
        severity="High",
        base_points=35,
        description="Threatening imminent account freeze creates artificial panic to force hasty, unverified compliance.",
    ),

    # 5. Remote Access & Malicious APK Installation
    FraudPattern(
        category="Malware & Remote Access",
        title="Remote Access or APK Download Request",
        pattern=re.compile(
            r'\b(install|download|sideload)\s+.*?\b(apk|anydesk|teamviewer|rustdesk|quicksupport|screen share|zoho assist)\b|'
            r'\b(give|grant)\s+(?:me\s+|us\s+)?(remote access|screen control|screen sharing)\b|'
            r'\b(remote access\s+to\s+your\s+banking\s+app)\b',
            re.IGNORECASE,
        ),
        severity="Critical",
        base_points=50,
        description="Instructing users to install unverified APK files or grant remote-control access gives fraudsters full control over banking apps and SMS tokens.",
    ),

    # 6. Utility & Electricity Cutoff Scams
    FraudPattern(
        category="Utility Cutoff Scam",
        title="Urgent Electricity / Utility Cutoff Threat",
        pattern=re.compile(
            r'\b(electricity connection|power supply)\s+(will be|is getting)\s+(disconnected|cut off|stopped)\s+'
            r'(tonight|today|immediately)\b|\bcontact electricity officer\b|\b(mseb|bescom|tneb|dhbvn|uppcl)\b',
            re.IGNORECASE,
        ),
        severity="High",
        base_points=35,
        description="Utility companies never threaten same-night disconnection via personal SMS with mobile phone contact numbers.",
    ),

    # 7. Part-Time Job, YouTube Like & Telegram Task Scams
    FraudPattern(
        category="Task & Investment Scam",
        title="Telegram Task / Work-From-Home Scam",
        pattern=re.compile(
            r'\b(earn\s+(₹|\$|rs\.?)\s*\d+([,\d]*)\s*(to|-)\s*(₹|\$|rs\.?)\s*\d+|'
            r'work from home.*daily payouts|like youtube videos|google maps reviews|'
            r'telegram manager|part-time job.*daily income|prepaid task|guaranteed returns)\b',
            re.IGNORECASE,
        ),
        severity="High",
        base_points=35,
        description="Promising substantial daily earnings for trivial online tasks leads to Telegram investment fraud and upfront 'deposit' traps.",
    ),

    # 8. Unsolicited Demands for Penalty Fees, Recruitment Fees & Security Deposits
    FraudPattern(
        category="Extortion & Fee Fraud",
        title="Unsolicited Penalty or Recruitment Fee Demand",
        pattern=re.compile(
            r'\b(transfer|pay|deposit)\s+(?:a\s+)?(penalty fee|release fee|refundable amount|'
            r'settlement amount|security deposit|clearance charge|customs duty|'
            r'refundable recruitment fee|recruitment fee|registration fee to secure|refundable deposit)\b|'
            r'\brecruitment fee to secure your job\b',
            re.IGNORECASE,
        ),
        severity="High",
        base_points=45,
        description="Demanding upfront 'refundable' fees or registration charges to secure employment or release packages is a signature advance-fee fraud.",
    ),

    # 9. Artificial Urgency Timers & Panic Triggers
    FraudPattern(
        category="Psychological Manipulation",
        title="Artificial Deadline Panic",
        pattern=re.compile(
            r'\b(within\s+\d+\s*(minutes|mins)|in\s+\d+\s*(minutes|mins)|immediately|right now|'
            r'urgent action required|last warning|final notice before legal action)\b',
            re.IGNORECASE,
        ),
        severity="Medium",
        base_points=20,
        description="Artificial countdowns prevent users from consulting family, bank officials, or official helplines.",
    ),

    # 10. QR Code Scam / Reverse Payment Demands
    FraudPattern(
        category="Payment Scam",
        title="Reverse Payment / QR Code Trap",
        pattern=re.compile(
            r'\b(scan\s+(this\s+)?qr\s+code\s+to\s+receive|enter\s+pin\s+to\s+credit|upi pin.*receive money)\b',
            re.IGNORECASE,
        ),
        severity="Critical",
        base_points=45,
        description="Entering a UPI PIN or scanning a merchant QR code NEVER receives money—it only authorizes a debit from your account.",
    ),
]
