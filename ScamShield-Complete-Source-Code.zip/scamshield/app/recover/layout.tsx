import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Recovery planner | ScamShield",
  description:
    "Create a practical checklist after sharing credentials, sending money, clicking a link, or granting device access.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
