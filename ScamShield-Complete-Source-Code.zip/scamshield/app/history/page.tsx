"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  ChevronDown,
  Download,
  History,
  Info,
  LockKeyhole,
  Search,
  Trash2,
  Undo2,
} from "lucide-react";
import {
  downloadText,
  HISTORY_KEY,
  readHistory,
  type SavedScan,
} from "@/lib/storage";
import { verdictLabels } from "@/lib/link-review";
import { useCloudHistory } from "@/components/cloud-history-provider";
import { getSupabase } from "@/lib/supabase/client";
import {
  CLOUD_PAGE_SIZE,
  fetchChecks,
  deleteCloudCheck,
  historyError,
} from "@/lib/cloud-history";
export default function HistoryPage() {
  const [localScans, setScans] = useState<SavedScan[]>([]);
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [undo, setUndo] = useState<SavedScan[] | null>(null);
  const [notice, setNotice] = useState("");
  const cloud = useCloudHistory();
  const [source, setSource] = useState<"device" | "cloud">("device");
  const [cloudRows, setCloudRows] = useState<SavedScan[]>([]);
  const [cloudOwner, setCloudOwner] = useState("");
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudError, setCloudError] = useState("");
  const [more, setMore] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [importing, setImporting] = useState(false);
  const generation = useRef(0);
  const userId = cloud.user?.id;
  const cloudView = source === "cloud";
  const scans = cloudView
    ? cloudOwner === userId
      ? cloudRows
      : []
    : localScans;
  useEffect(() => {
    const current = ++generation.current;
    setCloudRows([]);
    setCloudOwner("");
    setCloudError("");
    setMore(false);
    const client = getSupabase();
    if (!cloudView || !userId || !client) {
      setCloudBusy(false);
      return;
    }
    setCloudBusy(true);
    fetchChecks(client, userId)
      .then((rows) => {
        if (generation.current !== current) return;
        setCloudRows(rows);
        setCloudOwner(userId);
        setMore(rows.length === CLOUD_PAGE_SIZE);
      })
      .catch((e) => {
        if (generation.current === current) setCloudError(historyError(e));
      })
      .finally(() => {
        if (generation.current === current) setCloudBusy(false);
      });
    return () => {
      generation.current++;
    };
  }, [cloudView, userId, cloud.revision, refresh]);
  async function loadMore() {
    const client = getSupabase();
    if (!client || !userId || cloudBusy) return;
    const current = generation.current;
    setCloudBusy(true);
    setCloudError("");
    try {
      const rows = await fetchChecks(client, userId, cloudRows.length);
      if (current !== generation.current) return;
      setCloudRows((previous) => [
        ...new Map([...previous, ...rows].map((s) => [s.id, s])).values(),
      ]);
      setMore(rows.length === CLOUD_PAGE_SIZE);
    } catch (e) {
      if (current === generation.current) setCloudError(historyError(e));
    } finally {
      if (current === generation.current) setCloudBusy(false);
    }
  }
  async function removeCloud(id: string) {
    const client = getSupabase();
    if (!client || !userId || cloudBusy) return;
    const current = generation.current;
    setCloudBusy(true);
    setCloudError("");
    try {
      await deleteCloudCheck(client, userId, id);
      if (current === generation.current) setRefresh((n) => n + 1);
    } catch (e) {
      if (current === generation.current) setCloudError(historyError(e));
    } finally {
      if (current === generation.current) setCloudBusy(false);
    }
  }
  useEffect(() => {
    setScans(readHistory());
    setReady(true);
    const sync = () => setScans(readHistory());
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  function write(next: SavedScan[], saveUndo = true) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      if (saveUndo) setUndo(localScans);
      setScans(next);
      setNotice(
        saveUndo
          ? "History updated. You can undo this change."
          : "Change undone.",
      );
    } catch {
      setNotice("Browser storage could not be updated.");
    }
  }
  const visible = scans.filter(
    (s) =>
      (filter === "all" || s.assessment.tone === filter) &&
      `${s.preview} ${s.source || s.channel} ${s.channel} ${s.assessment.risk} ${s.assessment.summary}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <main id="main-content" className="main-wrap subpage">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span />
            YOUR CHECKS. YOUR CHOICE.
          </span>
          <h1>
            A little <span>perspective.</span>
          </h1>
          <p>
            Review the checks you chose to save. Only redacted summaries are
            kept here.
          </p>
        </div>
        <span className="page-emblem">
          <History size={34} strokeWidth={1.3} />
        </span>
      </div>
      <section className="cloud-history-card" aria-label="History storage">
        <div className="cloud-card-heading">
          <div>
            <span className="section-label">HISTORY STORAGE</span>
            <h2>
              {cloud.user
                ? "Your device and your account."
                : "Keep it here. Or take it with you."}
            </h2>
          </div>
          <button
            className="secondary-button"
            onClick={cloud.openAuth}
            aria-haspopup="dialog"
          >
            {cloud.user ? "Account settings" : "Sign in / create account"}
            <ArrowRight size={15} />
          </button>
        </div>
        {cloud.user ? (
          <>
            <div
              className="filter-group"
              role="group"
              aria-label="Choose history location"
            >
              <button
                aria-pressed={!cloudView}
                onClick={() => {
                  setSource("device");
                  setNotice("");
                }}
              >
                This device
              </button>
              <button
                aria-pressed={cloudView}
                onClick={() => {
                  setSource("cloud");
                  setNotice("");
                }}
              >
                My cloud history
              </button>
            </div>
            <label className="cloud-toggle">
              <input
                type="checkbox"
                checked={cloud.enabled}
                onChange={(e) => cloud.setEnabled(e.target.checked)}
              />
              <span>
                <strong>Sync new saved checks</strong>
                <small>
                  Only checks with their save option selected are synced. Raw
                  screenshots and audio are excluded.
                </small>
              </span>
            </label>
            <p className="small-note">
              Signed in as {cloud.user.email}. Device records may belong to
              anyone who used this browser. Review the device list before
              importing. Re-importing updates matching records without creating
              duplicates.
            </p>
            <div className="cloud-card-actions">
              <button
                className="secondary-button"
                disabled={importing || !localScans.length}
                onClick={async () => {
                  setImporting(true);
                  try {
                    await cloud.upload(readHistory());
                  } finally {
                    setImporting(false);
                  }
                }}
              >
                {importing
                  ? "Uploading…"
                  : `Upload ${localScans.length} device checks to my account`}
              </button>
              {cloudView && (
                <button
                  className="secondary-button"
                  disabled={cloudBusy}
                  onClick={() => setRefresh((n) => n + 1)}
                >
                  Refresh cloud history
                </button>
              )}
              {cloud.pending > 0 && (
                <button
                  className="secondary-button"
                  disabled={importing}
                  onClick={async () => {
                    setImporting(true);
                    try {
                      await cloud.retry();
                    } finally {
                      setImporting(false);
                    }
                  }}
                >
                  Retry {cloud.pending} unsaved cloud checks
                </button>
              )}
            </div>
            {cloud.status && <p role="status">{cloud.status}</p>}
            {cloud.error && (
              <p className="account-error" role="alert">
                {cloud.error}
              </p>
            )}
          </>
        ) : (
          <p>
            {cloud.loading
              ? "Checking sign-in…"
              : cloud.configured
                ? "Sign in to keep redacted check summaries across devices. Device history works without an account."
                : "Cloud setup is pending. Device history works now; the project owner can enable Supabase using SUPABASE.md."}
          </p>
        )}
      </section>
      {cloudView && !cloud.user && (
        <p className="history-notice">
          Sign in to view your cloud records, or{" "}
          <button onClick={() => setSource("device")}>
            return to device history
          </button>
          .
        </p>
      )}
      {cloudError && (
        <p className="account-error" role="alert">
          {cloudError}{" "}
          <button
            className="secondary-button"
            disabled={cloudBusy}
            onClick={() => setRefresh((n) => n + 1)}
          >
            Retry cloud history
          </button>
        </p>
      )}
      <div className="history-stats">
        <div>
          <span>Saved checks</span>
          <strong>
            {scans.length}
            <small>
              {cloudView ? "loaded from your account" : "/ 20 most recent"}
            </small>
          </strong>
        </div>
        <div>
          <span>Higher-risk checks</span>
          <strong>
            {scans.filter((s) => s.assessment.tone === "danger").length}
            <small>worth reviewing</small>
          </strong>
        </div>
        <div>
          <LockKeyhole size={18} />
          <strong>{cloudView ? "In your account" : "On this device"}</strong>
          <span>
            {cloudView
              ? "Private cloud records"
              : "Device records are kept separately"}
          </span>
        </div>
      </div>
      <div className="history-toolbar">
        <label className="search-field">
          <Search size={15} />
          <input
            aria-label="Search saved checks"
            placeholder="Search your summaries…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <div className="filter-group" role="group" aria-label="Filter by risk">
          {[
            ["all", "All"],
            ["danger", "High risk"],
            ["warning", "Caution"],
            ["safe", "Low risk"],
            ["neutral", "Unverified"],
          ].map(([id, label]) => (
            <button
              key={id}
              aria-pressed={filter === id}
              onClick={() => setFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          className="secondary-button"
          disabled={!scans.length}
          onClick={() =>
            downloadText(
              "scamshield-history.json",
              JSON.stringify(
                {
                  exportedAt: new Date().toISOString(),
                  location: source,
                  scope: cloudView
                    ? "Loaded cloud records only"
                    : "Device records",
                  note: "Redacted summaries; heuristic assessments, not verified fraud records.",
                  scans,
                },
                null,
                2,
              ),
              "application/json",
            )
          }
        >
          <Download size={14} /> {cloudView ? "Export loaded" : "Export"}
        </button>
        <button
          className="icon-button"
          aria-label="Clear saved history"
          title="Clear saved history"
          disabled={cloudView || !scans.length}
          onClick={() => write([])}
        >
          <Trash2 size={15} />
        </button>
      </div>
      {!cloudView && (notice || undo) && (
        <div className="history-notice" role="status">
          <span>{notice}</span>
          {undo && (
            <button
              onClick={() => {
                write(undo, false);
                setUndo(null);
              }}
            >
              <Undo2 size={13} /> Undo
            </button>
          )}
        </div>
      )}
      {!ready || (cloudView && cloudBusy && !scans.length) ? (
        <p className="muted" role="status">
          {cloudView
            ? "Loading your cloud history…"
            : "Loading this device’s history…"}
        </p>
      ) : visible.length ? (
        <div className="history-list">
          {visible.map((scan) => (
            <article key={scan.id} className="history-item">
              <div className="history-item-top">
                <span className={`risk-badge ${scan.assessment.tone}`}>
                  <span />
                  {scan.assessment.aiReview ? "Basic: " : ""}
                  {scan.assessment.risk}
                </span>
                {scan.assessment.aiReview && (
                  <span
                    className={`risk-badge ${scan.assessment.aiReview.verdict === "suspicious" ? "warning" : "neutral"}`}
                  >
                    AI: {verdictLabels[scan.assessment.aiReview.verdict]}
                  </span>
                )}
                <span className="history-channel">
                  {scan.source === "screenshot"
                    ? "Screenshot"
                    : scan.source === "audio"
                      ? "Audio"
                      : scan.channel === "url"
                        ? "Link"
                        : scan.channel === "call"
                          ? "Call"
                          : "Message"}{" "}
                  · {new Date(scan.createdAt).toLocaleString()}
                </span>
                {scan.assessment.score !== null ? (
                  <strong>
                    {scan.assessment.score}
                    <small>/100</small>
                  </strong>
                ) : (
                  <strong className="unscored-label">Not scored</strong>
                )}
                <button
                  className="icon-button"
                  aria-label={`Remove check from ${new Date(scan.createdAt).toLocaleString()}`}
                  disabled={cloudBusy}
                  onClick={() =>
                    cloudView
                      ? void removeCloud(scan.id)
                      : write(scans.filter((s) => s.id !== scan.id))
                  }
                >
                  <Trash2 size={14} />
                </button>
              </div>
              <p className="history-preview">{scan.preview}</p>
              <details>
                <summary>
                  Review findings
                  <ChevronDown size={14} />
                </summary>
                <p>{scan.assessment.summary}</p>
                {scan.assessment.aiReview && (
                  <div className="saved-ai-review">
                    <strong>AI page review</strong>
                    <p>{scan.assessment.aiReview.summary}</p>
                    <p>
                      {scan.assessment.aiReview.pageRead
                        ? "Page content retrieved"
                        : "Page content not verified"}{" "}
                      ·{" "}
                      {new Date(
                        scan.assessment.aiReview.checkedAt,
                      ).toLocaleString()}
                    </p>
                    {scan.assessment.aiReview.findings.map((finding, i) => (
                      <p key={i}>{finding}</p>
                    ))}
                  </div>
                )}
                {scan.assessment.signals.map((s, i) => (
                  <p key={i}>
                    <strong>{s.title}</strong> — {s.description}
                  </p>
                ))}
                <span className="small-note">
                  This saved summary cannot reconstruct the full original
                  message.
                </span>
              </details>
            </article>
          ))}
        </div>
      ) : (
        <div className="large-empty">
          <History size={36} strokeWidth={1.2} />
          <h2>
            {scans.length
              ? "No matching checks."
              : "Your history starts with a choice."}
          </h2>
          <p>
            {scans.length
              ? "Try another search or risk filter."
              : cloudView
                ? "Save a new check with sync enabled, or upload the device checks you choose to keep."
                : "Enable “Save redacted summaries” in the checker to keep up to 20 recent checks on this device."}
          </p>
          <Link href="/" className="primary-button">
            Go to checker
            <ArrowRight size={15} />
          </Link>
        </div>
      )}
      {cloudView && more && (
        <button
          className="secondary-button"
          disabled={cloudBusy}
          onClick={loadMore}
        >
          {cloudBusy ? "Loading…" : "Load more checks"}
        </button>
      )}
      {cloudView && (
        <p className="small-note">
          Search, filters and export apply to loaded records. Removing a cloud
          record does not remove its separate device copy.
        </p>
      )}
      <div className="assistant-footnote">
        <Info size={14} />
        <p>
          Redaction removes common numbers, codes, and email patterns. It cannot
          recognize every sensitive detail. Anyone using this browser profile
          may see device summaries. Clearing browser data removes device
          history, but cloud records remain in your account until you remove
          them from the cloud view. Signing out hides your cloud list on this
          browser.
        </p>
      </div>
    </main>
  );
}
