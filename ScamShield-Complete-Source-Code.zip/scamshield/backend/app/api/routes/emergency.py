from fastapi import APIRouter
from app.schemas.requests import EmergencyRequest
from app.schemas.responses import EmergencyResponse
from app.services.emergency_service import get_emergency_response

router = APIRouter(tags=["Emergency Response"])


@router.post("/emergency", response_model=EmergencyResponse)
async def handle_emergency_scenario(request: EmergencyRequest):
    """
    Delivers prioritized emergency response steps for victims who may have shared credentials,
    transferred money, installed a malicious APK, or faced extortion.
    Includes Indian National Cyber Crime Helpline (1930) and golden-hour containment checklists.
    """
    return get_emergency_response(request)
