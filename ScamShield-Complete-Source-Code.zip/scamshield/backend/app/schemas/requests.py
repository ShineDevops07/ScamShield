from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


class ContentTypeEnum(str, Enum):
    MESSAGE = "message"
    EMAIL = "email"
    CHAT = "chat"
    CALL = "call"


class AnalyzeRequest(BaseModel):
    message: str = Field(
        ...,
        min_length=1,
        max_length=10000,
        description="The content of the message, SMS, chat, or call transcript to analyze",
    )
    content_type: ContentTypeEnum = Field(
        default=ContentTypeEnum.MESSAGE,
        description="Type of digital communication: message, email, chat, or call",
    )
    language: Optional[str] = Field(
        default="en",
        max_length=20,
        description="Optional language code or hint (e.g. en, hi)",
    )
    sender: Optional[str] = Field(
        default=None,
        max_length=150,
        description="User-provided sender information (e.g. phone number, email address, SMS header)",
    )
    url: Optional[str] = Field(
        default=None,
        max_length=2048,
        description="Optional explicit URL supplied for inspection",
    )
    context: Optional[str] = Field(
        default=None,
        max_length=2000,
        description="Optional background or conversation context",
    )

    @field_validator("message")
    @classmethod
    def validate_message_not_empty(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("Message cannot be empty or only whitespace")
        return stripped


class FrontendAnalyzeRequest(BaseModel):
    """Compatibility request model matching the frontend payload shape."""
    type: Optional[str] = Field(default="message")
    text: str = Field(..., min_length=1, max_length=10000)
    sender: Optional[str] = Field(default=None, max_length=150)
    subject: Optional[str] = Field(default=None, max_length=200)


class AnalyzeURLRequest(BaseModel):
    url: str = Field(
        ...,
        min_length=3,
        max_length=2048,
        description="The URL submitted for syntax, domain and threat analysis",
    )
    allow_dns_check: Optional[bool] = Field(
        default=False,
        description="Whether to perform safe non-HTTP DNS domain resolution if permitted",
    )

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("URL cannot be empty")
        return stripped


class FollowUpRequest(BaseModel):
    analysis_id: Optional[str] = Field(
        default=None,
        description="Unique identifier from a previous analysis result",
    )
    analysis_summary: Optional[str] = Field(
        default=None,
        max_length=2000,
        description="Optional previous analysis summary or verdict if analysis_id is not cached",
    )
    question: str = Field(
        ...,
        min_length=2,
        max_length=1000,
        description="Specific question regarding the analysis, verdict, or safe next steps",
    )
    context: Optional[str] = Field(
        default=None,
        max_length=2000,
        description="Optional extra context",
    )


class EmergencyScenarioEnum(str, Enum):
    OTP_SHARED = "otp_shared"
    CREDENTIALS_LEAKED = "credentials_leaked"
    MONEY_SENT = "money_sent"
    APK_INSTALLED = "apk_installed"
    REMOTE_ACCESS_GRANTED = "remote_access_granted"
    LINK_CLICKED = "link_clicked"
    ID_DOCUMENTS_SHARED = "id_documents_shared"
    EXTORTION_BLACKMAIL = "extortion_blackmail"
    GENERAL = "general"


class EmergencyRequest(BaseModel):
    scenario: EmergencyScenarioEnum = Field(
        ...,
        description="Specific emergency incident type",
    )
    details: Optional[str] = Field(
        default=None,
        max_length=2000,
        description="Brief details of what occurred",
    )
    bank_name: Optional[str] = Field(
        default=None,
        max_length=100,
        description="Name of bank or financial service involved",
    )
    payment_method: Optional[str] = Field(
        default=None,
        max_length=50,
        description="Payment mode used (e.g. UPI, IMPS, NEFT, Credit Card)",
    )
    amount_lost: Optional[str] = Field(
        default=None,
        max_length=50,
        description="Approximate amount involved if any",
    )
