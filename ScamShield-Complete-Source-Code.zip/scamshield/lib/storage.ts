import type { AnalysisTab, Assessment } from "./analysis";
import { analyzeRisk, looksLikePaymentReceipt } from "./analysis";
export const HISTORY_KEY = "scamshield.history.v2";
export const LATEST_KEY = "scamshield.latest.v2";
export const SAVE_KEY = "scamshield.save-history.v2";
export const HISTORY_SAVED_EVENT = "scamshield:history-saved";
export type ScanSource = "message" | "call" | "url" | "screenshot" | "audio";
export interface SavedScan {
  id: string;
  createdAt: string;
  channel: AnalysisTab;
  source?: ScanSource;
  preview: string;
  assessment: Assessment;
}
function upgradeLegacyReceipt(scan: SavedScan): SavedScan {
  if (
    scan.channel !== "url" &&
    !scan.assessment.kind &&
    scan.assessment.score !== null &&
    scan.assessment.score < 25 &&
    looksLikePaymentReceipt(scan.preview)
  ) {
    return { ...scan, assessment: analyzeRisk(scan.preview, scan.channel) };
  }
  return scan;
}
export function redactSensitive(text: string) {
  return text
    .replace(/\b[A-Z]{5}\d{4}[A-Z]\b/gi, "[ID removed]")
    .replace(/\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b/gi, "[email removed]")
    .replace(/\b(?:\d[ -]?){10,19}\b/g, "[number removed]")
    .replace(
      /\b(?:otp|pin|code|password|cvv)\s*(?:is|:|=)?\s*\d{3,8}\b/gi,
      "[security code removed]",
    )
    .replace(/\b\d{4,8}\b/g, (m) => (m === "1930" ? m : "[number removed]"));
}
export function safeAiReview(value: unknown): Assessment["aiReview"] {
  if (!value || typeof value !== "object") return undefined;
  const a = value as NonNullable<Assessment["aiReview"]>;
  if (
    !["suspicious", "no_clear_red_flags", "inconclusive"].includes(a.verdict) ||
    typeof a.summary !== "string" ||
    typeof a.pageRead !== "boolean" ||
    !Number.isFinite(Date.parse(a.checkedAt)) ||
    !Array.isArray(a.findings) ||
    a.findings.some((s) => typeof s !== "string")
  )
    return undefined;
  return {
    verdict: a.verdict,
    summary: redactSensitive(a.summary).slice(0, 1200),
    pageRead: a.pageRead,
    checkedAt: new Date(a.checkedAt).toISOString(),
    findings: a.findings
      .slice(0, 8)
      .map((s) => redactSensitive(s).slice(0, 600)),
  };
}
export function safeScan(
  content: string,
  channel: AnalysisTab,
  assessment: Assessment,
  source: ScanSource = channel,
): SavedScan {
  return {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    channel,
    source,
    preview: redactSensitive(content).slice(0, 160),
    assessment: {
      ...assessment,
      ...(assessment.aiReview
        ? { aiReview: safeAiReview(assessment.aiReview) }
        : {}),
      risk: redactSensitive(assessment.risk),
      summary: redactSensitive(assessment.summary),
      signals: assessment.signals.map((s) => ({
        ...s,
        title: redactSensitive(s.title),
        description: redactSensitive(s.description),
        excerpt: redactSensitive(s.excerpt).slice(0, 160),
      })),
    },
  };
}
export function readHistory(): SavedScan[] {
  try {
    const value = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(value)
      ? value
          .filter(
            (x) =>
              x &&
              typeof x.id === "string" &&
              typeof x.preview === "string" &&
              typeof x.createdAt === "string" &&
              ["message", "call", "url"].includes(x.channel) &&
              x.assessment &&
              ((x.assessment.score === null &&
                x.assessment.kind === "payment_receipt") ||
                (Number.isFinite(x.assessment.score) &&
                  x.assessment.score >= 0 &&
                  x.assessment.score <= 100)) &&
              ["neutral", "danger", "warning", "safe"].includes(
                x.assessment.tone,
              ) &&
              typeof x.assessment.risk === "string" &&
              typeof x.assessment.summary === "string" &&
              Array.isArray(x.assessment.signals) &&
              x.assessment.signals.every(
                (s: unknown) =>
                  s &&
                  typeof s === "object" &&
                  "title" in s &&
                  "description" in s &&
                  "excerpt" in s &&
                  typeof s.title === "string" &&
                  typeof s.description === "string" &&
                  typeof s.excerpt === "string",
              ),
          )
          .slice(0, 20)
          .map(upgradeLegacyReceipt)
          .map((scan) => ({
            ...scan,
            assessment: {
              ...scan.assessment,
              ...(scan.assessment.aiReview
                ? { aiReview: safeAiReview(scan.assessment.aiReview) }
                : {}),
            },
          }))
      : [];
  } catch {
    return [];
  }
}
export function remember(scan: SavedScan, save: boolean) {
  let stored = true;
  try {
    sessionStorage.setItem(LATEST_KEY, JSON.stringify(scan));
    if (save)
      localStorage.setItem(
        HISTORY_KEY,
        JSON.stringify(
          [scan, ...readHistory().filter((s) => s.id !== scan.id)].slice(0, 20),
        ),
      );
  } catch {
    stored = false;
  }
  if (save && typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent(HISTORY_SAVED_EVENT, { detail: scan }),
    );
  return stored;
}
export function latestScan(): SavedScan | null {
  try {
    const scan = JSON.parse(sessionStorage.getItem(LATEST_KEY) || "null");
    return scan?.assessment && typeof scan.assessment.summary === "string"
      ? upgradeLegacyReceipt(scan)
      : null;
  } catch {
    return null;
  }
}
export function downloadText(
  name: string,
  content: string,
  type = "text/plain",
) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
