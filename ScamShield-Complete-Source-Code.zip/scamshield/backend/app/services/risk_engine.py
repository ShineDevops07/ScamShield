from typing import Any, Dict, List, Tuple
from app.core.config import settings
from app.schemas.responses import EvidenceItem, RiskLevelEnum, SeverityEnum


class RiskScoreAssessment:
    def __init__(
        self,
        risk_score: int,
        risk_level: RiskLevelEnum,
        confidence: str,
        verdict: str,
        summary: str,
        recommended_actions: List[str],
        what_not_to_do: List[str],
        uncertainty: List[str],
        verification_steps: List[str],
        limitations: List[str],
    ):
        self.risk_score = risk_score
        self.risk_level = risk_level
        self.confidence = confidence
        self.verdict = verdict
        self.summary = summary
        self.recommended_actions = recommended_actions
        self.what_not_to_do = what_not_to_do
        self.uncertainty = uncertainty
        self.verification_steps = verification_steps
        self.limitations = limitations


def synthesize_risk_score(
    base_score: int,
    evidence_items: List[EvidenceItem],
    is_security_advisory: bool = False,
    is_quoted_or_reporting: bool = False,
    is_pure_otp: bool = False,
    is_benign_commerce: bool = False,
) -> RiskScoreAssessment:
    """
    Synthesizes a bounded, transparent risk assessment.
    Combines observed and inferred indicators with diminishing returns to prevent false escalation.
    """
    final_score = base_score

    # Re-evaluate evidence for critical multipliers
    has_credential_demand = any(
        "Credential" in e.description or "OTP" in e.description
        for e in evidence_items
        if e.severity in (SeverityEnum.HIGH, SeverityEnum.CRITICAL) and e.evidence_type.value == "observed"
    )
    has_urgency = any(
        "Panic" in e.description or "Urgency" in e.description or "Suspension" in e.description
        for e in evidence_items
    )
    has_remote_access = any(
        "Remote Access" in e.description or "APK" in e.description
        for e in evidence_items
    )
    has_digital_arrest = any(
        "Digital Arrest" in e.description or "Law Enforcement" in e.description
        for e in evidence_items
    )

    # Compound synergy penalty (e.g. Credential Demand + Artificial Urgency)
    if has_credential_demand and has_urgency and not is_security_advisory:
        final_score = max(final_score, 85)

    if (has_remote_access or has_digital_arrest) and not is_security_advisory:
        final_score = max(final_score, 88)

    # Absolute clamp
    final_score = max(0, min(100, final_score))

    # Map to configured bands (0-19: Low, 20-49: Caution, 50-79: High, 80-100: Critical)
    if final_score >= settings.RISK_THRESHOLD_CRITICAL:
        risk_level = RiskLevelEnum.CRITICAL
    elif final_score >= settings.RISK_THRESHOLD_HIGH:
        risk_level = RiskLevelEnum.HIGH
    elif final_score >= settings.RISK_THRESHOLD_CAUTION:
        risk_level = RiskLevelEnum.CAUTION
    else:
        risk_level = RiskLevelEnum.LOW

    # Separate Confidence Metric (calibrated based on specificity of signals)
    if is_security_advisory or is_pure_otp or is_benign_commerce:
        confidence = "High (deterministic negation and benign commerce heuristics matched verified protective patterns)"
    elif has_credential_demand or has_remote_access or has_digital_arrest:
        confidence = "High (explicit overt malicious extortion signals directly observed in input text)"
    elif len(evidence_items) > 0:
        confidence = "Medium (contextual heuristics detected cautionary cues; intent relies on inferred markers)"
    else:
        confidence = "Low (sparse content; evaluation is approximate due to limited context)"

    # Formulate verdict, summary, and action guidance
    recommended_actions: List[str] = []
    what_not_to_do: List[str] = []
    uncertainty: List[str] = []
    verification_steps: List[str] = []
    limitations: List[str] = [
        "Risk scores represent heuristic threat severity estimates, not empirical statistical probabilities of fraud.",
        "Low risk assessments do NOT prove authenticity or legitimate sender identity.",
        "Communications can be spoofed; always verify unexpected requests through trusted out-of-band channels.",
    ]

    if risk_level in (RiskLevelEnum.CRITICAL, RiskLevelEnum.HIGH):
        verdict = "Severe scam threat detected with active social engineering or credential harvesting tactics."
        summary = (
            "The message contains high-risk fraud indicators such as urgent demands for security codes, "
            "coercive law enforcement threats, or deceptive links."
        )
        recommended_actions.extend([
            "Immediately disconnect the call or delete the message without replying.",
            "Block the sender number or address on your communication device.",
            "Report the fraud attempt to the National Cyber Crime Portal (cybercrime.gov.in) or dial 1930 (India).",
        ])
        what_not_to_do.extend([
            "DO NOT share any 4-digit or 6-digit OTP, UPI PIN, ATM PIN, or passwords.",
            "DO NOT click any link or download APK files sent via SMS or messaging apps.",
            "DO NOT transfer money, penalty amounts, or refundable security deposits under pressure.",
            "DO NOT install remote screen-sharing tools like AnyDesk, TeamViewer, or RustDesk.",
        ])
        verification_steps.extend([
            "If the sender claims to represent a bank or service, open your bank app directly or dial the official phone number on the back of your debit card.",
            "If police or customs action is claimed, note that Indian law enforcement conducts official proceedings in person, never via WhatsApp video or phone calls.",
        ])

    elif risk_level == RiskLevelEnum.CAUTION:
        verdict = "Ambiguous communication with cautionary cues requiring independent verification."
        summary = (
            "The content exhibits pressure tactics, unfamiliar links, or unverified claims that warrant "
            "double-checking before taking any action."
        )
        recommended_actions.extend([
            "Pause and evaluate whether you initiated this transaction or inquiry.",
            "Check official websites directly by manually typing the web address.",
        ])
        what_not_to_do.extend([
            "DO NOT follow instructions sent in unexpected messages without independent corroboration.",
            "DO NOT share sensitive personal documentation (PAN/Aadhaar) through informal channels.",
        ])
        verification_steps.extend([
            "Log in to the official portal directly through your bookmarked link or mobile app to check notification status.",
            "Contact customer care through numbers listed on their verified official website.",
        ])

    else:
        # LOW RISK
        if is_security_advisory:
            verdict = "Protective security advisory instructing users to safeguard confidential credentials."
            summary = (
                "Sentence analysis verifies this is a defensive security warning from an institution "
                "educating users against sharing passwords or OTPs."
            )
            recommended_actions.extend([
                "Heed the advisory instructions and continue keeping your credentials confidential.",
            ])
            what_not_to_do.extend([
                "Never share your OTP or security PIN with anyone, even if they claim to work for the sender institution.",
            ])
        elif is_pure_otp:
            verdict = "Transactional authentication notice. Keep the delivered verification code private."
            summary = (
                "This message delivers a generated one-time security code. While standard for logins, "
                "the code itself must never be disclosed to third parties."
            )
            recommended_actions.extend([
                "Use the code only in the authentic application you just initiated.",
            ])
            what_not_to_do.extend([
                "DO NOT read this code aloud, forward it, or share it on phone calls or chats.",
            ])
        elif is_quoted_or_reporting:
            verdict = "Quoted or educational scam inquiry without active threat execution."
            summary = (
                "The text discusses or inquires about a scam scenario in an educational or reporting context."
            )
            recommended_actions.extend([
                "Continue reporting suspicious attempts to your service provider or cyber authorities.",
            ])
            what_not_to_do.extend([
                "Never engage with suspected scammers to test or bait them.",
            ])
        else:
            verdict = "No overt extortion, credential harvesting, or deceptive threat cues detected."
            summary = (
                "The submitted message does not match known high-risk scam heuristics, but always remain vigilant."
            )
            recommended_actions.extend([
                "Maintain standard digital hygiene when dealing with unsolicited communications.",
            ])
            what_not_to_do.extend([
                "Never send financial transfers or passwords to unverified contacts.",
            ])

        verification_steps.extend([
            "Verify sender identity if the message requests unexpected changes to your account or schedule.",
        ])

    if not is_security_advisory and not has_credential_demand:
        uncertainty.append(
            "Sender authenticity cannot be confirmed by message text alone without cryptographic or carrier-level verification."
        )

    return RiskScoreAssessment(
        risk_score=final_score,
        risk_level=risk_level,
        confidence=confidence,
        verdict=verdict,
        summary=summary,
        recommended_actions=recommended_actions,
        what_not_to_do=what_not_to_do,
        uncertainty=uncertainty,
        verification_steps=verification_steps,
        limitations=limitations,
    )
