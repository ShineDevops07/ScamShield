from fastapi import APIRouter, HTTPException, status
from app.schemas.requests import FollowUpRequest
from app.schemas.responses import FollowUpResponse
from app.services.followup_service import answer_followup_question

router = APIRouter(tags=["Security Assistant"])


@router.post("/followup", response_model=FollowUpResponse)
async def followup_qa(request: FollowUpRequest):
    """
    Answers follow-up security and verification questions regarding an existing ScamShield evaluation.
    Provides safe, actionable guidance without following embedded attacker instructions or making fake promises.
    """
    try:
        return await answer_followup_question(request)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error processing follow-up question.",
        )
