import pytest
from httpx import ASGITransport, AsyncClient
from main import app


@pytest.mark.asyncio
async def test_emergency_otp_shared():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "scenario": "otp_shared",
            "bank_name": "State Bank of India",
        }
        res = await client.post("/api/v1/emergency", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert data["scenario"] == "otp_shared"
        assert len(data["immediate_actions"]) >= 3
        # Check first priority is freeze
        assert "freeze" in data["immediate_actions"][0]["action"].lower()
        # Verify 1930 reporting channel present
        assert any("1930" in ch["contact"] for ch in data["reporting_channels"])


@pytest.mark.asyncio
async def test_emergency_money_sent():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "scenario": "money_sent",
            "amount_lost": "₹25,000",
            "payment_method": "UPI",
            "bank_name": "HDFC Bank",
        }
        res = await client.post("/api/v1/emergency", json=payload)
        assert res.status_code == 200
        data = res.json()
        assert any("golden hour" in a["action"].lower() or "1930" in a["action"].lower() for a in data["immediate_actions"])
        # Check reality check against recovery scammers
        assert "hack back" in data["recovery_reality_check"].lower() or "beware" in data["recovery_reality_check"].lower()
