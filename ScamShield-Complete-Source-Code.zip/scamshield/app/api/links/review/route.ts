import { reviewableUrl } from "@/lib/link-review";
import { reviewLink } from "@/lib/link-review-server";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
const headers = { "Cache-Control": "no-store" };
let requests: number[] = [];
let active = 0;
export async function GET() {
  return Response.json(
    { available: !!process.env.GEMINI_API_KEY, provider: "Gemini" },
    { headers },
  );
}
export async function POST(request: Request) {
  if (!request.headers.get("content-type")?.includes("application/json"))
    return Response.json(
      { error: "Send a JSON link request." },
      { status: 415, headers },
    );
  let url: string;
  try {
    const reader = request.body?.getReader();
    if (!reader) throw Error("empty_body");
    let raw = "",
      size = 0;
    const decoder = new TextDecoder();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 4096) {
        await reader.cancel();
        return Response.json(
          { error: "Link request is too large." },
          { status: 413, headers },
        );
      }
      raw += decoder.decode(value, { stream: true });
    }
    raw += decoder.decode();
    const data = JSON.parse(raw);
    url = reviewableUrl(data?.url);
  } catch (e) {
    return Response.json(
      {
        error:
          e instanceof SyntaxError
            ? "Invalid JSON request."
            : e instanceof Error && e.message !== "empty_body"
              ? e.message
              : "Enter a public website link.",
      },
      { status: 400, headers },
    );
  }
  if (!process.env.GEMINI_API_KEY)
    return Response.json(
      {
        error:
          "AI page review is not connected yet. Basic link inspection is available.",
      },
      { status: 503, headers },
    );
  const now = Date.now();
  requests = requests.filter((t) => t > now - 60000);
  if (requests.length >= 10 || active >= 3)
    return Response.json(
      { error: "AI review is busy. Wait a minute and retry." },
      { status: 429, headers: { ...headers, "Retry-After": "60" } },
    );
  requests.push(now);
  active++;
  try {
    const signal = AbortSignal.any([
      request.signal,
      AbortSignal.timeout(45000),
    ]);
    const review = await reviewLink(url, signal);
    return Response.json({ review }, { headers });
  } catch (e) {
    const reason = e instanceof Error ? e.message : "";
    const error =
      reason === "provider_quota"
        ? "The AI provider’s quota is temporarily unavailable. Try again later."
        : ["provider_auth", "configuration"].includes(reason)
          ? "The AI connection needs attention. Basic inspection is still available."
          : request.signal.aborted
            ? "AI review was cancelled."
            : "AI review could not finish. The page has not been verified. Retry or use basic inspection.";
    return Response.json(
      { error },
      {
        status:
          reason === "provider_quota"
            ? 429
            : request.signal.aborted
              ? 499
              : 502,
        headers,
      },
    );
  } finally {
    active--;
  }
}
