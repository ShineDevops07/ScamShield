import { analyzeRisk, type Assessment } from "./analysis";

export const MAX_AUDIO_BYTES = 20 * 1024 * 1024;
export const MAX_TRANSCRIPT_CHARACTERS = 50_000;
export const MAX_CHECK_CHARACTERS = 10_000;
export const AUDIO_ACCEPT =
  ".mp3,.wav,audio/mpeg,audio/mp3,audio/wav,audio/x-wav";

function mp3Frame(bytes: Uint8Array, at: number) {
  return (
    at + 4 <= bytes.length &&
    bytes[at] === 0xff &&
    (bytes[at + 1] & 0xe0) === 0xe0 &&
    ((bytes[at + 1] >> 3) & 3) !== 1 &&
    ((bytes[at + 1] >> 1) & 3) === 1 &&
    bytes[at + 2] >> 4 > 0 &&
    bytes[at + 2] >> 4 < 15 &&
    ((bytes[at + 2] >> 2) & 3) !== 3
  );
}

export function audioMime(
  size: number,
  bytes: Uint8Array,
): "audio/mpeg" | "audio/wav" {
  if (!size) throw Error("This audio file is empty.");
  if (size > MAX_AUDIO_BYTES)
    throw Error(
      "Choose an audio file up to 20 MB. Trim a longer recording first.",
    );
  const ascii = (from: number, to: number) =>
    String.fromCharCode(...bytes.slice(from, to));
  if (bytes.length >= 44 && ascii(0, 4) === "RIFF" && ascii(8, 12) === "WAVE")
    return "audio/wav";
  let start = 0;
  if (bytes.length >= 10 && ascii(0, 3) === "ID3") {
    if (
      bytes[3] < 2 ||
      bytes[3] > 4 ||
      bytes.slice(6, 10).some((value) => value > 127)
    )
      throw Error(
        "This MP3 header could not be read. Try exporting the recording again.",
      );
    const tagSize = bytes
      .slice(6, 10)
      .reduce((total, value) => total * 128 + value, 0);
    start = 10 + tagSize + (bytes[3] === 4 && bytes[5] & 0x10 ? 10 : 0);
  }
  for (let at = start; at < Math.min(bytes.length - 3, start + 4096); at++) {
    if (mp3Frame(bytes, at)) return "audio/mpeg";
  }
  throw Error(
    "Choose a valid MP3 or WAV recording. Renaming another file does not convert it to audio.",
  );
}

export function transcriptCoverageLimited(
  text: string,
  languages: string[] = [],
) {
  if (languages.some((code) => !/^(?:en|eng)(?:-|$)/i.test(code))) return true;
  const letters = [...text.matchAll(/\p{L}/gu)].map((match) => match[0]);
  const nonLatin = letters.filter(
    (letter) => !/\p{Script=Latin}/u.test(letter),
  ).length;
  return nonLatin >= 3 && nonLatin / Math.max(1, letters.length) > 0.05;
}

export function assessCallTranscript(
  text: string,
  languages: string[] = [],
): {
  assessment: Assessment | null;
  coverageLimited: boolean;
} {
  const coverageLimited = transcriptCoverageLimited(text, languages);
  const assessment = analyzeRisk(text, "call");
  // Finding no English patterns in another language must not imply safety.
  return {
    coverageLimited,
    assessment:
      coverageLimited && (assessment.score === null || assessment.score < 25)
        ? null
        : assessment,
  };
}
