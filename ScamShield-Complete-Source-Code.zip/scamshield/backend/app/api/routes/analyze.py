from typing import Any, Dict, Optional, Union
from fastapi import APIRouter, Body, HTTPException, status

from app.core.logging import logger
from app.schemas.requests import AnalyzeRequest, ContentTypeEnum, FrontendAnalyzeRequest
from app.schemas.responses import AnalyzeResponse
from app.services.analysis_pipeline import run_analysis_pipeline

router = APIRouter(tags=["Message Analysis"])


@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze_message_v1(request: AnalyzeRequest):
    """
    Primary ScamShield digital communication analysis endpoint.
    Evaluates SMS, emails, chat transcripts, and suspicious messages for fraud markers,
    urgency tactics, credential demands, and impersonation.
    """
    try:
        return await run_analysis_pipeline(request)
    except Exception as e:
        logger.error(f"Analysis error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while evaluating the submitted content.",
        )


@router.post("/compat/analyze", response_model=AnalyzeResponse)
async def analyze_frontend_compat(payload: Dict[str, Any] = Body(...)):
    """
    Direct compatibility bridge endpoint accepting either the standard AnalyzeRequest
    or the legacy frontend payload shape { type, text, sender, subject }.
    """
    # Extract text from either 'text' or 'message'
    text = payload.get("text") or payload.get("message")
    if not text or not str(text).strip():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Missing required field: 'text' or 'message' cannot be empty.",
        )

    content_type_str = payload.get("type", "message").lower()
    content_type = ContentTypeEnum.MESSAGE
    if content_type_str in ("email", "chat", "call"):
        content_type = ContentTypeEnum(content_type_str)

    req = AnalyzeRequest(
        message=str(text).strip(),
        content_type=content_type,
        sender=payload.get("sender"),
        context=payload.get("subject"),
        url=payload.get("url"),
    )

    return await run_analysis_pipeline(req)
