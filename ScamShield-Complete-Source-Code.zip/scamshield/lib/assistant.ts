import type { SavedScan } from "./storage";
import { assessmentLabel } from "./analysis";
export interface ChatMessage {
  role: "user" | "assistant";
  text: string;
  mode?: "guided" | "ai";
  topic?: string;
}
export const starterQuestions = [
  "How do I spot a phishing message?",
  "Do I need a UPI PIN to receive money?",
  "I clicked a suspicious link. What now?",
  "Explain my latest check.",
];
const advice = {
  receipt:
    "I cannot confirm whether a payment screenshot is genuine or edited, or whether a transfer happened. A success message or transaction ID in an image is not verification. Open your own bank, wallet, or merchant payment app independently and find the actual credit. Match the amount, date, receiving account, and reference. If the credit is missing or pending, do not rely on the screenshot; use the provider's official support. Screenshot text analysis does not authenticate payments.",
  phishing:
    "Look for a mismatch between the sender’s claim and what they ask you to do: share a code, send money, install an app, or act before a deadline. Open the official service independently instead of using the message’s link. Familiar names and HTTPS alone do not prove authenticity.",
  upi: "You do not need to enter a UPI PIN to receive money. Scanning a payment QR and entering a PIN is used to authorize a payment. Read the payment screen carefully and verify the recipient independently. See NPCI’s official fraud-awareness guidance below.",
  otp: "Keep OTPs, passwords, CVVs, and PINs private. Do not read them out to an unexpected caller or send them in chat. If you already shared one, secure the affected account through the official service, contact its support, and review activity. Use the recovery planner for a checklist.",
  money:
    "Contact your bank or payment provider through its official app or known support number promptly. In India, call 1930 for financial cyber fraud and report through cybercrime.gov.in. Preserve transaction references and messages. Do not pay a “recovery agent.” Reporting does not guarantee that money can be recovered.",
  link: "Close the suspicious page and do not submit details or install files. A click alone does not prove that the device is compromised. If you entered a password, secure the affected account from a trusted device. If you installed an app, use the app/remote-access recovery checklist. The link inspector checks structure without visiting the site.",
  arrest:
    "Threats of “digital arrest,” a seized parcel, or a payment to avoid prosecution are common impersonation patterns. Stop responding under pressure and verify any claim independently through official channels. Do not send money or security codes to the caller. Preserve the communication and consider an official report.",
  remote:
    "Do not install an unknown APK or give an unexpected caller access to your screen. If access is already active, end the session and use a separate trusted device to contact affected services. Get trusted technical help to assess the device. Our recovery planner has an app/remote-access checklist.",
  investment:
    "Be cautious about guaranteed returns, unusually high daily payouts, Telegram task jobs, and deposits needed to unlock earnings. Verify the company independently. A small initial payout is not proof that a later deposit is safe. Never send more money merely to release a promised balance.",
  identity:
    "Share identity documents only through a verified, necessary process. If documents were already shared with an unverified contact, preserve evidence, review the issuing authority’s official protection options, and watch for unauthorized activity. Do not post copies here or pay someone promising to erase your records.",
  reporting:
    "For financial cyber fraud in India, contact your bank promptly, call 1930, and use cybercrime.gov.in. Keep dates, transaction references, and the original messages. For suspicious communications without a loss, use appropriate official reporting and platform channels. ScamShield does not file a report for you.",
  privacy:
    "Content checks and guided answers run in your browser. History optionally saves short redacted summaries on this device and, with sign-in and sync enabled, in your Supabase account. Redaction is imperfect, so avoid entering private information. AI chat is a separate opt-in mode: when enabled, your redacted conversation and any included check summary are sent to Gemini through this server.",
};
export function guidedAnswer(
  question: string,
  previous: ChatMessage[] = [],
  scan: SavedScan | null = null,
): { text: string; topic: string } {
  const q = question.toLowerCase().trim();
  if (
    /ignore (?:all |previous )?instructions|bypass|(?:write|create|build|make).{0,25}(?:phishing|scam|steal|malware)/i.test(
      q,
    )
  )
    return {
      text: "I can help you recognize and respond to scams, but I can’t help create deceptive messages, steal credentials, or bypass security. Try asking how to identify warning signs or secure an account.",
      topic: "scope",
    };
  if (
    /latest|my (?:check|scan|result|score)|why.{0,25}(?:score|risk)|explain.{0,20}(?:check|result)/.test(
      q,
    )
  ) {
    if (!scan)
      return {
        text: "Run a check first, then turn on “Include my latest check” here. I’ll use its redacted summary and findings. I cannot see your original message unless you choose to type it into this conversation.",
        topic: "context",
      };
    return {
      text: `Your latest ${scan.channel} check: ${scan.assessment.aiReview ? "Basic URL inspection: " : ""}${assessmentLabel(scan.assessment)}. ${scan.assessment.summary}${scan.assessment.aiReview ? ` AI page review (${scan.assessment.aiReview.verdict.replaceAll("_", " ")}): ${scan.assessment.aiReview.summary} Page content retrieved: ${scan.assessment.aiReview.pageRead ? "yes" : "no"}. AI review does not have a numeric score.` : ""}\n\n${scan.assessment.signals.length ? scan.assessment.signals.map((s) => `• ${s.title}: ${s.description}`).join("\n") : "No listed warning patterns matched the input."}\n\n${scan.assessment.score === null ? "This receipt is unverified, not confirmed genuine or fake. No fraud probability or authenticity score was calculated." : "The score is a heuristic, not a probability of fraud or verification of the sender."} Use independent contact details before acting.`,
      topic: "context",
    };
  }
  let topic: keyof typeof advice | "hello" | "scope" = "scope";
  if (
    /(?:sent|lost|paid|transferred|stolen|debited).{0,30}(?:money|payment|funds|rupee|₹)|money.{0,20}(?:lost|sent|gone)/.test(
      q,
    )
  )
    topic = "money";
  else if (/1930|report|complaint|police help/.test(q)) topic = "reporting";
  else if (/privacy|store|data|history|offline|save/.test(q)) topic = "privacy";
  else if (
    /receipt|payment screenshot|payment proof|transaction id|\butr\b/.test(q)
  )
    topic = "receipt";
  else if (/upi|qr|receive money|cashback/.test(q)) topic = "upi";
  else if (/otp|pin|password|cvv|code/.test(q)) topic = "otp";
  else if (/digital arrest|customs|parcel|police|cbi|arrest/.test(q))
    topic = "arrest";
  else if (/remote|anydesk|teamviewer|screen shar|apk|install/.test(q))
    topic = "remote";
  else if (/investment|job|telegram|task|returns|income|deposit|earn/.test(q))
    topic = "investment";
  else if (/aadhaar|aadhar|pan card|identity|documents/.test(q))
    topic = "identity";
  else if (/click|link|url|domain|website|https/.test(q)) topic = "link";
  else if (/phish|scam|suspicious|fraud|warning|spot|safe|verify/.test(q))
    topic = "phishing";
  else if (/^(hi|hello|hey|thanks|thank you)[!. ]*$/.test(q)) topic = "hello";
  else if (
    /what (?:now|next)|what should i do|tell me more|why|how/.test(q) &&
    q.length < 60
  ) {
    const last = [...previous]
      .reverse()
      .find((m) => m.role === "assistant" && m.topic && m.topic in advice);
    if (last?.topic) topic = last.topic as keyof typeof advice;
  }
  return {
    text:
      topic === "hello"
        ? "Hello. I can help with suspicious messages, UPI and OTP safety, link checks, reporting, and recovery steps. What are you unsure about?"
        : topic === "scope"
          ? "I’m focused on scam awareness and practical safety steps. Ask me about a suspicious message, OTP requests, UPI/QR tricks, risky links, or what to do after responding. For a case-specific explanation, include your latest check."
          : advice[topic],
    topic,
  };
}
