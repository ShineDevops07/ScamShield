"use client";
import AccountButton from "./account-button";
import { useCloudHistory } from "./cloud-history-provider";
export default function CloudSaveNote() {
  const { user, enabled } = useCloudHistory();
  return (
    <p className="cloud-save-note">
      {user && enabled
        ? "New saved checks also sync to your account. Cloud save status appears after checking."
        : user
          ? "Cloud sync is off. Saved checks stay on this device."
          : "Sign in and enable cloud sync to keep saved checks across devices."}{" "}
      <AccountButton>Account settings</AccountButton>
    </p>
  );
}
