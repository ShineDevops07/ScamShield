import { inspectLink } from "./url-inspector";

export type AnalysisTab = "message" | "call" | "url";

export interface SampleItem {
  label: string;
  type: AnalysisTab;
  text: string;
  callerNumber?: string;
  callerName?: string;
  duration?: string;
  callType?: string;
}

export const callSamples: SampleItem[] = [
  {
    label: "FedEx Customs Scam Call",
    type: "call",
    callerNumber: "+91 98231 09841",
    callerName: 'Customs Officer "Sharma"',
    duration: "2m 14s",
    callType: "Robocall transfer to impersonator",
    text: "This is Mumbai Customs Department. A parcel registered with your Aadhaar card contains banned substances and fake passports. Digital arrest warrant has been issued against your name. To resolve this case without police visit, transfer refundable penalty amount of ₹45,000 immediately.",
  },
  {
    label: "Bank KYC Expiry Call",
    type: "call",
    callerNumber: "+91 80102 33491",
    callerName: "SBI Verification Desk",
    duration: "1m 08s",
    callType: "Voice phishing (Vishing)",
    text: "Sir your State Bank debit card KYC expired today 12 PM. Account will be permanently deactivated. Please confirm the 6-digit verification code sent to your phone right now to continue banking services.",
  },
  {
    label: "Legitimate Bank Advisory Call",
    type: "call",
    callerNumber: "+91 22 2540 1199",
    callerName: "HDFC Official Advisory Desk",
    duration: "45s",
    callType: "Legitimate awareness",
    text: "Dear customer, this is an automated security advisory from your bank. Remember: never share your OTP, password, or UPI PIN with anyone, including bank officials. Our staff will never ask for your code.",
  },
];

export const messageSamples: SampleItem[] = [
  {
    label: "Electricity Power Cut SMS",
    type: "message",
    callerNumber: "VM-MSEBHD",
    text: "Dear consumer, your electricity connection will be disconnected tonight 9:30 PM due to unpaid bill. Immediately contact Electricity Officer on 98451-XXXXX or pay via link: http://bit.ly/mseb-quickpay",
  },
  {
    label: "Part-Time Job / Telegram Scam",
    type: "message",
    callerNumber: "WA Business",
    text: "Hi! Earn ₹3,000 to ₹8,000 daily working from home just by liking YouTube videos and Google Maps reviews. No experience needed. Daily instant payouts. Tap to join our Telegram manager now.",
  },
  {
    label: "Legitimate Security OTP SMS",
    type: "message",
    callerNumber: "AX-HDFCBK",
    text: "Your login OTP is 492019 for NetBanking session. Do not share your OTP or PIN with anyone. Bank employees will never ask for your OTP.",
  },
];

export const urlSamples: SampleItem[] = [
  {
    label: "Phishing Netbanking Portal",
    type: "url",
    text: "https://hfdcbank-kyc-update-portal-netbanking.support/login.php",
  },
  {
    label: "Legitimate Domain",
    type: "url",
    text: "https://www.onlinesbi.sbi/personal/login.html",
  },
];

export interface Signal {
  title: string;
  severity: "High" | "Medium" | "Low" | "Positive" | "Context";
  points: string;
  excerpt: string;
  description: string;
  type: "threat" | "safety" | "context";
}

export interface SavedAiLinkReview {
  verdict: "suspicious" | "no_clear_red_flags" | "inconclusive";
  summary: string;
  findings: string[];
  pageRead: boolean;
  checkedAt: string;
}
export interface Assessment {
  aiReview?: SavedAiLinkReview;
  score: number | null;
  kind?: "payment_receipt";
  signals: Signal[];
  risk: string;
  tone: "neutral" | "danger" | "warning" | "safe";
  summary: string;
}
export function assessmentLabel(assessment: Assessment) {
  return assessment.score === null
    ? `${assessment.risk} · Not scored`
    : `${assessment.risk} · ${assessment.score}/100`;
}

export function looksLikePaymentReceipt(content: string) {
  const text = content.replace(/\s+/g, " ");
  const explicitPaymentStatus =
    /\b(?:payment|transaction|transfer)\s+(?:successful|success|completed|received|pending|processing|failed|declined)\b/i.test(
      text,
    );
  const status =
    /\b(?:sent\s+successfully|payment\s+(?:successful|success|completed|received)|transaction\s+(?:successful|completed)|paid\s+(?:(?:₹|rs\.?|inr)?\s*[\d,.]+\s+)?to|received\s+from|money\s+(?:sent|received)|transfer\s+(?:successful|completed))\b/i.test(
      text,
    );
  const reference =
    /\b(?:utr|rrn|(?:upi\s+|wallet\s+)?(?:txn|transaction|ref(?:erence)?)\s*(?:id|number|no\.?|:|#))\b/i.test(
      text,
    );
  const receiptUI =
    /\b(?:wallet\s+balance|view\s+passbook|add\s+money\s+to\s+wallet|paid\s+(?:by|from)|bank\s+account|upi\s+(?:id|ref))\b/i.test(
      text,
    );
  return explicitPaymentStatus || (status && (reference || receiptUI));
}

export function analyzeRisk(
  content: string,
  type: AnalysisTab,
  options: { paymentReceipt?: boolean } = {},
): Assessment {
  const text = content.trim();
  if (!text)
    return {
      score: 0,
      signals: [],
      risk: "Awaiting content",
      tone: "neutral",
      summary: "Add content to start a check.",
    };
  const signals: Signal[] = [];
  let score = 5;
  function add(
    title: string,
    severity: Signal["severity"],
    points: number,
    excerpt: string,
    description: string,
    safety = false,
  ) {
    signals.push({
      title,
      severity,
      points: points ? `+${points}` : "Context",
      excerpt,
      description,
      type: safety ? "safety" : "threat",
    });
    score += points;
  }
  const activeMatch = (pattern: RegExp) => {
    const regex = new RegExp(pattern.source, "gi");
    for (const m of text.matchAll(regex)) {
      const before = text
        .slice(Math.max(0, (m.index || 0) - 45), m.index)
        .toLowerCase();
      if (
        !/(?:never|do not|don't|dont|should not|shouldn't|not to|avoid)\s+(?:ever\s+)?$/.test(
          before,
        )
      )
        return m[0];
    }
    return "";
  };
  if (type === "url") {
    const link = inspectLink(text);
    if (!link.valid)
      return {
        score: 0,
        signals: link.flags.map((f) => ({
          title: f.title,
          severity: "Medium",
          points: "Not scored",
          excerpt: text.slice(0, 120),
          description: f.detail,
          type: "threat",
        })),
        risk: "Invalid link",
        tone: "neutral",
        summary:
          "This input could not be checked as a website link. Correct the format and try again.",
      };
    for (const f of link.flags)
      add(
        f.title,
        f.weight >= 30 ? "High" : "Medium",
        f.weight,
        link.hostname,
        f.detail,
      );
    score = link.score;
  } else {
    const protective = text.match(
      /(?:never|do not|don't|will never)\s+(?:share|send|give|disclose|ask for)\s+(?:your\s+)?(?:otp|pin|password|verification code|credentials)/i,
    );
    if (protective)
      add(
        "Protective security advice",
        "Positive",
        0,
        protective[0],
        "This clause warns against sharing private information. It does not cancel other suspicious requests in the message.",
        true,
      );
    const credentials = activeMatch(
      /(?:share|send|provide|give|reply with|confirm|enter|tell|read out|forward)\s+(?:me\s+)?(?:your\s+|the\s+|this\s+)?(?:6-digit\s+|4-digit\s+)?(?:otp|pin|password|verification code|cvv|secret code)/i,
    );
    if (credentials)
      add(
        "Request for private credentials",
        "High",
        60,
        credentials,
        "The text asks for a security code or password. Treat requests from unexpected callers or messages as high risk.",
      );
    const documents = activeMatch(
      /(?:share|send|provide|upload|submit|forward)\s+(?:a copy of\s+)?(?:your\s+|the\s+)?(?:pan card|pan number|aadhaar(?: card)?|aadhar(?: card)?|identity proof)/i,
    );
    if (documents)
      add(
        "Request for identity documents",
        "High",
        35,
        documents,
        "An informal request for identity documents needs independent verification before you share anything.",
      );
    const arrest = activeMatch(
      /(?:digital arrest|arrest warrant|banned substances|fake passports|illegal parcel)/i,
    );
    if (arrest)
      add(
        "Threat of arrest or prosecution",
        "High",
        55,
        arrest,
        "Threats involving arrest or seized parcels are common impersonation tactics. Verify claims independently.",
      );
    const remote = activeMatch(
      /(?:install|download|open|enable|grant|allow)\s+(?:the\s+|this\s+|our\s+)?(?:anydesk|teamviewer|rustdesk|remote access|screen shar(?:ing|e)|[^.!?\n]{0,40}\.apk\b)/i,
    );
    if (remote)
      add(
        "Remote access or app installation",
        "High",
        60,
        remote,
        "Remote-control apps or unknown APK files can expose a device. Do not grant access at an unexpected caller’s request.",
      );
    const urgency = activeMatch(
      /(?:immediately|right now|tonight|in \d+ (?:minutes|hours)|permanently deactivated|account will be (?:blocked|suspended)|connection will be disconnected)/i,
    );
    const payment = activeMatch(
      /\b(?:transfer|pay|deposit)\b[^.!?\n]{0,60}(?:₹|\brs\b|\binr\b|\bamount\b|\bfee\b|\bpenalty\b|\bmoney\b)|\b(?:refundable penalty|security deposit|release fee|registration fee)\b/i,
    );
    if (payment)
      add(
        "Request for payment",
        "Medium",
        urgency || arrest ? 30 : 15,
        payment,
        "Verify unexpected payment requests through a trusted channel. A payment request alone does not prove fraud.",
      );
    if (urgency)
      add(
        "Pressure to act quickly",
        "Medium",
        20,
        urgency,
        "A short deadline or threat can discourage independent checks. Slow down and verify the request.",
      );
    const task = activeMatch(
      /(?:telegram manager|earn ₹|guaranteed returns|double your money|daily instant payouts|liking youtube|pay[^.!?\n]{0,40}(?:unlock|withdraw|job))/i,
    );
    if (task)
      add(
        "Unusual income or investment promise",
        "High",
        40,
        task,
        "Easy-income promises, guaranteed returns, or deposits to unlock work or withdrawals are common scam patterns.",
      );
    const qr = activeMatch(
      /(?:scan[^.!?\n]{0,50}qr[^.!?\n]{0,50}(?:receive|refund|cashback)|(?:enter|type)[^.!?\n]{0,25}upi pin[^.!?\n]{0,45}(?:receive|refund))/i,
    );
    if (qr)
      add(
        "Payment disguised as receiving money",
        "High",
        60,
        qr,
        "Scanning a payment QR and entering a UPI PIN authorizes a payment. Receiving money does not require your PIN.",
      );
    const links = text.match(/https?:\/\/[^\s<>"']+/gi) || [];
    for (const raw of links.slice(0, 3)) {
      const link = inspectLink(raw.replace(/[.,!;)]+$/, ""));
      if (link.valid && link.score >= 20)
        add(
          "Link needs a closer look",
          link.score >= 60 ? "High" : "Medium",
          Math.min(35, Math.round(link.score / 2)),
          link.hostname,
          link.flags.map((f) => f.title).join("; ") +
            ". No website visit or reputation lookup was performed.",
        );
    }
  }
  const receipt =
    type !== "url" && (options.paymentReceipt || looksLikePaymentReceipt(text));
  if (receipt) {
    signals.push(
      {
        title: "Payment authenticity is unverified",
        severity: "Context",
        points: "Not scored",
        excerpt: "",
        description:
          "A screenshot, success message, or transaction ID does not prove that money reached the receiving account. ScamShield has no access to bank records and does not detect image edits.",
        type: "context",
      },
      {
        title: "Verify the credit in your own account",
        severity: "Context",
        points: "Next step",
        excerpt: "",
        description:
          "Open your own bank, wallet, or merchant payment app independently. Find the actual credited transaction and match the amount, date, receiving account, and reference. If it is missing or pending, do not treat the screenshot as confirmation; contact official support.",
        type: "context",
      },
    );
    if (score < 25)
      return {
        kind: "payment_receipt",
        score: null,
        signals,
        risk: "Payment not verified",
        tone: "neutral",
        summary:
          "This looks like a payment receipt. The text cannot establish whether the transfer happened or the image was edited. No authenticity score is available; this is not a low-risk verdict.",
      };
  }
  score = Math.min(98, score);
  return {
    score,
    ...(receipt ? { kind: "payment_receipt" as const } : {}),
    signals,
    risk: score >= 60 ? "High risk" : score >= 25 ? "Use caution" : "Low risk",
    tone: score >= 60 ? "danger" : score >= 25 ? "warning" : "safe",
    summary:
      score >= 60
        ? "Several warning signs suggest this may be a scam. Pause before responding."
        : score >= 25
          ? "Some warning signs need a closer look. Verify the request independently."
          : "No strong warning signs were found. This does not verify the sender or guarantee safety.",
  };
}
