"""Fraud patterns and contextual rules."""
