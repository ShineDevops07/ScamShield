from typing import Any, Dict, List, Optional
from app.schemas.responses import EvidenceItem, EvidenceTypeEnum, SeverityEnum


def build_evidence_dossier(
    context_signals: List[Dict[str, Any]],
    url_findings: Optional[List[Dict[str, Any]]] = None,
    sender_info: Optional[str] = None,
    ai_inferred_signals: Optional[List[Dict[str, Any]]] = None,
) -> List[EvidenceItem]:
    """
    Constructs a strictly categorized evidence dossier:
    1. Observed evidence (directly present in message/URL text)
    2. Inferred evidence (semantic intent, coercion, impersonation hypotheses)
    3. Independently verified evidence (domain registry/threat intel if confirmed)
    """
    evidence: List[EvidenceItem] = []

    # 1. Process observed context signals from message text
    for sig in context_signals:
        ev_type_str = sig.get("evidence_type", "observed")
        ev_type = (
            EvidenceTypeEnum.OBSERVED
            if ev_type_str == "observed"
            else EvidenceTypeEnum.INFERRED
        )

        severity_str = sig.get("severity", "Medium")
        try:
            severity = SeverityEnum(severity_str)
        except ValueError:
            severity = SeverityEnum.MEDIUM

        evidence.append(
            EvidenceItem(
                description=sig.get("title", "Signal Detected"),
                evidence_source=sig.get("source", "message_text"),
                severity=severity,
                points=sig.get("points"),
                excerpt=sig.get("excerpt"),
                explanation=sig.get("description", ""),
                evidence_type=ev_type,
            )
        )

    # 2. Process URL findings
    if url_findings:
        for uf in url_findings:
            evidence.append(
                EvidenceItem(
                    description=uf.get("title", "URL Indicator"),
                    evidence_source="url_analysis",
                    severity=uf.get("severity", SeverityEnum.HIGH),
                    points=uf.get("points"),
                    excerpt=uf.get("excerpt"),
                    explanation=uf.get("explanation", ""),
                    evidence_type=uf.get("evidence_type", EvidenceTypeEnum.OBSERVED),
                )
            )

    # 3. Process Sender Info (Observed)
    if sender_info:
        evidence.append(
            EvidenceItem(
                description="Sender Identity Header",
                evidence_source="sender_metadata",
                severity=SeverityEnum.MEDIUM,
                points=None,
                excerpt=sender_info,
                explanation=f"Sender claimed as '{sender_info}'. Note that SMS headers and caller IDs can be easily spoofed using VoIP gateways.",
                evidence_type=EvidenceTypeEnum.OBSERVED,
            )
        )

    # 4. Process AI Inferred Signals (Inferred only)
    if ai_inferred_signals:
        for ai_sig in ai_inferred_signals:
            evidence.append(
                EvidenceItem(
                    description=ai_sig.get("title", "AI Evaluated Risk Cue"),
                    evidence_source="ai_heuristic_reasoning",
                    severity=ai_sig.get("severity", SeverityEnum.MEDIUM),
                    points=None,
                    excerpt=ai_sig.get("excerpt"),
                    explanation=ai_sig.get("explanation", ""),
                    evidence_type=EvidenceTypeEnum.INFERRED,
                )
            )

    return evidence
