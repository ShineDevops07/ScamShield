import logging
import re
import sys
from typing import Any

# Sensitive pattern regexes for automated redaction
# Long multi-group patterns (Credit Card, Aadhaar) are matched FIRST to prevent partial interception
SENSITIVE_PATTERNS = [
    # Credit/Debit Card Numbers (13-19 digits, spaced or hyphenated)
    (re.compile(r'\b(?:\d{4}[ -]?){3}\d{1,4}\b'), '[REDACTED_CARD]'),
    # Aadhaar Number (12 digits, spaced or unspaced, with negative lookahead for 16-digit cards)
    (re.compile(r'\b\d{4}\s?\d{4}\s?\d{4}(?!\s?\d{4})\b'), '[REDACTED_AADHAAR]'),
    # Indian PAN Card (5 uppercase letters, 4 digits, 1 letter)
    (re.compile(r'\b[A-Z]{5}[0-9]{4}[A-Z]{1}\b', re.IGNORECASE), '[REDACTED_PAN]'),
    # Bearer / Auth tokens
    (re.compile(r'(bearer\s+)[A-Za-z0-9\-._~+/]+=*', re.IGNORECASE), r'\1[REDACTED_TOKEN]'),
    # Passwords in URLs or JSON
    (re.compile(r'("password"|"secret"|"api_key"|"key")\s*:\s*"[^"]+"', re.IGNORECASE), r'\1: "[REDACTED]"'),
    # 4-8 digit explicit OTPs / PINs
    (re.compile(r'\b(otp|pin|cvv|code|passcode)\s*[:=]?\s*([0-9]{4,8})\b', re.IGNORECASE), r'\1: [REDACTED_CODE]'),
    # Standalone 4-8 digit OTP codes after phrases like 'is 492019'
    (re.compile(r'\b(is\s+)([0-9]{4,8})(?!\s+\d{4})\b', re.IGNORECASE), r'\1[REDACTED_OTP]'),
]


def redact_sensitive_data(text: str) -> str:
    """Redacts PII, credentials, OTPs, Aadhaar, PAN, and card numbers from strings."""
    if not isinstance(text, str):
        return text
    redacted = text
    for pattern, replacement in SENSITIVE_PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


class RedactingFormatter(logging.Formatter):
    """Custom formatter that automatically redacts sensitive data from log records."""

    def format(self, record: logging.LogRecord) -> str:
        orig = super().format(record)
        return redact_sensitive_data(orig)


def setup_logger(name: str = "scamshield") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler(sys.stdout)
        formatter = RedactingFormatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False
    return logger


logger = setup_logger()
