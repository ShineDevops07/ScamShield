import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Plans & pricing | ScamShield",
  description:
    "Explore free scam-safety tools, upcoming family plans from ₹99/month, and four-week organization pilots from ₹5,000.",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
