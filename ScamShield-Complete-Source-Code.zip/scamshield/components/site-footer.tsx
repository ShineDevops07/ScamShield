import { ShieldCheck } from "lucide-react";
import Link from "next/link";
import AccountButton from "./account-button";
export default function SiteFooter() {
  return (
    <footer className="site-footer">
      <div>
        <Link href="/" className="footer-brand">
          <ShieldCheck size={17} />
          ScamShield
        </Link>
        <span>Understand the signs. Choose your next step.</span>
      </div>
      <nav aria-label="Footer navigation">
        <AccountButton>Account & cloud history</AccountButton>
        <Link href="/pricing">Plans & pricing</Link>
        <Link href="/recover">Recovery & reporting</Link>
      </nav>
    </footer>
  );
}
