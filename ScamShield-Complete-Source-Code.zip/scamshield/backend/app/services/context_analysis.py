import re
from typing import Any, Dict, List, Optional, Tuple

from app.rules.fraud_patterns import FRAUD_PATTERNS, FraudPattern
from app.rules.contextual_rules import (
    check_security_advisory,
    check_quoted_or_reporting,
    check_pure_otp_notification,
    check_benign_commerce,
)


URL_REGEX = re.compile(
    r'(https?://[^\s<>"\',]+|(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:/[^\s<>"\',]*)?)',
    re.IGNORECASE,
)


class ContextAnalysisResult:
    def __init__(
        self,
        is_security_advisory: bool,
        is_quoted_or_reporting: bool,
        is_pure_otp: bool,
        is_benign_commerce: bool,
        advisory_excerpt: Optional[str],
        matched_fraud_patterns: List[Tuple[FraudPattern, str]],
        extracted_urls: List[str],
        detected_categories: List[str],
        base_risk_score: int,
        primary_signals: List[Dict[str, Any]],
        reassuring_signals: List[str],
        red_flags: List[str],
    ):
        self.is_security_advisory = is_security_advisory
        self.is_quoted_or_reporting = is_quoted_or_reporting
        self.is_pure_otp = is_pure_otp
        self.is_benign_commerce = is_benign_commerce
        self.advisory_excerpt = advisory_excerpt
        self.matched_fraud_patterns = matched_fraud_patterns
        self.extracted_urls = extracted_urls
        self.detected_categories = detected_categories
        self.base_risk_score = base_risk_score
        self.primary_signals = primary_signals
        self.reassuring_signals = reassuring_signals
        self.red_flags = red_flags


def analyze_message_context(text: str, explicit_url: Optional[str] = None) -> ContextAnalysisResult:
    """
    Performs deterministic contextual analysis of the message.
    Distinguishes malicious attacks from security advisories, benign notifications, and quoted reports.
    """
    clean_text = text.strip()
    lower_text = clean_text.lower()

    # 1. Contextual Negation & Protective Advisory Check
    is_advisory, advisory_excerpt = check_security_advisory(clean_text)

    # 2. Quoted Scam & Reporting Check
    is_quoted, quoted_excerpt = check_quoted_or_reporting(clean_text)

    # 3. Pure OTP Delivery Notification Check
    is_pure_otp, otp_excerpt = check_pure_otp_notification(clean_text)

    # 4. Benign Commerce / Delivery Fee Check
    is_benign_fee, fee_excerpt = check_benign_commerce(clean_text)

    # 5. Extract URLs
    found_urls = URL_REGEX.findall(clean_text)
    extracted_urls = [u for u in found_urls if "." in u and not u.endswith((".py", ".ts", ".js"))]
    if explicit_url and explicit_url not in extracted_urls:
        extracted_urls.append(explicit_url)

    matched_fraud_patterns: List[Tuple[FraudPattern, str]] = []
    detected_categories: List[str] = []
    primary_signals: List[Dict[str, Any]] = []
    red_flags: List[str] = []
    reassuring_signals: List[str] = []

    base_score = 5

    # If it is a confirmed security advisory
    if is_advisory:
        detected_categories.append("Legitimate Security / Anti-Phishing Advisory")
        reassuring_signals.append(
            f"Explicit protective negation detected ('{advisory_excerpt}'). Instructs user NOT to share sensitive credentials."
        )
        base_score = 5
        primary_signals.append({
            "title": "Protective Security Advisory",
            "severity": "Positive",
            "points": "-20",
            "excerpt": advisory_excerpt,
            "description": "Full sentence analysis confirms this communication warns against sharing OTP, PIN, or passwords.",
            "source": "message_text",
            "evidence_type": "observed",
        })

    # If it is a quoted / reporting message
    elif is_quoted:
        detected_categories.append("Scam Reporting / Educational Inquiry")
        reassuring_signals.append(
            "User is quoting, discussing, or debunking a scam rather than an attacker executing an active threat."
        )
        base_score = 10
        primary_signals.append({
            "title": "Quoted Scam Reporting / Analysis Context",
            "severity": "Low",
            "points": "0",
            "excerpt": quoted_excerpt,
            "description": "The submitted text inquires about or reports a known scam scenario.",
            "source": "message_text",
            "evidence_type": "inferred",
        })

    # If it is a benign cash-on-delivery or delivery fee message
    elif is_benign_fee:
        detected_categories.append("Standard E-Commerce / Delivery Notification")
        reassuring_signals.append(
            "Standard delivery fee notice specifying payment upon parcel arrival without extortion threats."
        )
        base_score = 10
        primary_signals.append({
            "title": "Legitimate Delivery Fee Notice",
            "severity": "Positive",
            "points": "0",
            "excerpt": fee_excerpt,
            "description": "Notice refers to ordinary delivery fee or cash-on-delivery without demanding advance gift cards or wire transfers.",
            "source": "message_text",
            "evidence_type": "observed",
        })

    # If it is a pure OTP notification (e.g., 'Your OTP is 482193')
    elif is_pure_otp:
        detected_categories.append("Transactional OTP Notification")
        reassuring_signals.append(
            "Standard incoming one-time password notification. Does not demand you reply or disclose it."
        )
        base_score = 15
        primary_signals.append({
            "title": "Transactional Security Code Notification",
            "severity": "Low",
            "points": "+5",
            "excerpt": otp_excerpt,
            "description": "This is an incoming verification code. The code itself is sensitive, but the message does not solicit disclosure.",
            "source": "message_text",
            "evidence_type": "observed",
        })

    else:
        # Evaluate active fraud patterns
        for fp in FRAUD_PATTERNS:
            match = fp.pattern.search(clean_text)
            if match:
                matched_text = match.group(0)
                matched_fraud_patterns.append((fp, matched_text))
                if fp.category not in detected_categories:
                    detected_categories.append(fp.category)
                red_flags.append(f"{fp.title}: '{matched_text}' ({fp.description})")

                # Accumulate score with diminishing returns for redundant signals
                points_to_add = fp.base_points
                if base_score > 60:
                    points_to_add = int(points_to_add * 0.4)
                elif base_score > 40:
                    points_to_add = int(points_to_add * 0.6)

                base_score += points_to_add

                primary_signals.append({
                    "title": fp.title,
                    "severity": fp.severity,
                    "points": f"+{points_to_add}",
                    "excerpt": matched_text,
                    "description": fp.description,
                    "source": "message_text",
                    "evidence_type": "observed",
                })

    # Extra penalty for embedded suspicious URLs
    if extracted_urls and not is_advisory and not is_benign_fee:
        for u in extracted_urls:
            red_flags.append(f"Contains actionable link: {u}")
            base_score += 15

    base_risk_score = max(5, min(98, base_score))

    return ContextAnalysisResult(
        is_security_advisory=is_advisory,
        is_quoted_or_reporting=is_quoted,
        is_pure_otp=is_pure_otp,
        is_benign_commerce=is_benign_fee,
        advisory_excerpt=advisory_excerpt,
        matched_fraud_patterns=matched_fraud_patterns,
        extracted_urls=extracted_urls,
        detected_categories=detected_categories,
        base_risk_score=base_risk_score,
        primary_signals=primary_signals,
        reassuring_signals=reassuring_signals,
        red_flags=red_flags,
    )
