export type LinkFlag = { title: string; detail: string; weight: number };
export type LinkInspection = {
  valid: boolean;
  hostname: string;
  protocol: string;
  normalized: string;
  flags: LinkFlag[];
  score: number;
  path: string;
  shortener: boolean;
};
const shorteners = [
  "bit.ly",
  "tinyurl.com",
  "t.co",
  "cutt.ly",
  "rb.gy",
  "is.gd",
  "goo.gl",
];
const brands = [
  {
    name: "HDFC",
    tokens: /hdfc|hfdc/i,
    hosts: ["hdfcbank.com", "hdfc.bank.in"],
  },
  {
    name: "SBI",
    tokens: /sbi|statebank/i,
    hosts: ["onlinesbi.sbi", "sbi.co.in", "sbi.bank.in"],
  },
  {
    name: "ICICI",
    tokens: /icici/i,
    hosts: ["icicibank.com", "icici.bank.in"],
  },
  {
    name: "Google",
    tokens: /google|googel|g00gle/i,
    hosts: ["google.com", "google.co.in"],
  },
  {
    name: "Amazon",
    tokens: /amazon|amaz0n/i,
    hosts: ["amazon.in", "amazon.com"],
  },
];
export function inspectLink(input: string): LinkInspection {
  const raw = input.trim();
  const base = {
    valid: false,
    hostname: "",
    protocol: "",
    normalized: "",
    flags: [] as LinkFlag[],
    score: 0,
    path: "",
    shortener: false,
  };
  if (!raw || raw.length > 2048 || /\s/.test(raw))
    return {
      ...base,
      flags: [
        {
          title: "Invalid link",
          detail:
            "Enter one complete website link without spaces, up to 2,048 characters.",
          weight: 0,
        },
      ],
    };
  try {
    if (
      /^[a-z][a-z\d+.-]*:/i.test(raw) &&
      !/^[^/:?#]+:\d+(?:\/|$)/.test(raw) &&
      !/^https?:\/\//i.test(raw)
    )
      throw Error("scheme");
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (
      !["https:", "http:"].includes(url.protocol) ||
      (!url.hostname.includes(".") &&
        url.hostname !== "localhost" &&
        !url.hostname.includes(":"))
    )
      throw Error("host");
    const flags: LinkFlag[] = [];
    const host = url.hostname.toLowerCase();
    if (url.protocol === "http:")
      flags.push({
        title: "Unencrypted connection",
        detail:
          "HTTP does not encrypt traffic. It does not establish whether the site is fraudulent.",
        weight: 15,
      });
    if (url.username || url.password)
      flags.push({
        title: "Hidden destination trick",
        detail: `Text before @ is not the destination. The actual host is ${host}.`,
        weight: 45,
      });
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":"))
      flags.push({
        title: "IP address instead of a domain",
        detail:
          "An IP address makes the organization behind a link harder to recognize.",
        weight: 30,
      });
    if (
      host === "localhost" ||
      /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(
        host,
      ) ||
      host === "[::1]"
    )
      flags.push({
        title: "Local or private destination",
        detail:
          "This points to a local/private address. ScamShield will not connect to it.",
        weight: 30,
      });
    if (host.includes("xn--"))
      flags.push({
        title: "Internationalized domain",
        detail:
          "Punycode can represent legitimate non-English domains, but can also hide lookalike characters.",
        weight: 20,
      });
    const shortener = shorteners.includes(host);
    if (shortener)
      flags.push({
        title: "Shortened destination",
        detail:
          "The final website is hidden. Basic inspection does not expand shortened links or follow redirects.",
        weight: 30,
      });
    if (host.split(".").length > 4)
      flags.push({
        title: "Many subdomains",
        detail:
          "Read the complete host carefully; a familiar name near the beginning can be misleading.",
        weight: 15,
      });
    if (/\.(support|xyz|top|click|loan|tk|icu)$/.test(host))
      flags.push({
        title: "Domain suffix worth checking",
        detail:
          "This suffix is a weak caution signal, not evidence of fraud by itself.",
        weight: 15,
      });
    for (const brand of brands)
      if (
        brand.tokens.test(host) &&
        !brand.hosts.some((h) => host === h || host.endsWith(`.${h}`))
      )
        flags.push({
          title: `Possible ${brand.name} lookalike`,
          detail: `The hostname contains a ${brand.name}-like name but does not match our limited list of expected host spellings. Verify independently.`,
          weight: 40,
        });
    if (url.port && !["80", "443"].includes(url.port))
      flags.push({
        title: "Unusual port",
        detail: `The link uses port ${url.port}. This may be legitimate but deserves a closer look.`,
        weight: 10,
      });
    if (/\.(apk|exe|scr|msi)(?:$|[?#])/i.test(url.pathname))
      flags.push({
        title: "Executable download",
        detail:
          "The path appears to point to an app or executable. Do not install files sent by an unverified contact.",
        weight: 45,
      });
    return {
      valid: true,
      hostname: host,
      protocol: url.protocol.replace(":", ""),
      normalized: `${url.protocol}//${host}${url.port ? ":" + url.port : ""}${url.pathname}`,
      flags,
      score: Math.min(98, 5 + flags.reduce((a, f) => a + f.weight, 0)),
      path: url.pathname,
      shortener,
    };
  } catch {
    return {
      ...base,
      flags: [
        {
          title: "Unsupported or malformed link",
          detail:
            "Use a standard http:// or https:// website link. Script, data, and file links are not supported.",
          weight: 0,
        },
      ],
    };
  }
}
