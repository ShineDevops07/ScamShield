"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import CloudSaveNote from "@/components/cloud-save-note";
import {
  ArrowRight,
  AudioLines,
  Check,
  Download,
  FileAudio,
  Info,
  LoaderCircle,
  LockKeyhole,
  MessageCircle,
  RotateCcw,
  Upload,
  X,
} from "lucide-react";
import { assessmentLabel, type Assessment } from "@/lib/analysis";
import {
  AUDIO_ACCEPT,
  MAX_AUDIO_BYTES,
  MAX_CHECK_CHARACTERS,
  MAX_TRANSCRIPT_CHARACTERS,
  assessCallTranscript,
  audioMime,
} from "@/lib/audio";
import {
  downloadText,
  redactSensitive,
  remember,
  safeScan,
  SAVE_KEY,
} from "@/lib/storage";

type SelectedAudio = { file: File; url: string };
type AudioReport = {
  text: string;
  assessment: Assessment | null;
  coverageLimited: boolean;
};
type Availability = "loading" | "ready" | "missing" | "error";

function languageName(code: string) {
  try {
    return new Intl.DisplayNames(["en"], { type: "language" }).of(code) || code;
  } catch {
    return code;
  }
}

export default function AudioScanner() {
  const [audio, setAudio] = useState<SelectedAudio | null>(null);
  const [text, setText] = useState("");
  const [languages, setLanguages] = useState<string[]>([]);
  const [report, setReport] = useState<AudioReport | null>(null);
  const [availability, setAvailability] = useState<Availability>("loading");
  const [consent, setConsent] = useState(false);
  const [save, setSave] = useState(false);
  const [busy, setBusy] = useState(false);
  const [choosing, setChoosing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  const player = useRef<HTMLAudioElement>(null);
  const review = useRef<HTMLTextAreaElement>(null);
  const currentURL = useRef("");
  const job = useRef(0);
  const controller = useRef<AbortController | null>(null);
  const statusController = useRef<AbortController | null>(null);
  const mounted = useRef(true);

  async function checkAvailability() {
    statusController.current?.abort();
    const pending = new AbortController();
    statusController.current = pending;
    setAvailability("loading");
    try {
      const response = await fetch("/api/transcribe", {
        cache: "no-store",
        signal: AbortSignal.any([pending.signal, AbortSignal.timeout(10_000)]),
      });
      const data = await response.json();
      if (!response.ok || typeof data.available !== "boolean") throw Error();
      if (mounted.current && !pending.signal.aborted)
        setAvailability(data.available ? "ready" : "missing");
    } catch {
      if (mounted.current && !pending.signal.aborted) setAvailability("error");
    }
  }

  useEffect(() => {
    mounted.current = true;
    try {
      setSave(localStorage.getItem(SAVE_KEY) === "true");
    } catch {}
    void checkAvailability();
    return () => {
      mounted.current = false;
      job.current++;
      controller.current?.abort();
      statusController.current?.abort();
      if (currentURL.current) URL.revokeObjectURL(currentURL.current);
    };
  }, []);

  useEffect(() => {
    const element = player.current;
    return () => element?.pause();
  }, [audio]);

  function cancel() {
    job.current++;
    controller.current?.abort();
    controller.current = null;
    setBusy(false);
  }

  function reset() {
    cancel();
    if (currentURL.current) URL.revokeObjectURL(currentURL.current);
    currentURL.current = "";
    setAudio(null);
    setText("");
    setLanguages([]);
    setReport(null);
    setConsent(false);
    setError("");
    setNotice("");
    setChoosing(false);
    if (fileInput.current) fileInput.current.value = "";
  }

  async function choose(file: File) {
    reset();
    const id = job.current;
    setChoosing(true);
    try {
      if (file.size > MAX_AUDIO_BYTES)
        throw Error(
          "Choose a file up to 20 MB. Trim a longer recording first.",
        );
      const mime = audioMime(
        file.size,
        new Uint8Array(await file.arrayBuffer()),
      );
      if (!mounted.current || id !== job.current) return;
      const normalized = new File([file], file.name, { type: mime });
      const url = URL.createObjectURL(normalized);
      currentURL.current = url;
      setAudio({ file: normalized, url });
    } catch (reason) {
      if (mounted.current && id === job.current)
        setError(
          reason instanceof Error
            ? reason.message
            : "This audio file could not be opened.",
        );
    } finally {
      if (mounted.current && id === job.current) setChoosing(false);
    }
  }

  async function transcribe() {
    if (!audio || !consent || busy || choosing || availability !== "ready")
      return;
    const id = ++job.current;
    const pending = new AbortController();
    controller.current = pending;
    setBusy(true);
    setError("");
    setNotice("");
    setReport(null);
    const body = new FormData();
    body.set("file", audio.file);
    body.set("consent", "true");
    try {
      const response = await fetch("/api/transcribe", {
        method: "POST",
        body,
        signal: AbortSignal.any([pending.signal, AbortSignal.timeout(120_000)]),
      });
      const data = await response.json();
      if (!mounted.current || id !== job.current) return;
      if (!response.ok)
        throw Error(
          typeof data.error === "string"
            ? data.error
            : "Transcription could not finish. Try again or paste a transcript.",
        );
      if (
        typeof data.text !== "string" ||
        !data.text.trim() ||
        data.text.length > MAX_TRANSCRIPT_CHARACTERS
      )
        throw Error(
          "The service did not return a usable transcript. Try a clearer, shorter recording.",
        );
      setText(data.text.trim());
      setLanguages(
        Array.isArray(data.languages)
          ? data.languages.filter(
              (code: unknown): code is string => typeof code === "string",
            )
          : [],
      );
      setNotice(
        "Transcript returned by OpenAI. Listen back and correct the wording before checking. No scam assessment has run yet.",
      );
      requestAnimationFrame(() => review.current?.focus());
    } catch (reason) {
      if (mounted.current && id === job.current)
        setError(
          reason instanceof Error && reason.name !== "TimeoutError"
            ? reason.message
            : "Transcription timed out. Try a shorter recording.",
        );
    } finally {
      if (mounted.current && id === job.current) {
        setBusy(false);
        controller.current = null;
      }
    }
  }

  function checkTranscript() {
    const content = text.trim();
    if (!content || content.length > MAX_CHECK_CHARACTERS || busy || choosing)
      return;
    const result = assessCallTranscript(content, languages);
    setReport({ text: content, ...result });
    setError("");
    if (!result.assessment) {
      setNotice(
        "Language coverage is limited. No risk score or history entry was created for this check.",
      );
      return;
    }
    const stored = remember(
      safeScan(content, "call", result.assessment, "audio"),
      save,
    );
    setNotice(
      stored
        ? save
          ? "A redacted call summary was saved on this device. Audio was not saved."
          : "Redacted findings are available to the assistant during this session. Audio was not saved."
        : "The check is ready, but browser storage is unavailable.",
    );
  }

  return (
    <main id="main-content" className="main-wrap subpage audio-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            <span /> FROM RECORDING TO REASONING
          </span>
          <h1>
            Hear it again. <span>See the signs.</span>
          </h1>
          <p>
            Turn a voice note or recorded call into text. Review the words, then
            check the request.
          </p>
        </div>
        <span className="page-emblem">
          <AudioLines size={36} strokeWidth={1.3} />
        </span>
      </div>
      <div className="screenshot-steps" aria-label="Audio workflow">
        <span className={audio ? "done" : ""}>
          <span>01</span>Choose audio
        </span>
        <i />
        <span className={text ? "done" : ""}>
          <span>02</span>Review transcript
        </span>
        <i />
        <span className={report ? "done" : ""}>
          <span>03</span>Check the request
        </span>
      </div>

      <div className="audio-workspace">
        <section className="audio-card" aria-labelledby="audio-title">
          <div className="panel-heading">
            <div>
              <span className="section-label">YOUR RECORDING</span>
              <h2 id="audio-title">Start with the original audio.</h2>
            </div>
            {audio && (
              <button
                className="icon-button"
                aria-label="Remove recording"
                onClick={reset}
              >
                <X size={17} />
              </button>
            )}
          </div>
          <input
            ref={fileInput}
            type="file"
            className="sr-only"
            aria-label="Choose audio file"
            tabIndex={-1}
            accept={AUDIO_ACCEPT}
            disabled={busy || choosing}
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void choose(file);
            }}
          />
          {!audio ? (
            <div
              className={`audio-dropzone ${dragging ? "dragging" : ""}`}
              tabIndex={0}
              role="group"
              aria-label="Drop an MP3 or WAV recording here"
              onDragOver={(event) => {
                event.preventDefault();
                if (!busy && !choosing) setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(event) => {
                event.preventDefault();
                setDragging(false);
                if (!busy && !choosing && event.dataTransfer.files?.[0])
                  void choose(event.dataTransfer.files[0]);
              }}
            >
              <span className="upload-emblem">
                <Upload size={28} strokeWidth={1.4} />
              </span>
              <h3>Drop a recording here.</h3>
              <p>
                An MP3 voice note or WAV recording works.
                <br />
                Short, clear clips are easier to review.
              </p>
              <button
                className="primary-button"
                disabled={choosing}
                onClick={() => fileInput.current?.click()}
              >
                {choosing ? (
                  <LoaderCircle size={16} className="spin" />
                ) : (
                  <FileAudio size={16} />
                )}{" "}
                Choose audio
              </button>
              <span>MP3 or WAV · Up to 20 MB</span>
            </div>
          ) : (
            <div className="audio-file-card">
              <span className="audio-file-icon">
                <FileAudio size={28} strokeWidth={1.4} />
              </span>
              <div>
                <strong>{audio.file.name}</strong>
                <span>
                  {(audio.file.size / 1024 / 1024).toFixed(2)} MB · Ready to
                  preview
                </span>
              </div>
              <audio
                ref={player}
                controls
                src={audio.url}
                preload="metadata"
                aria-label="Preview selected recording"
              />
              <button
                className="text-button"
                disabled={busy || choosing}
                onClick={() => fileInput.current?.click()}
              >
                Change recording <ArrowRight size={14} />
              </button>
            </div>
          )}

          <div className={`audio-availability ${availability}`} role="status">
            {availability === "loading" ? (
              <>
                <LoaderCircle size={16} className="spin" />
                <span>Checking transcription availability…</span>
              </>
            ) : availability === "ready" ? (
              <>
                <Check size={17} />
                <span>
                  Transcription is configured. Review the sharing permission
                  below.
                </span>
              </>
            ) : (
              <>
                <Info size={18} />
                <div>
                  <strong>
                    {availability === "missing"
                      ? "Transcription needs a server key."
                      : "Could not check transcription availability."}
                  </strong>
                  <p>You can still paste a transcript and use the checker.</p>
                  <button
                    className="text-button"
                    onClick={() => void checkAvailability()}
                  >
                    Check again <RotateCcw size={13} />
                  </button>
                  {availability === "missing" && (
                    <details>
                      <summary>Setup for the app owner</summary>
                      <p>
                        Add <code>OPENAI_API_KEY</code> to the server's{" "}
                        <code>.env.local</code>, then restart. Optional model
                        setting: <code>OPENAI_TRANSCRIBE_MODEL</code>. Keep the
                        key off the browser and out of chat.
                      </p>
                    </details>
                  )}
                </div>
              </>
            )}
          </div>
          <label className="audio-consent">
            <input
              type="checkbox"
              checked={consent}
              disabled={busy || !audio}
              onChange={(event) => setConsent(event.target.checked)}
            />
            <span>
              I have permission to share this recording and agree to send it to
              OpenAI through this app for transcription. API usage may incur
              charges.
            </span>
          </label>
          {busy ? (
            <div className="audio-working" role="status">
              <span>
                <LoaderCircle className="spin" size={18} /> Uploading and
                transcribing…
              </span>
              <p>
                Wait for the returned transcript. Longer clips can take more
                time.
              </p>
              <button
                className="secondary-button"
                onClick={() => {
                  cancel();
                  setNotice(
                    "Transcription cancelled. Any late result will be ignored. Processing may already have started at the provider.",
                  );
                }}
              >
                Cancel transcription
              </button>
            </div>
          ) : (
            <button
              className="primary-button audio-transcribe"
              disabled={
                !audio || !consent || choosing || availability !== "ready"
              }
              onClick={() => void transcribe()}
            >
              <AudioLines size={17} /> Transcribe audio <ArrowRight size={16} />
            </button>
          )}
          <div className="audio-privacy">
            <LockKeyhole size={17} />
            <p>
              Selecting or playing a file stays on this device. Clicking
              Transcribe sends the audio to our server and OpenAI. This app does
              not write audio to disk or save it in history.{" "}
              <a
                href="https://developers.openai.com/api/docs/guides/your-data"
                target="_blank"
                rel="noopener noreferrer"
              >
                Provider data policies
              </a>{" "}
              apply.
            </p>
          </div>
        </section>

        <section
          className="audio-card audio-review"
          aria-labelledby="transcript-title"
        >
          <div className="panel-heading">
            <div>
              <span className="section-label">REVIEW BEFORE CHECKING</span>
              <h2 id="transcript-title">Keep the wording accurate.</h2>
            </div>
            <span className="step-number">02</span>
          </div>
          <p className="audio-review-help">
            Listen back for names, amounts, requests, and words like “not.”
            Speech recognition can make mistakes. You can also paste an existing
            transcript.
          </p>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              checkTranscript();
            }}
          >
            <label htmlFor="audio-transcript">Editable transcript</label>
            <textarea
              id="audio-transcript"
              ref={review}
              value={text}
              disabled={busy || choosing}
              maxLength={MAX_TRANSCRIPT_CHARACTERS}
              onChange={(event) => {
                setText(event.target.value);
                setReport(null);
                setNotice("");
              }}
              placeholder="Your transcript will appear here. Or paste the words from a call or voice note…"
            />
            <div className="input-meta">
              <span>
                {languages.length
                  ? `Detected speech: ${languages.map(languageName).join(", ")}`
                  : "Review the actual words before checking."}
              </span>
              <span>{text.length.toLocaleString()} characters</span>
            </div>
            {text.length > MAX_CHECK_CHARACTERS && (
              <p className="audio-language-note" role="status">
                The checker accepts 10,000 characters at a time. Shorten the
                reviewed text, or download the full redacted transcript.
              </p>
            )}
            <p className="audio-language-note">
              <Info size={16} /> The scam rules currently match English phrases.
              Hindi and mixed-language speech may be transcribed, but scam
              coverage is limited.
            </p>
            <label className="save-preference">
              <input
                type="checkbox"
                checked={save}
                onChange={(event) => {
                  setSave(event.target.checked);
                  try {
                    localStorage.setItem(
                      SAVE_KEY,
                      String(event.target.checked),
                    );
                  } catch {}
                }}
              />{" "}
              Save a redacted call summary in my history
            </label>
            <CloudSaveNote />
            <div className="form-footer">
              <span>
                <LockKeyhole size={14} /> Audio stays out of saved history
              </span>
              <button
                className="primary-button"
                disabled={
                  !text.trim() ||
                  text.trim().length > MAX_CHECK_CHARACTERS ||
                  busy ||
                  choosing
                }
              >
                Check reviewed transcript <ArrowRight size={16} />
              </button>
            </div>
          </form>
          <div className="audio-review-actions">
            <button
              className="secondary-button"
              disabled={!text.trim() || busy}
              onClick={() =>
                downloadText(
                  "scamshield-transcript.txt",
                  `ScamShield — reviewed transcript (automatically redacted)\n\n${redactSensitive(text)}\n\nTranscription can contain errors. This is not a verified or forensic record.`,
                )
              }
            >
              <Download size={15} /> Download redacted transcript
            </button>
            <button
              className="text-button"
              disabled={busy || choosing}
              onClick={() => {
                setText(
                  "This is the verification desk. Send your OTP immediately or your account will be blocked.",
                );
                setLanguages(["en"]);
                setReport(null);
                setNotice(
                  "Sample text loaded. This is an example transcript, not a transcription of your recording.",
                );
              }}
            >
              Load sample transcript <ArrowRight size={14} />
            </button>
          </div>
        </section>
      </div>

      {error && (
        <div className="screenshot-error" role="alert">
          <Info size={18} />
          <p>{error}</p>
        </div>
      )}
      {notice && (
        <p className="screenshot-notice" role="status">
          <Info size={16} />
          {notice}
        </p>
      )}
      {report && (
        <section
          className={`screenshot-assessment audio-assessment ${report.assessment?.tone || "neutral"}`}
          aria-live="polite"
        >
          <div className="link-report-heading">
            <div>
              <span className="section-label">
                REVIEWED TRANSCRIPT ASSESSMENT
              </span>
              <h2>What the words suggest.</h2>
              <p className="muted">
                This checks the reviewed text. It does not verify the caller,
                identify a voice, or detect audio edits.
              </p>
            </div>
            <span className="risk-badge">
              <span />
              {report.assessment
                ? assessmentLabel(report.assessment)
                : "Language coverage limited · Not scored"}
            </span>
          </div>
          {report.coverageLimited && (
            <p className="audio-language-note">
              <Info size={17} /> This transcript includes a language outside the
              English rules. Findings can miss requests; absence of a match is
              not a safety verdict.
            </p>
          )}
          {report.assessment ? (
            <>
              {report.assessment.score !== null && (
                <div
                  className="risk-track"
                  role="meter"
                  aria-label="Reviewed call text risk score"
                  aria-valuenow={report.assessment.score}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <span style={{ width: `${report.assessment.score}%` }} />
                </div>
              )}
              <p className="screenshot-summary">{report.assessment.summary}</p>
              <div className="url-flags">
                {report.assessment.signals.length ? (
                  report.assessment.signals.map((finding, index) => (
                    <article key={finding.title}>
                      <span className="flag-number">
                        {finding.type === "threat" ? (
                          index + 1
                        ) : (
                          <Info size={15} />
                        )}
                      </span>
                      <div>
                        <h3>{finding.title}</h3>
                        <p>{finding.description}</p>
                        {finding.excerpt && (
                          <blockquote>“{finding.excerpt}”</blockquote>
                        )}
                      </div>
                    </article>
                  ))
                ) : (
                  <article>
                    <span className="flag-number">
                      <Info size={16} />
                    </span>
                    <div>
                      <h3>No listed text warnings matched</h3>
                      <p>
                        This does not confirm that the caller is legitimate or
                        the recording is authentic.
                      </p>
                    </div>
                  </article>
                )}
              </div>
            </>
          ) : (
            <p className="screenshot-summary">
              The checker cannot reliably assess this language with its current
              rules. No numeric risk score was assigned. Use a carefully
              reviewed English version for the English checker.
            </p>
          )}
          <div className="link-result-actions">
            {report.assessment ? (
              <Link href="/assistant" className="secondary-button">
                <MessageCircle size={15} /> Ask about this check
              </Link>
            ) : (
              <Link href="/" className="secondary-button">
                Check an English version <ArrowRight size={15} />
              </Link>
            )}
            <Link href="/recover" className="secondary-button">
              I already responded <ArrowRight size={15} />
            </Link>
            <button
              className="secondary-button"
              onClick={() =>
                downloadText(
                  "scamshield-audio-report.txt",
                  `ScamShield — reviewed audio transcript assessment\n${report.assessment ? assessmentLabel(report.assessment) : "Language coverage limited · Not scored"}\n\n${report.assessment?.summary || "No reliable assessment was made for this language."}\n\nReviewed text (automatically redacted):\n${redactSensitive(report.text)}\n\n${report.assessment?.signals.map((finding) => `${finding.title}: ${finding.description}`).join("\n\n") || ""}\n\nText-pattern guidance only. Voice identity, recording authenticity, and sender claims were not verified. Audio was not saved.`,
                )
              }
            >
              <Download size={15} /> Download assessment
            </button>
          </div>
        </section>
      )}
      <div className="assistant-footnote">
        <Info size={16} />
        <p>
          Use recordings you are allowed to share. Original audio may contain
          private details that cannot be removed by text redaction before
          upload. API transcription needs an OpenAI key and available billing;
          it is separate from local screenshot OCR and optional Gemini chat. No
          live call recording, speaker authentication, or audio-forgery
          detection is included.
        </p>
      </div>
    </main>
  );
}
