import uuid
from typing import Any, Dict, List, Optional

from app.core.logging import logger
from app.schemas.requests import AnalyzeRequest
from app.schemas.responses import (
    AnalysisMethodEnum,
    AnalyzeResponse,
    EvidenceItem,
    EvidenceTypeEnum,
    SeverityEnum,
)
from app.services.context_analysis import analyze_message_context
from app.services.evidence_analysis import build_evidence_dossier
from app.services.risk_engine import synthesize_risk_score
from app.services.url_analysis import analyze_url_safety
from app.services.ai_provider import get_ai_provider, FallbackRulesAIProvider


async def run_analysis_pipeline(request: AnalyzeRequest) -> AnalyzeResponse:
    """
    Executes the full ScamShield analysis pipeline:
    1. Deterministic contextual parsing & feature extraction
    2. URL safety heuristics
    3. Contextual AI evaluation (with graceful fallback)
    4. Multi-tier evidence compilation (Observed, Inferred, Verified)
    5. Bounded risk engine scoring & verdict formulation
    """
    analysis_id = str(uuid.uuid4())
    logger.info(f"Initiating analysis pipeline. Session ID: {analysis_id}")

    # 1. Deterministic Contextual Analysis
    ctx = analyze_message_context(text=request.message, explicit_url=request.url)

    # 2. Safe URL Analysis
    url_findings: List[Dict[str, Any]] = []
    if ctx.extracted_urls:
        for u in ctx.extracted_urls[:3]:  # inspect first 3 extracted URLs safely
            url_res = analyze_url_safety(u)
            if url_res.risk_score >= 40:
                for ind in url_res.suspicious_indicators + url_res.lookalike_indicators:
                    url_findings.append({
                        "title": "Suspicious URL Heuristic",
                        "severity": SeverityEnum.HIGH if url_res.risk_score >= 60 else SeverityEnum.MEDIUM,
                        "points": f"+{url_res.risk_score // 3}",
                        "excerpt": u,
                        "explanation": ind,
                        "evidence_type": EvidenceTypeEnum.OBSERVED,
                    })

    # 3. AI Evaluation
    ai_provider = get_ai_provider()
    is_external_ai = not isinstance(ai_provider, FallbackRulesAIProvider)

    ai_inferred_signals: List[Dict[str, Any]] = []
    ai_analysis_data: Optional[Dict[str, Any]] = None
    analysis_method = AnalysisMethodEnum.RULES_BASED

    try:
        ai_res = await ai_provider.analyze_content(text=request.message, context=request.context)
        if ai_res:
            analysis_method = (
                AnalysisMethodEnum.AI_ASSISTED if is_external_ai else AnalysisMethodEnum.HYBRID
            )
            ai_analysis_data = ai_res.model_dump()
            for r in ai_res.inferred_risks:
                ai_inferred_signals.append({
                    "title": r.get("title", "AI Evaluated Anomaly"),
                    "severity": SeverityEnum.HIGH if r.get("severity") == "Critical" else SeverityEnum.MEDIUM,
                    "excerpt": None,
                    "explanation": r.get("explanation", ""),
                })
    except Exception as e:
        logger.warning(f"AI evaluation step skipped due to error: {str(e)}")
        analysis_method = AnalysisMethodEnum.RULES_BASED

    # 4. Build Structured Evidence Dossier
    evidence_items = build_evidence_dossier(
        context_signals=ctx.primary_signals,
        url_findings=url_findings,
        sender_info=request.sender,
        ai_inferred_signals=ai_inferred_signals,
    )

    # 5. Synthesize Risk Score & Guidance
    assessment = synthesize_risk_score(
        base_score=ctx.base_risk_score,
        evidence_items=evidence_items,
        is_security_advisory=ctx.is_security_advisory,
        is_quoted_or_reporting=ctx.is_quoted_or_reporting,
        is_pure_otp=ctx.is_pure_otp,
        is_benign_commerce=ctx.is_benign_commerce,
    )

    # 6. Format Frontend Compatibility Attributes
    risk_band_title = assessment.risk_level.value.capitalize()
    signals_frontend = [
        {
            "title": e.description,
            "severity": e.severity.value,
            "points": e.points or "N/A",
            "excerpt": e.excerpt or "",
            "description": e.explanation,
            "type": "threat" if e.severity.value in ("High", "Critical") else "safety",
        }
        for e in evidence_items
    ]

    return AnalyzeResponse(
        analysis_id=analysis_id,
        risk_score=assessment.risk_score,
        risk_level=assessment.risk_level,
        confidence=assessment.confidence,
        verdict=assessment.verdict,
        summary=assessment.summary,
        detected_categories=ctx.detected_categories,
        evidence=evidence_items,
        red_flags=ctx.red_flags,
        reassuring_signals=ctx.reassuring_signals,
        recommended_actions=assessment.recommended_actions,
        what_not_to_do=assessment.what_not_to_do,
        uncertainty=assessment.uncertainty,
        verification_steps=assessment.verification_steps,
        analysis_method=analysis_method,
        limitations=assessment.limitations,
        # Frontend compatibility fields
        score=assessment.risk_score,
        riskBand=risk_band_title,
        signals=signals_frontend,
        aiAnalysis=ai_analysis_data,
        recommendedAction=assessment.recommended_actions[0] if assessment.recommended_actions else "No action required.",
        verificationStatus="Static heuristic & AI evaluation complete. Sender identity unverified.",
        disclaimer="ScamShield provides threat analysis for advisory purposes. Always independently verify suspicious communications.",
    )
