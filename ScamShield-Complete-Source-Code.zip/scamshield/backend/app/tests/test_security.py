from app.core.logging import redact_sensitive_data
from app.services.image_service import validate_image_file


def test_sensitive_data_redaction():
    # OTP Redaction
    sample_otp = "User entered OTP: 492019 for login session"
    redacted_otp = redact_sensitive_data(sample_otp)
    assert "492019" not in redacted_otp
    assert "[REDACTED_OTP]" in redacted_otp or "[REDACTED_CODE]" in redacted_otp

    # Aadhaar Number Redaction (12 digits)
    sample_aadhaar = "Aadhaar registered is 4920 1823 9912 in record"
    redacted_aadhaar = redact_sensitive_data(sample_aadhaar)
    assert "4920 1823 9912" not in redacted_aadhaar
    assert "[REDACTED_AADHAAR]" in redacted_aadhaar

    # PAN Card Redaction (ABCDE1234F)
    sample_pan = "Customer PAN is ABCDE1234F for tax"
    redacted_pan = redact_sensitive_data(sample_pan)
    assert "ABCDE1234F" not in redacted_pan
    assert "[REDACTED_PAN]" in redacted_pan

    # Credit Card Redaction
    sample_card = "Card number 4111 2222 3333 4444 charged"
    redacted_card = redact_sensitive_data(sample_card)
    assert "4111 2222 3333 4444" not in redacted_card
    assert "[REDACTED_CARD]" in redacted_card


def test_image_file_signature_validation():
    # Valid PNG magic bytes
    valid_png_header = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
    is_valid, msg, mime = validate_image_file(valid_png_header)
    assert is_valid is True
    assert mime == "image/png"

    # Valid JPEG magic bytes
    valid_jpeg_header = b"\xff\xd8\xff\xe0\x00\x10JFIF"
    is_valid, msg, mime = validate_image_file(valid_jpeg_header)
    assert is_valid is True
    assert mime == "image/jpeg"

    # Invalid executable or plain text masquerading as image
    fake_image = b"MZ\x90\x00\x03\x00\x00\x00This is an exe"
    is_valid, msg, mime = validate_image_file(fake_image)
    assert is_valid is False
    assert "Unsupported or malformed" in msg
