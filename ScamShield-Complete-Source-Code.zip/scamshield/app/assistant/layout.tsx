import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Safety assistant | ScamShield",
  description:
    "Ask basic scam-safety questions, understand your latest check, and choose guided or optional AI answers.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
