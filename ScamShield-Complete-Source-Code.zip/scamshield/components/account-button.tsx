"use client";
import { CircleCheck } from "lucide-react";
import { useCloudHistory } from "./cloud-history-provider";
export default function AccountButton({
  children,
  className = "",
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  const { user, openAuth } = useCloudHistory();
  return (
    <button
      type="button"
      className={`account-trigger ${className} ${user ? "is-signed-in" : ""}`}
      onClick={openAuth}
      aria-haspopup="dialog"
      aria-label={
        !children && user ? "Logged in. Open account settings" : undefined
      }
      title={!children && user ? "Open account settings" : undefined}
    >
      {children ||
        (user ? (
          <>
            <CircleCheck size={15} aria-hidden="true" />
            Logged in
          </>
        ) : (
          "Sign in"
        ))}
    </button>
  );
}
