import re
from typing import Dict, List, Optional, Tuple


# 1. Security Advisory & Negation Patterns
SECURITY_ADVISORY_PATTERNS = [
    re.compile(
        r'\b(never|do not|don\'t|dont|should not|shouldn\'t|will never|never ask|strictly avoid|refuse to|warns against)\s+'
        r'(share|give|tell|disclose|send|provide|reveal|enter|forward|upload)?\s*(your|any|the)?\s*'
        r'(otp|pin|password|cvv|code|credentials|details|pan|pancard|aadhaar|aadhar|id card)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'\b(bank (employees|staff|officials|representatives) will never ask|'
        r'keep your (otp|password|pin|pan|aadhaar) (secret|private|safe)|'
        r'do not share with anyone|beware of fraudulent calls|do not click suspicious)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'\b(remember:\s*never share your otp|bank staff will never ask for your code)\b',
        re.IGNORECASE,
    ),
]

# 2. Quoted Scam & Reporting Context Patterns
QUOTED_REPORTING_PATTERNS = [
    re.compile(
        r'\b(this scammer (told|asked|said)|someone told me|received a message saying|'
        r'got a call saying|scammer said|they claimed to be)\b.*?\b(but i (ignored|blocked|reported)|i refused)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'\b(how (can|do) i recognize (a )?(phishing|scam|fraud)|'
        r'what does a (phishing|scam) (email|message) look like|'
        r'is (this|the following) a scam\??)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'["\'].*?(send your otp|pay penalty|arrest warrant).*?["\'].*?\b(ignored|blocked|fake)\b',
        re.IGNORECASE,
    ),
]

# 3. Pure OTP Delivery Notification Pattern (Transactional, NOT asking to send it back)
PURE_OTP_DELIVERY_PATTERNS = [
    re.compile(
        r'^(your\s+(login\s+)?otp\s+is\s+\d{4,8}(\.)?|'
        r'\d{4,8}\s+is\s+your\s+(verification|login|security)\s+code|'
        r'use\s+code\s+\d{4,8}\s+to\s+verify)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'\byour login otp is \d{4,8} for .*? session\b',
        re.IGNORECASE,
    ),
]

# 4. Benign Delivery Fee & Normal Commerce Patterns
BENIGN_COMMERCE_PATTERNS = [
    re.compile(
        r'\byour delivery fee is (₹|\$|rs\.?)\s*\d+(\.\d{2})?\.\s*(pay when your parcel arrives|cash on delivery|pay on delivery)\b',
        re.IGNORECASE,
    ),
    re.compile(
        r'\b(pay when your parcel arrives|cash on delivery (available|selected)|cod amount:?\s*(₹|\$|rs\.?)\s*\d+)\b',
        re.IGNORECASE,
    ),
]


def check_security_advisory(text: str) -> Tuple[bool, Optional[str]]:
    """Checks if the message is explicitly advising the user NOT to share confidential data."""
    for pattern in SECURITY_ADVISORY_PATTERNS:
        match = pattern.search(text)
        if match:
            return True, match.group(0)
    return False, None


def check_quoted_or_reporting(text: str) -> Tuple[bool, Optional[str]]:
    """Checks if the user is quoting, reporting, inquiring about, or debunking a scam rather than endorsing it."""
    for pattern in QUOTED_REPORTING_PATTERNS:
        match = pattern.search(text)
        if match:
            return True, match.group(0)
    return False, None


def check_pure_otp_notification(text: str) -> Tuple[bool, Optional[str]]:
    """
    Checks if this is a standard incoming OTP/security code notification.
    These are legitimate automated notices, but the recipient must be reminded not to share it.
    """
    # If the text asks the user to "send", "reply with", or "call to give" the OTP, it is NOT benign
    if re.search(r'\b(reply with|send (back|this|your)|call .* to give|forward to)\b', text, re.IGNORECASE):
        return False, None

    for pattern in PURE_OTP_DELIVERY_PATTERNS:
        match = pattern.search(text.strip())
        if match:
            return True, match.group(0)
    return False, None


def check_benign_commerce(text: str) -> Tuple[bool, Optional[str]]:
    """Checks for standard benign cash-on-delivery or verified e-commerce fee statements."""
    for pattern in BENIGN_COMMERCE_PATTERNS:
        match = pattern.search(text)
        if match:
            return True, match.group(0)
    return False, None
