import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Screenshot scanner | ScamShield",
  description:
    "Read text from a suspicious screenshot in your browser, review it, and check the message for common scam patterns.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
