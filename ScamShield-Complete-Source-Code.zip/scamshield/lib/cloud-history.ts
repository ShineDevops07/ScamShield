import type { SupabaseClient } from "@supabase/supabase-js";
import {
  safeAiReview,
  redactSensitive,
  type SavedScan,
  type ScanSource,
} from "./storage";
import type { Assessment, Signal } from "./analysis";

export const CLOUD_TABLE = "scamshield_checks";
export const CLOUD_PAGE_SIZE = 50;
const sources: ScanSource[] = ["message", "call", "url", "screenshot", "audio"];
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const text = (value: unknown, max: number) =>
  redactSensitive(typeof value === "string" ? value : "").slice(0, max);

// Explicit allowlist: never serialize an image, recording, full transcript or extra fields.
export function cloudRecord(scan: SavedScan, userId: string) {
  if (
    !uuid.test(scan.id) ||
    !uuid.test(userId) ||
    !Number.isFinite(Date.parse(scan.createdAt)) ||
    !["message", "call", "url"].includes(scan.channel)
  )
    throw Error("This saved check has an invalid format.");
  const a = scan.assessment;
  if (
    !a ||
    !["neutral", "safe", "warning", "danger"].includes(a.tone) ||
    !(
      (a.score === null &&
        a.kind === "payment_receipt" &&
        a.tone === "neutral") ||
      (typeof a.score === "number" &&
        Number.isFinite(a.score) &&
        a.score >= 0 &&
        a.score <= 100)
    ) ||
    !Array.isArray(a.signals)
  )
    throw Error("This assessment has an invalid format.");
  if (
    scan.source &&
    sources.includes(scan.source) &&
    (scan.source === "audio" || scan.source === "call"
      ? scan.channel !== "call"
      : scan.source === "url"
        ? scan.channel !== "url"
        : scan.channel !== "message")
  )
    throw Error("This check source does not match its channel.");
  const assessment: Assessment = {
    ...(a.aiReview ? { aiReview: safeAiReview(a.aiReview) } : {}),
    score: a.score,
    tone: a.tone,
    risk: text(a.risk, 100),
    summary: text(a.summary, 1200),
    ...(a.kind === "payment_receipt" ? { kind: a.kind } : {}),
    signals: a.signals.slice(0, 30).map((s): Signal => ({
      title: text(s.title, 160),
      description: text(s.description, 1000),
      excerpt: text(s.excerpt, 160),
      points: text(s.points, 20),
      severity: ["High", "Medium", "Low", "Positive", "Context"].includes(
        s.severity,
      )
        ? s.severity
        : "Context",
      type: ["threat", "safety", "context"].includes(s.type)
        ? s.type
        : "context",
    })),
  };
  return {
    id: scan.id,
    user_id: userId,
    created_at: new Date(scan.createdAt).toISOString(),
    channel: scan.channel,
    source: sources.includes(scan.source!) ? scan.source! : scan.channel,
    preview: text(scan.preview, 160),
    assessment,
  };
}
export function historyError(error: unknown) {
  const e = error as { code?: string; message?: string };
  if (["42P01", "PGRST205"].includes(e?.code || ""))
    return "The cloud history table is missing. Run the Supabase migration in SUPABASE.md, then retry.";
  if (["42501", "PGRST301"].includes(e?.code || ""))
    return "Cloud access was denied. Sign in again and check the database policies.";
  return "Cloud history could not be reached. Your device history is still available. Retry when you are connected.";
}
export async function uploadChecks(
  client: SupabaseClient,
  userId: string,
  scans: SavedScan[],
) {
  if (!scans.length) return;
  const rows = [
    ...new Map(scans.map((s) => [s.id, cloudRecord(s, userId)])).values(),
  ];
  const { error } = await client
    .from(CLOUD_TABLE)
    .upsert(rows, { onConflict: "user_id,id" });
  if (error) throw error;
}
export async function fetchChecks(
  client: SupabaseClient,
  userId: string,
  offset = 0,
) {
  const { data, error } = await client
    .from(CLOUD_TABLE)
    .select("id,created_at,channel,source,preview,assessment")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .order("id", { ascending: false })
    .range(offset, offset + CLOUD_PAGE_SIZE - 1);
  if (error) throw error;
  return (data || []).map((row) => {
    const candidate: SavedScan = {
      id: row.id,
      createdAt: row.created_at,
      channel: row.channel,
      source: row.source,
      preview: row.preview,
      assessment: row.assessment,
    };
    // Validate incoming records too; cloud data is not trusted markup.
    const safe = cloudRecord(candidate, userId);
    return { ...candidate, preview: safe.preview, assessment: safe.assessment };
  });
}
export async function deleteCloudCheck(
  client: SupabaseClient,
  userId: string,
  id: string,
) {
  const { error } = await client
    .from(CLOUD_TABLE)
    .delete()
    .eq("user_id", userId)
    .eq("id", id);
  if (error) throw error;
}
